﻿namespace Client
{
    partial class Frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmmain));
            this.txtBoxRcv = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnReadDO = new System.Windows.Forms.Button();
            this.btnReadDI = new System.Windows.Forms.Button();
            this.txtaddr = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDINum = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtDONum = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ip1 = new IPAddressControlLib.IPAddressControl();
            this.txtport = new System.Windows.Forms.TextBox();
            this.btnopen = new System.Windows.Forms.Button();
            this.imglistDO = new System.Windows.Forms.ImageList(this.components);
            this.imglistDI = new System.Windows.Forms.ImageList(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDO8 = new System.Windows.Forms.Button();
            this.btnDO7 = new System.Windows.Forms.Button();
            this.btnDO6 = new System.Windows.Forms.Button();
            this.btnDO5 = new System.Windows.Forms.Button();
            this.btnDO4 = new System.Windows.Forms.Button();
            this.btnDO3 = new System.Windows.Forms.Button();
            this.btnDO2 = new System.Windows.Forms.Button();
            this.btnDO1 = new System.Windows.Forms.Button();
            this.btnOpenAll = new System.Windows.Forms.Button();
            this.btnCloseAll = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDI20 = new System.Windows.Forms.Button();
            this.btnDI19 = new System.Windows.Forms.Button();
            this.btnDI18 = new System.Windows.Forms.Button();
            this.btnDI17 = new System.Windows.Forms.Button();
            this.btnDI16 = new System.Windows.Forms.Button();
            this.btnDI15 = new System.Windows.Forms.Button();
            this.btnDI14 = new System.Windows.Forms.Button();
            this.btnDI13 = new System.Windows.Forms.Button();
            this.btnDI12 = new System.Windows.Forms.Button();
            this.btnDI11 = new System.Windows.Forms.Button();
            this.btnDI10 = new System.Windows.Forms.Button();
            this.btnDI9 = new System.Windows.Forms.Button();
            this.btnDI8 = new System.Windows.Forms.Button();
            this.btnDI7 = new System.Windows.Forms.Button();
            this.btnDI6 = new System.Windows.Forms.Button();
            this.btnDI5 = new System.Windows.Forms.Button();
            this.btnDI4 = new System.Windows.Forms.Button();
            this.btnDI3 = new System.Windows.Forms.Button();
            this.btnDI2 = new System.Windows.Forms.Button();
            this.btnDI1 = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtBoxRcv
            // 
            this.txtBoxRcv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBoxRcv.Location = new System.Drawing.Point(0, 331);
            this.txtBoxRcv.Multiline = true;
            this.txtBoxRcv.Name = "txtBoxRcv";
            this.txtBoxRcv.Size = new System.Drawing.Size(696, 213);
            this.txtBoxRcv.TabIndex = 55;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnReadDO);
            this.groupBox3.Controls.Add(this.btnReadDI);
            this.groupBox3.Controls.Add(this.txtaddr);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtDINum);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.btnClear);
            this.groupBox3.Controls.Add(this.txtDONum);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.ip1);
            this.groupBox3.Controls.Add(this.txtport);
            this.groupBox3.Controls.Add(this.btnopen);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(696, 80);
            this.groupBox3.TabIndex = 56;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "设备IP及其端口";
            // 
            // btnReadDO
            // 
            this.btnReadDO.Location = new System.Drawing.Point(484, 51);
            this.btnReadDO.Name = "btnReadDO";
            this.btnReadDO.Size = new System.Drawing.Size(75, 23);
            this.btnReadDO.TabIndex = 62;
            this.btnReadDO.Text = "读取DO";
            this.btnReadDO.UseVisualStyleBackColor = true;
            this.btnReadDO.Click += new System.EventHandler(this.btnReadDO_Click);
            // 
            // btnReadDI
            // 
            this.btnReadDI.Location = new System.Drawing.Point(580, 51);
            this.btnReadDI.Name = "btnReadDI";
            this.btnReadDI.Size = new System.Drawing.Size(75, 23);
            this.btnReadDI.TabIndex = 61;
            this.btnReadDI.Text = "读取DI";
            this.btnReadDI.UseVisualStyleBackColor = true;
            this.btnReadDI.Click += new System.EventHandler(this.btnReadDI_Click);
            // 
            // txtaddr
            // 
            this.txtaddr.Location = new System.Drawing.Point(71, 53);
            this.txtaddr.Name = "txtaddr";
            this.txtaddr.Size = new System.Drawing.Size(66, 21);
            this.txtaddr.TabIndex = 58;
            this.txtaddr.Text = "254";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 57;
            this.label5.Text = "设备地址";
            // 
            // txtDINum
            // 
            this.txtDINum.Location = new System.Drawing.Point(348, 53);
            this.txtDINum.Name = "txtDINum";
            this.txtDINum.Size = new System.Drawing.Size(66, 21);
            this.txtDINum.TabIndex = 56;
            this.txtDINum.Text = "20";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(295, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 55;
            this.label4.Text = "DI数量";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(580, 18);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 54;
            this.btnClear.Text = "清空接收";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtDONum
            // 
            this.txtDONum.Location = new System.Drawing.Point(217, 53);
            this.txtDONum.Name = "txtDONum";
            this.txtDONum.Size = new System.Drawing.Size(66, 21);
            this.txtDONum.TabIndex = 53;
            this.txtDONum.Text = "8";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(164, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 52;
            this.label3.Text = "DO数量";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(220, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 50;
            this.label2.Text = "端口号：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 12);
            this.label1.TabIndex = 49;
            this.label1.Text = "IP:";
            // 
            // ip1
            // 
            this.ip1.AllowInternalTab = false;
            this.ip1.AutoHeight = true;
            this.ip1.BackColor = System.Drawing.SystemColors.Window;
            this.ip1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ip1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ip1.Location = new System.Drawing.Point(59, 20);
            this.ip1.MinimumSize = new System.Drawing.Size(96, 21);
            this.ip1.Name = "ip1";
            this.ip1.ReadOnly = false;
            this.ip1.Size = new System.Drawing.Size(129, 21);
            this.ip1.TabIndex = 48;
            this.ip1.Text = "127.0.0.1";
            // 
            // txtport
            // 
            this.txtport.Location = new System.Drawing.Point(279, 20);
            this.txtport.Name = "txtport";
            this.txtport.Size = new System.Drawing.Size(66, 21);
            this.txtport.TabIndex = 35;
            this.txtport.Text = "60000";
            // 
            // btnopen
            // 
            this.btnopen.Location = new System.Drawing.Point(484, 18);
            this.btnopen.Name = "btnopen";
            this.btnopen.Size = new System.Drawing.Size(75, 23);
            this.btnopen.TabIndex = 36;
            this.btnopen.Text = "打开连接";
            this.btnopen.UseVisualStyleBackColor = true;
            this.btnopen.Click += new System.EventHandler(this.btnopen_Click);
            // 
            // imglistDO
            // 
            this.imglistDO.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglistDO.ImageStream")));
            this.imglistDO.TransparentColor = System.Drawing.Color.Transparent;
            this.imglistDO.Images.SetKeyName(0, "comclosed.ico");
            this.imglistDO.Images.SetKeyName(1, "comopened.ico");
            this.imglistDO.Images.SetKeyName(2, "24_Help.ico");
            // 
            // imglistDI
            // 
            this.imglistDI.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglistDI.ImageStream")));
            this.imglistDI.TransparentColor = System.Drawing.Color.Transparent;
            this.imglistDI.Images.SetKeyName(0, "comclosed.ico");
            this.imglistDI.Images.SetKeyName(1, "comopened.ico");
            this.imglistDI.Images.SetKeyName(2, "24_Help.ico");
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDO8);
            this.groupBox2.Controls.Add(this.btnDO7);
            this.groupBox2.Controls.Add(this.btnDO6);
            this.groupBox2.Controls.Add(this.btnDO5);
            this.groupBox2.Controls.Add(this.btnDO4);
            this.groupBox2.Controls.Add(this.btnDO3);
            this.groupBox2.Controls.Add(this.btnDO2);
            this.groupBox2.Controls.Add(this.btnDO1);
            this.groupBox2.Controls.Add(this.btnOpenAll);
            this.groupBox2.Controls.Add(this.btnCloseAll);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 80);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(696, 106);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DO输出";
            // 
            // btnDO8
            // 
            this.btnDO8.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO8.ImageIndex = 0;
            this.btnDO8.ImageList = this.imglistDO;
            this.btnDO8.Location = new System.Drawing.Point(282, 67);
            this.btnDO8.Name = "btnDO8";
            this.btnDO8.Size = new System.Drawing.Size(80, 32);
            this.btnDO8.TabIndex = 68;
            this.btnDO8.Tag = "8";
            this.btnDO8.Text = "  DO8";
            this.btnDO8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO8.UseVisualStyleBackColor = false;
            this.btnDO8.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO7
            // 
            this.btnDO7.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO7.ImageIndex = 0;
            this.btnDO7.ImageList = this.imglistDO;
            this.btnDO7.Location = new System.Drawing.Point(190, 67);
            this.btnDO7.Name = "btnDO7";
            this.btnDO7.Size = new System.Drawing.Size(80, 32);
            this.btnDO7.TabIndex = 46;
            this.btnDO7.Tag = "7";
            this.btnDO7.Text = "  DO7";
            this.btnDO7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO7.UseVisualStyleBackColor = false;
            this.btnDO7.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO6
            // 
            this.btnDO6.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO6.ImageIndex = 0;
            this.btnDO6.ImageList = this.imglistDO;
            this.btnDO6.Location = new System.Drawing.Point(100, 67);
            this.btnDO6.Name = "btnDO6";
            this.btnDO6.Size = new System.Drawing.Size(80, 32);
            this.btnDO6.TabIndex = 45;
            this.btnDO6.Tag = "6";
            this.btnDO6.Text = "  DO6";
            this.btnDO6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO6.UseVisualStyleBackColor = false;
            this.btnDO6.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO5
            // 
            this.btnDO5.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO5.ImageIndex = 0;
            this.btnDO5.ImageList = this.imglistDO;
            this.btnDO5.Location = new System.Drawing.Point(12, 67);
            this.btnDO5.Name = "btnDO5";
            this.btnDO5.Size = new System.Drawing.Size(80, 32);
            this.btnDO5.TabIndex = 44;
            this.btnDO5.Tag = "5";
            this.btnDO5.Text = "  DO5";
            this.btnDO5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO5.UseVisualStyleBackColor = false;
            this.btnDO5.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO4
            // 
            this.btnDO4.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO4.ImageIndex = 0;
            this.btnDO4.ImageList = this.imglistDO;
            this.btnDO4.Location = new System.Drawing.Point(282, 20);
            this.btnDO4.Name = "btnDO4";
            this.btnDO4.Size = new System.Drawing.Size(80, 32);
            this.btnDO4.TabIndex = 43;
            this.btnDO4.Tag = "4";
            this.btnDO4.Text = "  DO4";
            this.btnDO4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO4.UseVisualStyleBackColor = false;
            this.btnDO4.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO3
            // 
            this.btnDO3.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO3.ImageIndex = 0;
            this.btnDO3.ImageList = this.imglistDO;
            this.btnDO3.Location = new System.Drawing.Point(190, 20);
            this.btnDO3.Name = "btnDO3";
            this.btnDO3.Size = new System.Drawing.Size(80, 32);
            this.btnDO3.TabIndex = 42;
            this.btnDO3.Tag = "3";
            this.btnDO3.Text = "  DO3";
            this.btnDO3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO3.UseVisualStyleBackColor = false;
            this.btnDO3.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO2
            // 
            this.btnDO2.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO2.ImageIndex = 0;
            this.btnDO2.ImageList = this.imglistDO;
            this.btnDO2.Location = new System.Drawing.Point(100, 20);
            this.btnDO2.Name = "btnDO2";
            this.btnDO2.Size = new System.Drawing.Size(80, 32);
            this.btnDO2.TabIndex = 41;
            this.btnDO2.Tag = "2";
            this.btnDO2.Text = "  DO2";
            this.btnDO2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO2.UseVisualStyleBackColor = false;
            this.btnDO2.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO1
            // 
            this.btnDO1.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO1.ImageIndex = 0;
            this.btnDO1.ImageList = this.imglistDO;
            this.btnDO1.Location = new System.Drawing.Point(12, 20);
            this.btnDO1.Name = "btnDO1";
            this.btnDO1.Size = new System.Drawing.Size(80, 32);
            this.btnDO1.TabIndex = 40;
            this.btnDO1.Tag = "1";
            this.btnDO1.Text = "  DO1";
            this.btnDO1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO1.UseVisualStyleBackColor = false;
            this.btnDO1.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnOpenAll
            // 
            this.btnOpenAll.BackColor = System.Drawing.SystemColors.Control;
            this.btnOpenAll.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnOpenAll.ImageKey = "comopened.ico";
            this.btnOpenAll.ImageList = this.imglistDO;
            this.btnOpenAll.Location = new System.Drawing.Point(522, 37);
            this.btnOpenAll.Name = "btnOpenAll";
            this.btnOpenAll.Size = new System.Drawing.Size(114, 45);
            this.btnOpenAll.TabIndex = 39;
            this.btnOpenAll.Tag = "1";
            this.btnOpenAll.Text = "  打开全部";
            this.btnOpenAll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOpenAll.UseVisualStyleBackColor = false;
            this.btnOpenAll.Click += new System.EventHandler(this.btnOpenAll_Click);
            // 
            // btnCloseAll
            // 
            this.btnCloseAll.BackColor = System.Drawing.SystemColors.Control;
            this.btnCloseAll.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCloseAll.ImageKey = "comclosed.ico";
            this.btnCloseAll.ImageList = this.imglistDO;
            this.btnCloseAll.Location = new System.Drawing.Point(381, 37);
            this.btnCloseAll.Name = "btnCloseAll";
            this.btnCloseAll.Size = new System.Drawing.Size(114, 45);
            this.btnCloseAll.TabIndex = 38;
            this.btnCloseAll.Tag = "1";
            this.btnCloseAll.Text = "  关闭全部";
            this.btnCloseAll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCloseAll.UseVisualStyleBackColor = false;
            this.btnCloseAll.Click += new System.EventHandler(this.btnCloseAll_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.btnDI20);
            this.groupBox1.Controls.Add(this.btnDI19);
            this.groupBox1.Controls.Add(this.btnDI18);
            this.groupBox1.Controls.Add(this.btnDI17);
            this.groupBox1.Controls.Add(this.btnDI16);
            this.groupBox1.Controls.Add(this.btnDI15);
            this.groupBox1.Controls.Add(this.btnDI14);
            this.groupBox1.Controls.Add(this.btnDI13);
            this.groupBox1.Controls.Add(this.btnDI12);
            this.groupBox1.Controls.Add(this.btnDI11);
            this.groupBox1.Controls.Add(this.btnDI10);
            this.groupBox1.Controls.Add(this.btnDI9);
            this.groupBox1.Controls.Add(this.btnDI8);
            this.groupBox1.Controls.Add(this.btnDI7);
            this.groupBox1.Controls.Add(this.btnDI6);
            this.groupBox1.Controls.Add(this.btnDI5);
            this.groupBox1.Controls.Add(this.btnDI4);
            this.groupBox1.Controls.Add(this.btnDI3);
            this.groupBox1.Controls.Add(this.btnDI2);
            this.groupBox1.Controls.Add(this.btnDI1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 186);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(696, 145);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DI输入";
            // 
            // btnDI20
            // 
            this.btnDI20.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI20.FlatAppearance.BorderSize = 0;
            this.btnDI20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI20.ImageIndex = 0;
            this.btnDI20.ImageList = this.imglistDI;
            this.btnDI20.Location = new System.Drawing.Point(519, 81);
            this.btnDI20.Name = "btnDI20";
            this.btnDI20.Size = new System.Drawing.Size(55, 55);
            this.btnDI20.TabIndex = 60;
            this.btnDI20.Tag = "20";
            this.btnDI20.Text = "DI20";
            this.btnDI20.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI20.UseVisualStyleBackColor = true;
            // 
            // btnDI19
            // 
            this.btnDI19.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI19.FlatAppearance.BorderSize = 0;
            this.btnDI19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI19.ImageIndex = 0;
            this.btnDI19.ImageList = this.imglistDI;
            this.btnDI19.Location = new System.Drawing.Point(462, 81);
            this.btnDI19.Name = "btnDI19";
            this.btnDI19.Size = new System.Drawing.Size(55, 55);
            this.btnDI19.TabIndex = 59;
            this.btnDI19.Tag = "19";
            this.btnDI19.Text = "DI19";
            this.btnDI19.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI19.UseVisualStyleBackColor = true;
            // 
            // btnDI18
            // 
            this.btnDI18.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI18.FlatAppearance.BorderSize = 0;
            this.btnDI18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI18.ImageIndex = 0;
            this.btnDI18.ImageList = this.imglistDI;
            this.btnDI18.Location = new System.Drawing.Point(405, 81);
            this.btnDI18.Name = "btnDI18";
            this.btnDI18.Size = new System.Drawing.Size(55, 55);
            this.btnDI18.TabIndex = 58;
            this.btnDI18.Tag = "18";
            this.btnDI18.Text = "DI18";
            this.btnDI18.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI18.UseVisualStyleBackColor = true;
            // 
            // btnDI17
            // 
            this.btnDI17.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI17.FlatAppearance.BorderSize = 0;
            this.btnDI17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI17.ImageIndex = 0;
            this.btnDI17.ImageList = this.imglistDI;
            this.btnDI17.Location = new System.Drawing.Point(348, 81);
            this.btnDI17.Name = "btnDI17";
            this.btnDI17.Size = new System.Drawing.Size(55, 55);
            this.btnDI17.TabIndex = 57;
            this.btnDI17.Tag = "17";
            this.btnDI17.Text = "DI17";
            this.btnDI17.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI17.UseVisualStyleBackColor = true;
            // 
            // btnDI16
            // 
            this.btnDI16.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI16.FlatAppearance.BorderSize = 0;
            this.btnDI16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI16.ImageIndex = 0;
            this.btnDI16.ImageList = this.imglistDI;
            this.btnDI16.Location = new System.Drawing.Point(291, 81);
            this.btnDI16.Name = "btnDI16";
            this.btnDI16.Size = new System.Drawing.Size(55, 55);
            this.btnDI16.TabIndex = 56;
            this.btnDI16.Tag = "16";
            this.btnDI16.Text = "DI16";
            this.btnDI16.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI16.UseVisualStyleBackColor = true;
            // 
            // btnDI15
            // 
            this.btnDI15.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI15.FlatAppearance.BorderSize = 0;
            this.btnDI15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI15.ImageIndex = 0;
            this.btnDI15.ImageList = this.imglistDI;
            this.btnDI15.Location = new System.Drawing.Point(234, 81);
            this.btnDI15.Name = "btnDI15";
            this.btnDI15.Size = new System.Drawing.Size(55, 55);
            this.btnDI15.TabIndex = 55;
            this.btnDI15.Tag = "15";
            this.btnDI15.Text = "DI15";
            this.btnDI15.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI15.UseVisualStyleBackColor = true;
            // 
            // btnDI14
            // 
            this.btnDI14.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI14.FlatAppearance.BorderSize = 0;
            this.btnDI14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI14.ImageIndex = 0;
            this.btnDI14.ImageList = this.imglistDI;
            this.btnDI14.Location = new System.Drawing.Point(177, 81);
            this.btnDI14.Name = "btnDI14";
            this.btnDI14.Size = new System.Drawing.Size(55, 55);
            this.btnDI14.TabIndex = 54;
            this.btnDI14.Tag = "14";
            this.btnDI14.Text = "DI14";
            this.btnDI14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI14.UseVisualStyleBackColor = true;
            // 
            // btnDI13
            // 
            this.btnDI13.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI13.FlatAppearance.BorderSize = 0;
            this.btnDI13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI13.ImageIndex = 0;
            this.btnDI13.ImageList = this.imglistDI;
            this.btnDI13.Location = new System.Drawing.Point(120, 81);
            this.btnDI13.Name = "btnDI13";
            this.btnDI13.Size = new System.Drawing.Size(55, 55);
            this.btnDI13.TabIndex = 53;
            this.btnDI13.Tag = "13";
            this.btnDI13.Text = "DI13";
            this.btnDI13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI13.UseVisualStyleBackColor = true;
            // 
            // btnDI12
            // 
            this.btnDI12.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI12.FlatAppearance.BorderSize = 0;
            this.btnDI12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI12.ImageIndex = 0;
            this.btnDI12.ImageList = this.imglistDI;
            this.btnDI12.Location = new System.Drawing.Point(63, 81);
            this.btnDI12.Name = "btnDI12";
            this.btnDI12.Size = new System.Drawing.Size(55, 55);
            this.btnDI12.TabIndex = 52;
            this.btnDI12.Tag = "12";
            this.btnDI12.Text = "DI12";
            this.btnDI12.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI12.UseVisualStyleBackColor = true;
            // 
            // btnDI11
            // 
            this.btnDI11.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI11.FlatAppearance.BorderSize = 0;
            this.btnDI11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI11.ImageIndex = 0;
            this.btnDI11.ImageList = this.imglistDI;
            this.btnDI11.Location = new System.Drawing.Point(6, 81);
            this.btnDI11.Name = "btnDI11";
            this.btnDI11.Size = new System.Drawing.Size(55, 55);
            this.btnDI11.TabIndex = 51;
            this.btnDI11.Tag = "11";
            this.btnDI11.Text = "DI11";
            this.btnDI11.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI11.UseVisualStyleBackColor = true;
            // 
            // btnDI10
            // 
            this.btnDI10.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI10.FlatAppearance.BorderSize = 0;
            this.btnDI10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI10.ImageIndex = 0;
            this.btnDI10.ImageList = this.imglistDI;
            this.btnDI10.Location = new System.Drawing.Point(519, 20);
            this.btnDI10.Name = "btnDI10";
            this.btnDI10.Size = new System.Drawing.Size(55, 55);
            this.btnDI10.TabIndex = 50;
            this.btnDI10.Tag = "10";
            this.btnDI10.Text = "DI10";
            this.btnDI10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI10.UseVisualStyleBackColor = true;
            // 
            // btnDI9
            // 
            this.btnDI9.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI9.FlatAppearance.BorderSize = 0;
            this.btnDI9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI9.ImageIndex = 0;
            this.btnDI9.ImageList = this.imglistDI;
            this.btnDI9.Location = new System.Drawing.Point(462, 20);
            this.btnDI9.Name = "btnDI9";
            this.btnDI9.Size = new System.Drawing.Size(55, 55);
            this.btnDI9.TabIndex = 49;
            this.btnDI9.Tag = "9";
            this.btnDI9.Text = "DI9";
            this.btnDI9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI9.UseVisualStyleBackColor = true;
            // 
            // btnDI8
            // 
            this.btnDI8.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI8.FlatAppearance.BorderSize = 0;
            this.btnDI8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI8.ImageIndex = 0;
            this.btnDI8.ImageList = this.imglistDI;
            this.btnDI8.Location = new System.Drawing.Point(405, 20);
            this.btnDI8.Name = "btnDI8";
            this.btnDI8.Size = new System.Drawing.Size(55, 55);
            this.btnDI8.TabIndex = 48;
            this.btnDI8.Tag = "8";
            this.btnDI8.Text = "DI8";
            this.btnDI8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI8.UseVisualStyleBackColor = true;
            // 
            // btnDI7
            // 
            this.btnDI7.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI7.FlatAppearance.BorderSize = 0;
            this.btnDI7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI7.ImageIndex = 0;
            this.btnDI7.ImageList = this.imglistDI;
            this.btnDI7.Location = new System.Drawing.Point(348, 20);
            this.btnDI7.Name = "btnDI7";
            this.btnDI7.Size = new System.Drawing.Size(55, 55);
            this.btnDI7.TabIndex = 47;
            this.btnDI7.Tag = "7";
            this.btnDI7.Text = "DI7";
            this.btnDI7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI7.UseVisualStyleBackColor = true;
            // 
            // btnDI6
            // 
            this.btnDI6.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI6.FlatAppearance.BorderSize = 0;
            this.btnDI6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI6.ImageIndex = 0;
            this.btnDI6.ImageList = this.imglistDI;
            this.btnDI6.Location = new System.Drawing.Point(291, 20);
            this.btnDI6.Name = "btnDI6";
            this.btnDI6.Size = new System.Drawing.Size(55, 55);
            this.btnDI6.TabIndex = 46;
            this.btnDI6.Tag = "6";
            this.btnDI6.Text = "DI6";
            this.btnDI6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI6.UseVisualStyleBackColor = true;
            // 
            // btnDI5
            // 
            this.btnDI5.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI5.FlatAppearance.BorderSize = 0;
            this.btnDI5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI5.ImageIndex = 0;
            this.btnDI5.ImageList = this.imglistDI;
            this.btnDI5.Location = new System.Drawing.Point(234, 20);
            this.btnDI5.Name = "btnDI5";
            this.btnDI5.Size = new System.Drawing.Size(55, 55);
            this.btnDI5.TabIndex = 45;
            this.btnDI5.Tag = "5";
            this.btnDI5.Text = "DI5";
            this.btnDI5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI5.UseVisualStyleBackColor = true;
            // 
            // btnDI4
            // 
            this.btnDI4.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI4.FlatAppearance.BorderSize = 0;
            this.btnDI4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI4.ImageIndex = 0;
            this.btnDI4.ImageList = this.imglistDI;
            this.btnDI4.Location = new System.Drawing.Point(177, 20);
            this.btnDI4.Name = "btnDI4";
            this.btnDI4.Size = new System.Drawing.Size(55, 55);
            this.btnDI4.TabIndex = 44;
            this.btnDI4.Tag = "4";
            this.btnDI4.Text = "DI4";
            this.btnDI4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI4.UseVisualStyleBackColor = true;
            // 
            // btnDI3
            // 
            this.btnDI3.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI3.FlatAppearance.BorderSize = 0;
            this.btnDI3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI3.ImageIndex = 0;
            this.btnDI3.ImageList = this.imglistDI;
            this.btnDI3.Location = new System.Drawing.Point(120, 20);
            this.btnDI3.Name = "btnDI3";
            this.btnDI3.Size = new System.Drawing.Size(55, 55);
            this.btnDI3.TabIndex = 43;
            this.btnDI3.Tag = "3";
            this.btnDI3.Text = "DI3";
            this.btnDI3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI3.UseVisualStyleBackColor = true;
            // 
            // btnDI2
            // 
            this.btnDI2.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI2.FlatAppearance.BorderSize = 0;
            this.btnDI2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI2.ImageIndex = 0;
            this.btnDI2.ImageList = this.imglistDI;
            this.btnDI2.Location = new System.Drawing.Point(63, 20);
            this.btnDI2.Name = "btnDI2";
            this.btnDI2.Size = new System.Drawing.Size(55, 55);
            this.btnDI2.TabIndex = 42;
            this.btnDI2.Tag = "2";
            this.btnDI2.Text = "DI2";
            this.btnDI2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI2.UseVisualStyleBackColor = true;
            // 
            // btnDI1
            // 
            this.btnDI1.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI1.FlatAppearance.BorderSize = 0;
            this.btnDI1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI1.ImageIndex = 0;
            this.btnDI1.ImageList = this.imglistDI;
            this.btnDI1.Location = new System.Drawing.Point(6, 20);
            this.btnDI1.Name = "btnDI1";
            this.btnDI1.Size = new System.Drawing.Size(55, 55);
            this.btnDI1.TabIndex = 41;
            this.btnDI1.Tag = "1";
            this.btnDI1.Text = "DI1";
            this.btnDI1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI1.UseVisualStyleBackColor = true;
            // 
            // Frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 544);
            this.Controls.Add(this.txtBoxRcv);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Name = "Frmmain";
            this.Text = "TCP/IP 客户端调试";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Frmmain_FormClosed);
            this.Load += new System.EventHandler(this.Frmmain_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoxRcv;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public IPAddressControlLib.IPAddressControl ip1;
        public System.Windows.Forms.TextBox txtport;
        private System.Windows.Forms.Button btnopen;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtDONum;
        private System.Windows.Forms.ImageList imglistDO;
        private System.Windows.Forms.ImageList imglistDI;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnDO8;
        private System.Windows.Forms.Button btnDO7;
        private System.Windows.Forms.Button btnDO6;
        private System.Windows.Forms.Button btnDO5;
        private System.Windows.Forms.Button btnDO4;
        private System.Windows.Forms.Button btnDO3;
        private System.Windows.Forms.Button btnDO2;
        private System.Windows.Forms.Button btnDO1;
        private System.Windows.Forms.Button btnOpenAll;
        private System.Windows.Forms.Button btnCloseAll;
        public System.Windows.Forms.TextBox txtDINum;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDI20;
        private System.Windows.Forms.Button btnDI19;
        private System.Windows.Forms.Button btnDI18;
        private System.Windows.Forms.Button btnDI17;
        private System.Windows.Forms.Button btnDI16;
        private System.Windows.Forms.Button btnDI15;
        private System.Windows.Forms.Button btnDI14;
        private System.Windows.Forms.Button btnDI13;
        private System.Windows.Forms.Button btnDI12;
        private System.Windows.Forms.Button btnDI11;
        private System.Windows.Forms.Button btnDI10;
        private System.Windows.Forms.Button btnDI9;
        private System.Windows.Forms.Button btnDI8;
        private System.Windows.Forms.Button btnDI7;
        private System.Windows.Forms.Button btnDI6;
        private System.Windows.Forms.Button btnDI5;
        private System.Windows.Forms.Button btnDI4;
        private System.Windows.Forms.Button btnDI3;
        private System.Windows.Forms.Button btnDI2;
        private System.Windows.Forms.Button btnDI1;
        public System.Windows.Forms.TextBox txtaddr;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnReadDI;
        private System.Windows.Forms.Button btnReadDO;
    }
}

