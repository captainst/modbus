﻿namespace Client
{
    partial class Frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmmain));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtAINum = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbxBaudRate = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbxPortNum = new System.Windows.Forms.ComboBox();
            this.btnReadDO = new System.Windows.Forms.Button();
            this.btnReadDI = new System.Windows.Forms.Button();
            this.txtaddr = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDINum = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtDONum = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnopen = new System.Windows.Forms.Button();
            this.imglistDO = new System.Windows.Forms.ImageList(this.components);
            this.imglistDI = new System.Windows.Forms.ImageList(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDO32 = new System.Windows.Forms.Button();
            this.btnDO31 = new System.Windows.Forms.Button();
            this.btnDO30 = new System.Windows.Forms.Button();
            this.btnDO29 = new System.Windows.Forms.Button();
            this.btnDO28 = new System.Windows.Forms.Button();
            this.btnDO27 = new System.Windows.Forms.Button();
            this.btnDO26 = new System.Windows.Forms.Button();
            this.btnDO25 = new System.Windows.Forms.Button();
            this.btnDO24 = new System.Windows.Forms.Button();
            this.btnDO23 = new System.Windows.Forms.Button();
            this.btnDO22 = new System.Windows.Forms.Button();
            this.btnDO21 = new System.Windows.Forms.Button();
            this.btnDO20 = new System.Windows.Forms.Button();
            this.btnDO19 = new System.Windows.Forms.Button();
            this.btnDO18 = new System.Windows.Forms.Button();
            this.btnDO17 = new System.Windows.Forms.Button();
            this.btnDO16 = new System.Windows.Forms.Button();
            this.btnDO15 = new System.Windows.Forms.Button();
            this.btnDO14 = new System.Windows.Forms.Button();
            this.btnDO13 = new System.Windows.Forms.Button();
            this.btnDO12 = new System.Windows.Forms.Button();
            this.btnDO11 = new System.Windows.Forms.Button();
            this.btnDO10 = new System.Windows.Forms.Button();
            this.btnDO9 = new System.Windows.Forms.Button();
            this.btnDO8 = new System.Windows.Forms.Button();
            this.btnDO7 = new System.Windows.Forms.Button();
            this.btnDO6 = new System.Windows.Forms.Button();
            this.btnDO5 = new System.Windows.Forms.Button();
            this.btnDO4 = new System.Windows.Forms.Button();
            this.btnDO3 = new System.Windows.Forms.Button();
            this.btnDO2 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnCloseAll = new System.Windows.Forms.Button();
            this.txtInterval = new System.Windows.Forms.TextBox();
            this.btnDIRead = new System.Windows.Forms.Button();
            this.btnOpenAll = new System.Windows.Forms.Button();
            this.btnLed2 = new System.Windows.Forms.Button();
            this.btnLed1 = new System.Windows.Forms.Button();
            this.btnDO1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtbaseaddr = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDI32 = new System.Windows.Forms.Button();
            this.btnDI31 = new System.Windows.Forms.Button();
            this.btnDI30 = new System.Windows.Forms.Button();
            this.btnDI29 = new System.Windows.Forms.Button();
            this.btnDI28 = new System.Windows.Forms.Button();
            this.btnDI27 = new System.Windows.Forms.Button();
            this.btnDI26 = new System.Windows.Forms.Button();
            this.btnDI25 = new System.Windows.Forms.Button();
            this.btnDI24 = new System.Windows.Forms.Button();
            this.btnDI23 = new System.Windows.Forms.Button();
            this.btnDI22 = new System.Windows.Forms.Button();
            this.btnDI21 = new System.Windows.Forms.Button();
            this.btnDI20 = new System.Windows.Forms.Button();
            this.btnDI19 = new System.Windows.Forms.Button();
            this.btnDI18 = new System.Windows.Forms.Button();
            this.btnDI17 = new System.Windows.Forms.Button();
            this.btnDI16 = new System.Windows.Forms.Button();
            this.btnDI15 = new System.Windows.Forms.Button();
            this.btnDI14 = new System.Windows.Forms.Button();
            this.btnDI13 = new System.Windows.Forms.Button();
            this.btnDI12 = new System.Windows.Forms.Button();
            this.btnDI11 = new System.Windows.Forms.Button();
            this.btnDI10 = new System.Windows.Forms.Button();
            this.btnDI9 = new System.Windows.Forms.Button();
            this.btnDI8 = new System.Windows.Forms.Button();
            this.btnDI7 = new System.Windows.Forms.Button();
            this.btnDI6 = new System.Windows.Forms.Button();
            this.btnDI5 = new System.Windows.Forms.Button();
            this.btnDI4 = new System.Windows.Forms.Button();
            this.btnDI3 = new System.Windows.Forms.Button();
            this.btnDI2 = new System.Windows.Forms.Button();
            this.btnDI1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.txtBoxRcv = new System.Windows.Forms.RichTextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.txtao2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtwao12 = new System.Windows.Forms.Button();
            this.txtwao2 = new System.Windows.Forms.Button();
            this.txtwao1 = new System.Windows.Forms.Button();
            this.txtao1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.txtAINum);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.cbxBaudRate);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.cbxPortNum);
            this.groupBox3.Controls.Add(this.btnReadDO);
            this.groupBox3.Controls.Add(this.btnReadDI);
            this.groupBox3.Controls.Add(this.txtaddr);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtDINum);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.btnClear);
            this.groupBox3.Controls.Add(this.txtDONum);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.btnopen);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(620, 108);
            this.groupBox3.TabIndex = 56;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "设备IP及其端口";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(424, 80);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 69;
            this.button1.Text = "读取AI";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtAINum
            // 
            this.txtAINum.Location = new System.Drawing.Point(349, 80);
            this.txtAINum.Name = "txtAINum";
            this.txtAINum.Size = new System.Drawing.Size(66, 21);
            this.txtAINum.TabIndex = 68;
            this.txtAINum.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(296, 83);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 67;
            this.label8.Text = "AI数量";
            // 
            // cbxBaudRate
            // 
            this.cbxBaudRate.FormattingEnabled = true;
            this.cbxBaudRate.Items.AddRange(new object[] {
            "9600",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "115200"});
            this.cbxBaudRate.Location = new System.Drawing.Point(216, 24);
            this.cbxBaudRate.Name = "cbxBaudRate";
            this.cbxBaudRate.Size = new System.Drawing.Size(67, 20);
            this.cbxBaudRate.TabIndex = 66;
            this.cbxBaudRate.Text = "9600";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(160, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 65;
            this.label6.Text = "波特率:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(15, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 64;
            this.label1.Text = "串口号:";
            // 
            // cbxPortNum
            // 
            this.cbxPortNum.FormattingEnabled = true;
            this.cbxPortNum.Location = new System.Drawing.Point(71, 21);
            this.cbxPortNum.Name = "cbxPortNum";
            this.cbxPortNum.Size = new System.Drawing.Size(66, 20);
            this.cbxPortNum.TabIndex = 63;
            // 
            // btnReadDO
            // 
            this.btnReadDO.Location = new System.Drawing.Point(420, 51);
            this.btnReadDO.Name = "btnReadDO";
            this.btnReadDO.Size = new System.Drawing.Size(75, 23);
            this.btnReadDO.TabIndex = 62;
            this.btnReadDO.Text = "读取DO";
            this.btnReadDO.UseVisualStyleBackColor = true;
            this.btnReadDO.Click += new System.EventHandler(this.btnReadDO_Click);
            // 
            // btnReadDI
            // 
            this.btnReadDI.Location = new System.Drawing.Point(505, 52);
            this.btnReadDI.Name = "btnReadDI";
            this.btnReadDI.Size = new System.Drawing.Size(75, 23);
            this.btnReadDI.TabIndex = 61;
            this.btnReadDI.Text = "读取DI";
            this.btnReadDI.UseVisualStyleBackColor = true;
            this.btnReadDI.Click += new System.EventHandler(this.btnReadDI_Click);
            // 
            // txtaddr
            // 
            this.txtaddr.Location = new System.Drawing.Point(71, 53);
            this.txtaddr.Name = "txtaddr";
            this.txtaddr.Size = new System.Drawing.Size(66, 21);
            this.txtaddr.TabIndex = 58;
            this.txtaddr.Text = "254";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 57;
            this.label5.Text = "设备地址";
            // 
            // txtDINum
            // 
            this.txtDINum.Location = new System.Drawing.Point(348, 53);
            this.txtDINum.Name = "txtDINum";
            this.txtDINum.Size = new System.Drawing.Size(66, 21);
            this.txtDINum.TabIndex = 56;
            this.txtDINum.Text = "0";
            this.txtDINum.TextChanged += new System.EventHandler(this.txtDINum_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(295, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 55;
            this.label4.Text = "DI数量";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(505, 12);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 54;
            this.btnClear.Text = "清空接收";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtDONum
            // 
            this.txtDONum.Location = new System.Drawing.Point(217, 53);
            this.txtDONum.Name = "txtDONum";
            this.txtDONum.Size = new System.Drawing.Size(66, 21);
            this.txtDONum.TabIndex = 53;
            this.txtDONum.Text = "0";
            this.txtDONum.TextChanged += new System.EventHandler(this.txtDONum_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(164, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 52;
            this.label3.Text = "DO数量";
            // 
            // btnopen
            // 
            this.btnopen.Location = new System.Drawing.Point(424, 12);
            this.btnopen.Name = "btnopen";
            this.btnopen.Size = new System.Drawing.Size(75, 23);
            this.btnopen.TabIndex = 36;
            this.btnopen.Text = "打开串口";
            this.btnopen.UseVisualStyleBackColor = true;
            this.btnopen.Click += new System.EventHandler(this.btnopen_Click);
            // 
            // imglistDO
            // 
            this.imglistDO.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglistDO.ImageStream")));
            this.imglistDO.TransparentColor = System.Drawing.Color.Transparent;
            this.imglistDO.Images.SetKeyName(0, "comclosed.ico");
            this.imglistDO.Images.SetKeyName(1, "comopened.ico");
            this.imglistDO.Images.SetKeyName(2, "24_Help.ico");
            // 
            // imglistDI
            // 
            this.imglistDI.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglistDI.ImageStream")));
            this.imglistDI.TransparentColor = System.Drawing.Color.Transparent;
            this.imglistDI.Images.SetKeyName(0, "comclosed.ico");
            this.imglistDI.Images.SetKeyName(1, "comopened.ico");
            this.imglistDI.Images.SetKeyName(2, "24_Help.ico");
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDO32);
            this.groupBox2.Controls.Add(this.btnDO31);
            this.groupBox2.Controls.Add(this.btnDO30);
            this.groupBox2.Controls.Add(this.btnDO29);
            this.groupBox2.Controls.Add(this.btnDO28);
            this.groupBox2.Controls.Add(this.btnDO27);
            this.groupBox2.Controls.Add(this.btnDO26);
            this.groupBox2.Controls.Add(this.btnDO25);
            this.groupBox2.Controls.Add(this.btnDO24);
            this.groupBox2.Controls.Add(this.btnDO23);
            this.groupBox2.Controls.Add(this.btnDO22);
            this.groupBox2.Controls.Add(this.btnDO21);
            this.groupBox2.Controls.Add(this.btnDO20);
            this.groupBox2.Controls.Add(this.btnDO19);
            this.groupBox2.Controls.Add(this.btnDO18);
            this.groupBox2.Controls.Add(this.btnDO17);
            this.groupBox2.Controls.Add(this.btnDO16);
            this.groupBox2.Controls.Add(this.btnDO15);
            this.groupBox2.Controls.Add(this.btnDO14);
            this.groupBox2.Controls.Add(this.btnDO13);
            this.groupBox2.Controls.Add(this.btnDO12);
            this.groupBox2.Controls.Add(this.btnDO11);
            this.groupBox2.Controls.Add(this.btnDO10);
            this.groupBox2.Controls.Add(this.btnDO9);
            this.groupBox2.Controls.Add(this.btnDO8);
            this.groupBox2.Controls.Add(this.btnDO7);
            this.groupBox2.Controls.Add(this.btnDO6);
            this.groupBox2.Controls.Add(this.btnDO5);
            this.groupBox2.Controls.Add(this.btnDO4);
            this.groupBox2.Controls.Add(this.btnDO3);
            this.groupBox2.Controls.Add(this.btnDO2);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.btnDO1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 108);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(620, 243);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "V";
            // 
            // btnDO32
            // 
            this.btnDO32.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO32.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO32.ImageIndex = 0;
            this.btnDO32.ImageList = this.imglistDO;
            this.btnDO32.Location = new System.Drawing.Point(530, 134);
            this.btnDO32.Name = "btnDO32";
            this.btnDO32.Size = new System.Drawing.Size(68, 32);
            this.btnDO32.TabIndex = 112;
            this.btnDO32.Tag = "32";
            this.btnDO32.Text = " DO32";
            this.btnDO32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO32.UseVisualStyleBackColor = false;
            this.btnDO32.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO31
            // 
            this.btnDO31.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO31.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO31.ImageIndex = 0;
            this.btnDO31.ImageList = this.imglistDO;
            this.btnDO31.Location = new System.Drawing.Point(456, 134);
            this.btnDO31.Name = "btnDO31";
            this.btnDO31.Size = new System.Drawing.Size(68, 32);
            this.btnDO31.TabIndex = 111;
            this.btnDO31.Tag = "31";
            this.btnDO31.Text = " DO31";
            this.btnDO31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO31.UseVisualStyleBackColor = false;
            this.btnDO31.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO30
            // 
            this.btnDO30.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO30.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO30.ImageIndex = 0;
            this.btnDO30.ImageList = this.imglistDO;
            this.btnDO30.Location = new System.Drawing.Point(382, 134);
            this.btnDO30.Name = "btnDO30";
            this.btnDO30.Size = new System.Drawing.Size(68, 32);
            this.btnDO30.TabIndex = 110;
            this.btnDO30.Tag = "30";
            this.btnDO30.Text = " DO30";
            this.btnDO30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO30.UseVisualStyleBackColor = false;
            this.btnDO30.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO29
            // 
            this.btnDO29.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO29.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO29.ImageIndex = 0;
            this.btnDO29.ImageList = this.imglistDO;
            this.btnDO29.Location = new System.Drawing.Point(308, 134);
            this.btnDO29.Name = "btnDO29";
            this.btnDO29.Size = new System.Drawing.Size(68, 32);
            this.btnDO29.TabIndex = 109;
            this.btnDO29.Tag = "29";
            this.btnDO29.Text = " DO29";
            this.btnDO29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO29.UseVisualStyleBackColor = false;
            this.btnDO29.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO28
            // 
            this.btnDO28.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO28.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO28.ImageIndex = 0;
            this.btnDO28.ImageList = this.imglistDO;
            this.btnDO28.Location = new System.Drawing.Point(234, 134);
            this.btnDO28.Name = "btnDO28";
            this.btnDO28.Size = new System.Drawing.Size(68, 32);
            this.btnDO28.TabIndex = 108;
            this.btnDO28.Tag = "28";
            this.btnDO28.Text = " DO28";
            this.btnDO28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO28.UseVisualStyleBackColor = false;
            this.btnDO28.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO27
            // 
            this.btnDO27.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO27.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO27.ImageIndex = 0;
            this.btnDO27.ImageList = this.imglistDO;
            this.btnDO27.Location = new System.Drawing.Point(160, 134);
            this.btnDO27.Name = "btnDO27";
            this.btnDO27.Size = new System.Drawing.Size(68, 32);
            this.btnDO27.TabIndex = 107;
            this.btnDO27.Tag = "27";
            this.btnDO27.Text = " DO27";
            this.btnDO27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO27.UseVisualStyleBackColor = false;
            this.btnDO27.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO26
            // 
            this.btnDO26.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO26.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO26.ImageIndex = 0;
            this.btnDO26.ImageList = this.imglistDO;
            this.btnDO26.Location = new System.Drawing.Point(86, 134);
            this.btnDO26.Name = "btnDO26";
            this.btnDO26.Size = new System.Drawing.Size(68, 32);
            this.btnDO26.TabIndex = 106;
            this.btnDO26.Tag = "26";
            this.btnDO26.Text = " DO26";
            this.btnDO26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO26.UseVisualStyleBackColor = false;
            this.btnDO26.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO25
            // 
            this.btnDO25.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO25.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO25.ImageIndex = 0;
            this.btnDO25.ImageList = this.imglistDO;
            this.btnDO25.Location = new System.Drawing.Point(12, 134);
            this.btnDO25.Name = "btnDO25";
            this.btnDO25.Size = new System.Drawing.Size(68, 32);
            this.btnDO25.TabIndex = 105;
            this.btnDO25.Tag = "25";
            this.btnDO25.Text = " DO25";
            this.btnDO25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO25.UseVisualStyleBackColor = false;
            this.btnDO25.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO24
            // 
            this.btnDO24.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO24.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO24.ImageIndex = 0;
            this.btnDO24.ImageList = this.imglistDO;
            this.btnDO24.Location = new System.Drawing.Point(529, 96);
            this.btnDO24.Name = "btnDO24";
            this.btnDO24.Size = new System.Drawing.Size(68, 32);
            this.btnDO24.TabIndex = 104;
            this.btnDO24.Tag = "24";
            this.btnDO24.Text = " DO24";
            this.btnDO24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO24.UseVisualStyleBackColor = false;
            this.btnDO24.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO23
            // 
            this.btnDO23.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO23.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO23.ImageIndex = 0;
            this.btnDO23.ImageList = this.imglistDO;
            this.btnDO23.Location = new System.Drawing.Point(455, 96);
            this.btnDO23.Name = "btnDO23";
            this.btnDO23.Size = new System.Drawing.Size(68, 32);
            this.btnDO23.TabIndex = 103;
            this.btnDO23.Tag = "23";
            this.btnDO23.Text = " DO23";
            this.btnDO23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO23.UseVisualStyleBackColor = false;
            this.btnDO23.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO22
            // 
            this.btnDO22.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO22.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO22.ImageIndex = 0;
            this.btnDO22.ImageList = this.imglistDO;
            this.btnDO22.Location = new System.Drawing.Point(381, 96);
            this.btnDO22.Name = "btnDO22";
            this.btnDO22.Size = new System.Drawing.Size(68, 32);
            this.btnDO22.TabIndex = 102;
            this.btnDO22.Tag = "22";
            this.btnDO22.Text = " DO22";
            this.btnDO22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO22.UseVisualStyleBackColor = false;
            this.btnDO22.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO21
            // 
            this.btnDO21.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO21.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO21.ImageIndex = 0;
            this.btnDO21.ImageList = this.imglistDO;
            this.btnDO21.Location = new System.Drawing.Point(307, 96);
            this.btnDO21.Name = "btnDO21";
            this.btnDO21.Size = new System.Drawing.Size(68, 32);
            this.btnDO21.TabIndex = 101;
            this.btnDO21.Tag = "21";
            this.btnDO21.Text = " DO21";
            this.btnDO21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO21.UseVisualStyleBackColor = false;
            this.btnDO21.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO20
            // 
            this.btnDO20.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO20.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO20.ImageIndex = 0;
            this.btnDO20.ImageList = this.imglistDO;
            this.btnDO20.Location = new System.Drawing.Point(233, 96);
            this.btnDO20.Name = "btnDO20";
            this.btnDO20.Size = new System.Drawing.Size(68, 32);
            this.btnDO20.TabIndex = 100;
            this.btnDO20.Tag = "20";
            this.btnDO20.Text = " DO20";
            this.btnDO20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO20.UseVisualStyleBackColor = false;
            this.btnDO20.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO19
            // 
            this.btnDO19.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO19.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO19.ImageIndex = 0;
            this.btnDO19.ImageList = this.imglistDO;
            this.btnDO19.Location = new System.Drawing.Point(159, 96);
            this.btnDO19.Name = "btnDO19";
            this.btnDO19.Size = new System.Drawing.Size(68, 32);
            this.btnDO19.TabIndex = 99;
            this.btnDO19.Tag = "19";
            this.btnDO19.Text = " DO19";
            this.btnDO19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO19.UseVisualStyleBackColor = false;
            this.btnDO19.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO18
            // 
            this.btnDO18.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO18.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO18.ImageIndex = 0;
            this.btnDO18.ImageList = this.imglistDO;
            this.btnDO18.Location = new System.Drawing.Point(85, 96);
            this.btnDO18.Name = "btnDO18";
            this.btnDO18.Size = new System.Drawing.Size(68, 32);
            this.btnDO18.TabIndex = 98;
            this.btnDO18.Tag = "18";
            this.btnDO18.Text = " DO18";
            this.btnDO18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO18.UseVisualStyleBackColor = false;
            this.btnDO18.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO17
            // 
            this.btnDO17.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO17.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO17.ImageIndex = 0;
            this.btnDO17.ImageList = this.imglistDO;
            this.btnDO17.Location = new System.Drawing.Point(11, 96);
            this.btnDO17.Name = "btnDO17";
            this.btnDO17.Size = new System.Drawing.Size(68, 32);
            this.btnDO17.TabIndex = 97;
            this.btnDO17.Tag = "17";
            this.btnDO17.Text = " DO17";
            this.btnDO17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO17.UseVisualStyleBackColor = false;
            this.btnDO17.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO16
            // 
            this.btnDO16.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO16.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO16.ImageIndex = 0;
            this.btnDO16.ImageList = this.imglistDO;
            this.btnDO16.Location = new System.Drawing.Point(529, 58);
            this.btnDO16.Name = "btnDO16";
            this.btnDO16.Size = new System.Drawing.Size(68, 32);
            this.btnDO16.TabIndex = 96;
            this.btnDO16.Tag = "16";
            this.btnDO16.Text = " DO16";
            this.btnDO16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO16.UseVisualStyleBackColor = false;
            this.btnDO16.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO15
            // 
            this.btnDO15.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO15.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO15.ImageIndex = 0;
            this.btnDO15.ImageList = this.imglistDO;
            this.btnDO15.Location = new System.Drawing.Point(455, 58);
            this.btnDO15.Name = "btnDO15";
            this.btnDO15.Size = new System.Drawing.Size(68, 32);
            this.btnDO15.TabIndex = 95;
            this.btnDO15.Tag = "15";
            this.btnDO15.Text = " DO15";
            this.btnDO15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO15.UseVisualStyleBackColor = false;
            this.btnDO15.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO14
            // 
            this.btnDO14.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO14.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO14.ImageIndex = 0;
            this.btnDO14.ImageList = this.imglistDO;
            this.btnDO14.Location = new System.Drawing.Point(381, 58);
            this.btnDO14.Name = "btnDO14";
            this.btnDO14.Size = new System.Drawing.Size(68, 32);
            this.btnDO14.TabIndex = 94;
            this.btnDO14.Tag = "14";
            this.btnDO14.Text = " DO14";
            this.btnDO14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO14.UseVisualStyleBackColor = false;
            this.btnDO14.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO13
            // 
            this.btnDO13.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO13.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO13.ImageIndex = 0;
            this.btnDO13.ImageList = this.imglistDO;
            this.btnDO13.Location = new System.Drawing.Point(307, 58);
            this.btnDO13.Name = "btnDO13";
            this.btnDO13.Size = new System.Drawing.Size(68, 32);
            this.btnDO13.TabIndex = 93;
            this.btnDO13.Tag = "13";
            this.btnDO13.Text = " DO13";
            this.btnDO13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO13.UseVisualStyleBackColor = false;
            this.btnDO13.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO12
            // 
            this.btnDO12.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO12.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO12.ImageIndex = 0;
            this.btnDO12.ImageList = this.imglistDO;
            this.btnDO12.Location = new System.Drawing.Point(233, 58);
            this.btnDO12.Name = "btnDO12";
            this.btnDO12.Size = new System.Drawing.Size(68, 32);
            this.btnDO12.TabIndex = 92;
            this.btnDO12.Tag = "12";
            this.btnDO12.Text = " DO12";
            this.btnDO12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO12.UseVisualStyleBackColor = false;
            this.btnDO12.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO11
            // 
            this.btnDO11.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO11.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO11.ImageIndex = 0;
            this.btnDO11.ImageList = this.imglistDO;
            this.btnDO11.Location = new System.Drawing.Point(159, 58);
            this.btnDO11.Name = "btnDO11";
            this.btnDO11.Size = new System.Drawing.Size(68, 32);
            this.btnDO11.TabIndex = 91;
            this.btnDO11.Tag = "11";
            this.btnDO11.Text = " DO11";
            this.btnDO11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO11.UseVisualStyleBackColor = false;
            this.btnDO11.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO10
            // 
            this.btnDO10.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO10.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO10.ImageIndex = 0;
            this.btnDO10.ImageList = this.imglistDO;
            this.btnDO10.Location = new System.Drawing.Point(85, 58);
            this.btnDO10.Name = "btnDO10";
            this.btnDO10.Size = new System.Drawing.Size(68, 32);
            this.btnDO10.TabIndex = 90;
            this.btnDO10.Tag = "10";
            this.btnDO10.Text = " DO10";
            this.btnDO10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO10.UseVisualStyleBackColor = false;
            this.btnDO10.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO9
            // 
            this.btnDO9.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO9.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO9.ImageIndex = 0;
            this.btnDO9.ImageList = this.imglistDO;
            this.btnDO9.Location = new System.Drawing.Point(11, 58);
            this.btnDO9.Name = "btnDO9";
            this.btnDO9.Size = new System.Drawing.Size(68, 32);
            this.btnDO9.TabIndex = 89;
            this.btnDO9.Tag = "9";
            this.btnDO9.Text = " DO9";
            this.btnDO9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO9.UseVisualStyleBackColor = false;
            this.btnDO9.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO8
            // 
            this.btnDO8.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO8.ImageIndex = 0;
            this.btnDO8.ImageList = this.imglistDO;
            this.btnDO8.Location = new System.Drawing.Point(530, 20);
            this.btnDO8.Name = "btnDO8";
            this.btnDO8.Size = new System.Drawing.Size(68, 32);
            this.btnDO8.TabIndex = 88;
            this.btnDO8.Tag = "8";
            this.btnDO8.Text = " DO8";
            this.btnDO8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO8.UseVisualStyleBackColor = false;
            this.btnDO8.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO7
            // 
            this.btnDO7.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO7.ImageIndex = 0;
            this.btnDO7.ImageList = this.imglistDO;
            this.btnDO7.Location = new System.Drawing.Point(456, 20);
            this.btnDO7.Name = "btnDO7";
            this.btnDO7.Size = new System.Drawing.Size(68, 32);
            this.btnDO7.TabIndex = 87;
            this.btnDO7.Tag = "7";
            this.btnDO7.Text = " DO7";
            this.btnDO7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO7.UseVisualStyleBackColor = false;
            this.btnDO7.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO6
            // 
            this.btnDO6.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO6.ImageIndex = 0;
            this.btnDO6.ImageList = this.imglistDO;
            this.btnDO6.Location = new System.Drawing.Point(382, 20);
            this.btnDO6.Name = "btnDO6";
            this.btnDO6.Size = new System.Drawing.Size(68, 32);
            this.btnDO6.TabIndex = 86;
            this.btnDO6.Tag = "6";
            this.btnDO6.Text = " DO6";
            this.btnDO6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO6.UseVisualStyleBackColor = false;
            this.btnDO6.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO5
            // 
            this.btnDO5.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO5.ImageIndex = 0;
            this.btnDO5.ImageList = this.imglistDO;
            this.btnDO5.Location = new System.Drawing.Point(308, 20);
            this.btnDO5.Name = "btnDO5";
            this.btnDO5.Size = new System.Drawing.Size(68, 32);
            this.btnDO5.TabIndex = 85;
            this.btnDO5.Tag = "5";
            this.btnDO5.Text = " DO5";
            this.btnDO5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO5.UseVisualStyleBackColor = false;
            this.btnDO5.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO4
            // 
            this.btnDO4.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO4.ImageIndex = 0;
            this.btnDO4.ImageList = this.imglistDO;
            this.btnDO4.Location = new System.Drawing.Point(234, 20);
            this.btnDO4.Name = "btnDO4";
            this.btnDO4.Size = new System.Drawing.Size(68, 32);
            this.btnDO4.TabIndex = 84;
            this.btnDO4.Tag = "4";
            this.btnDO4.Text = " DO4";
            this.btnDO4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO4.UseVisualStyleBackColor = false;
            this.btnDO4.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO3
            // 
            this.btnDO3.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO3.ImageIndex = 0;
            this.btnDO3.ImageList = this.imglistDO;
            this.btnDO3.Location = new System.Drawing.Point(160, 20);
            this.btnDO3.Name = "btnDO3";
            this.btnDO3.Size = new System.Drawing.Size(68, 32);
            this.btnDO3.TabIndex = 83;
            this.btnDO3.Tag = "3";
            this.btnDO3.Text = " DO3";
            this.btnDO3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO3.UseVisualStyleBackColor = false;
            this.btnDO3.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // btnDO2
            // 
            this.btnDO2.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO2.ImageIndex = 0;
            this.btnDO2.ImageList = this.imglistDO;
            this.btnDO2.Location = new System.Drawing.Point(86, 20);
            this.btnDO2.Name = "btnDO2";
            this.btnDO2.Size = new System.Drawing.Size(68, 32);
            this.btnDO2.TabIndex = 82;
            this.btnDO2.Tag = "2";
            this.btnDO2.Text = " DO2";
            this.btnDO2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO2.UseVisualStyleBackColor = false;
            this.btnDO2.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnCloseAll);
            this.groupBox4.Controls.Add(this.txtInterval);
            this.groupBox4.Controls.Add(this.btnDIRead);
            this.groupBox4.Controls.Add(this.btnOpenAll);
            this.groupBox4.Controls.Add(this.btnLed2);
            this.groupBox4.Controls.Add(this.btnLed1);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox4.Location = new System.Drawing.Point(3, 173);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(614, 67);
            this.groupBox4.TabIndex = 81;
            this.groupBox4.TabStop = false;
            // 
            // btnCloseAll
            // 
            this.btnCloseAll.BackColor = System.Drawing.SystemColors.Control;
            this.btnCloseAll.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCloseAll.ImageKey = "comclosed.ico";
            this.btnCloseAll.ImageList = this.imglistDO;
            this.btnCloseAll.Location = new System.Drawing.Point(9, 20);
            this.btnCloseAll.Name = "btnCloseAll";
            this.btnCloseAll.Size = new System.Drawing.Size(100, 35);
            this.btnCloseAll.TabIndex = 38;
            this.btnCloseAll.Tag = "1";
            this.btnCloseAll.Text = "  关闭全部";
            this.btnCloseAll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCloseAll.UseVisualStyleBackColor = false;
            this.btnCloseAll.Click += new System.EventHandler(this.btnCloseAll_Click);
            // 
            // txtInterval
            // 
            this.txtInterval.Location = new System.Drawing.Point(516, 28);
            this.txtInterval.Name = "txtInterval";
            this.txtInterval.Size = new System.Drawing.Size(66, 21);
            this.txtInterval.TabIndex = 79;
            this.txtInterval.Text = "100";
            // 
            // btnDIRead
            // 
            this.btnDIRead.BackColor = System.Drawing.SystemColors.Control;
            this.btnDIRead.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDIRead.ImageKey = "comclosed.ico";
            this.btnDIRead.ImageList = this.imglistDO;
            this.btnDIRead.Location = new System.Drawing.Point(421, 24);
            this.btnDIRead.Name = "btnDIRead";
            this.btnDIRead.Size = new System.Drawing.Size(86, 27);
            this.btnDIRead.TabIndex = 80;
            this.btnDIRead.Tag = "1";
            this.btnDIRead.Text = "连续读";
            this.btnDIRead.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDIRead.UseVisualStyleBackColor = false;
            this.btnDIRead.Click += new System.EventHandler(this.btnDIRead_Click);
            // 
            // btnOpenAll
            // 
            this.btnOpenAll.BackColor = System.Drawing.SystemColors.Control;
            this.btnOpenAll.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnOpenAll.ImageKey = "comopened.ico";
            this.btnOpenAll.ImageList = this.imglistDO;
            this.btnOpenAll.Location = new System.Drawing.Point(115, 21);
            this.btnOpenAll.Name = "btnOpenAll";
            this.btnOpenAll.Size = new System.Drawing.Size(105, 32);
            this.btnOpenAll.TabIndex = 39;
            this.btnOpenAll.Tag = "1";
            this.btnOpenAll.Text = "  打开全部";
            this.btnOpenAll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOpenAll.UseVisualStyleBackColor = false;
            this.btnOpenAll.Click += new System.EventHandler(this.btnOpenAll_Click);
            // 
            // btnLed2
            // 
            this.btnLed2.BackColor = System.Drawing.SystemColors.Control;
            this.btnLed2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLed2.ImageIndex = 0;
            this.btnLed2.ImageList = this.imglistDO;
            this.btnLed2.Location = new System.Drawing.Point(254, 24);
            this.btnLed2.Name = "btnLed2";
            this.btnLed2.Size = new System.Drawing.Size(79, 27);
            this.btnLed2.TabIndex = 70;
            this.btnLed2.Tag = "1";
            this.btnLed2.Text = "跑马灯";
            this.btnLed2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLed2.UseVisualStyleBackColor = false;
            this.btnLed2.Click += new System.EventHandler(this.btnLed2_Click);
            // 
            // btnLed1
            // 
            this.btnLed1.BackColor = System.Drawing.SystemColors.Control;
            this.btnLed1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLed1.ImageKey = "comclosed.ico";
            this.btnLed1.ImageList = this.imglistDO;
            this.btnLed1.Location = new System.Drawing.Point(339, 24);
            this.btnLed1.Name = "btnLed1";
            this.btnLed1.Size = new System.Drawing.Size(76, 27);
            this.btnLed1.TabIndex = 69;
            this.btnLed1.Tag = "1";
            this.btnLed1.Text = "流水灯";
            this.btnLed1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLed1.UseVisualStyleBackColor = false;
            this.btnLed1.Click += new System.EventHandler(this.btnLed1_Click);
            // 
            // btnDO1
            // 
            this.btnDO1.BackColor = System.Drawing.SystemColors.Control;
            this.btnDO1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDO1.ImageIndex = 0;
            this.btnDO1.ImageList = this.imglistDO;
            this.btnDO1.Location = new System.Drawing.Point(12, 20);
            this.btnDO1.Name = "btnDO1";
            this.btnDO1.Size = new System.Drawing.Size(68, 32);
            this.btnDO1.TabIndex = 40;
            this.btnDO1.Tag = "1";
            this.btnDO1.Text = " DO1";
            this.btnDO1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDO1.UseVisualStyleBackColor = false;
            this.btnDO1.Click += new System.EventHandler(this.btnDO_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txtao2);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtwao12);
            this.groupBox1.Controls.Add(this.txtwao2);
            this.groupBox1.Controls.Add(this.txtwao1);
            this.groupBox1.Controls.Add(this.txtao1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtID);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtbaseaddr);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnDI32);
            this.groupBox1.Controls.Add(this.btnDI31);
            this.groupBox1.Controls.Add(this.btnDI30);
            this.groupBox1.Controls.Add(this.btnDI29);
            this.groupBox1.Controls.Add(this.btnDI28);
            this.groupBox1.Controls.Add(this.btnDI27);
            this.groupBox1.Controls.Add(this.btnDI26);
            this.groupBox1.Controls.Add(this.btnDI25);
            this.groupBox1.Controls.Add(this.btnDI24);
            this.groupBox1.Controls.Add(this.btnDI23);
            this.groupBox1.Controls.Add(this.btnDI22);
            this.groupBox1.Controls.Add(this.btnDI21);
            this.groupBox1.Controls.Add(this.btnDI20);
            this.groupBox1.Controls.Add(this.btnDI19);
            this.groupBox1.Controls.Add(this.btnDI18);
            this.groupBox1.Controls.Add(this.btnDI17);
            this.groupBox1.Controls.Add(this.btnDI16);
            this.groupBox1.Controls.Add(this.btnDI15);
            this.groupBox1.Controls.Add(this.btnDI14);
            this.groupBox1.Controls.Add(this.btnDI13);
            this.groupBox1.Controls.Add(this.btnDI12);
            this.groupBox1.Controls.Add(this.btnDI11);
            this.groupBox1.Controls.Add(this.btnDI10);
            this.groupBox1.Controls.Add(this.btnDI9);
            this.groupBox1.Controls.Add(this.btnDI8);
            this.groupBox1.Controls.Add(this.btnDI7);
            this.groupBox1.Controls.Add(this.btnDI6);
            this.groupBox1.Controls.Add(this.btnDI5);
            this.groupBox1.Controls.Add(this.btnDI4);
            this.groupBox1.Controls.Add(this.btnDI3);
            this.groupBox1.Controls.Add(this.btnDI2);
            this.groupBox1.Controls.Add(this.btnDI1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 351);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(620, 269);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DI输入";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(532, 56);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(66, 21);
            this.txtID.TabIndex = 74;
            this.txtID.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(473, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 73;
            this.label7.Text = "产品型号";
            // 
            // txtbaseaddr
            // 
            this.txtbaseaddr.Location = new System.Drawing.Point(532, 83);
            this.txtbaseaddr.Name = "txtbaseaddr";
            this.txtbaseaddr.ReadOnly = true;
            this.txtbaseaddr.Size = new System.Drawing.Size(66, 21);
            this.txtbaseaddr.TabIndex = 68;
            this.txtbaseaddr.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(473, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 67;
            this.label2.Text = "拨码开关";
            // 
            // btnDI32
            // 
            this.btnDI32.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI32.FlatAppearance.BorderSize = 0;
            this.btnDI32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI32.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI32.ImageIndex = 0;
            this.btnDI32.ImageList = this.imglistDI;
            this.btnDI32.Location = new System.Drawing.Point(410, 203);
            this.btnDI32.Name = "btnDI32";
            this.btnDI32.Size = new System.Drawing.Size(55, 55);
            this.btnDI32.TabIndex = 72;
            this.btnDI32.Tag = "32";
            this.btnDI32.Text = "DI32";
            this.btnDI32.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI32.UseVisualStyleBackColor = true;
            // 
            // btnDI31
            // 
            this.btnDI31.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI31.FlatAppearance.BorderSize = 0;
            this.btnDI31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI31.ImageIndex = 0;
            this.btnDI31.ImageList = this.imglistDI;
            this.btnDI31.Location = new System.Drawing.Point(353, 203);
            this.btnDI31.Name = "btnDI31";
            this.btnDI31.Size = new System.Drawing.Size(55, 55);
            this.btnDI31.TabIndex = 71;
            this.btnDI31.Tag = "31";
            this.btnDI31.Text = "DI31";
            this.btnDI31.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI31.UseVisualStyleBackColor = true;
            // 
            // btnDI30
            // 
            this.btnDI30.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI30.FlatAppearance.BorderSize = 0;
            this.btnDI30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI30.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI30.ImageIndex = 0;
            this.btnDI30.ImageList = this.imglistDI;
            this.btnDI30.Location = new System.Drawing.Point(296, 203);
            this.btnDI30.Name = "btnDI30";
            this.btnDI30.Size = new System.Drawing.Size(55, 55);
            this.btnDI30.TabIndex = 70;
            this.btnDI30.Tag = "30";
            this.btnDI30.Text = "DI30";
            this.btnDI30.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI30.UseVisualStyleBackColor = true;
            // 
            // btnDI29
            // 
            this.btnDI29.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI29.FlatAppearance.BorderSize = 0;
            this.btnDI29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI29.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI29.ImageIndex = 0;
            this.btnDI29.ImageList = this.imglistDI;
            this.btnDI29.Location = new System.Drawing.Point(239, 203);
            this.btnDI29.Name = "btnDI29";
            this.btnDI29.Size = new System.Drawing.Size(55, 55);
            this.btnDI29.TabIndex = 69;
            this.btnDI29.Tag = "29";
            this.btnDI29.Text = "DI29";
            this.btnDI29.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI29.UseVisualStyleBackColor = true;
            // 
            // btnDI28
            // 
            this.btnDI28.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI28.FlatAppearance.BorderSize = 0;
            this.btnDI28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI28.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI28.ImageIndex = 0;
            this.btnDI28.ImageList = this.imglistDI;
            this.btnDI28.Location = new System.Drawing.Point(186, 203);
            this.btnDI28.Name = "btnDI28";
            this.btnDI28.Size = new System.Drawing.Size(55, 55);
            this.btnDI28.TabIndex = 68;
            this.btnDI28.Tag = "28";
            this.btnDI28.Text = "DI28";
            this.btnDI28.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI28.UseVisualStyleBackColor = true;
            // 
            // btnDI27
            // 
            this.btnDI27.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI27.FlatAppearance.BorderSize = 0;
            this.btnDI27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI27.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI27.ImageIndex = 0;
            this.btnDI27.ImageList = this.imglistDI;
            this.btnDI27.Location = new System.Drawing.Point(129, 203);
            this.btnDI27.Name = "btnDI27";
            this.btnDI27.Size = new System.Drawing.Size(55, 55);
            this.btnDI27.TabIndex = 67;
            this.btnDI27.Tag = "27";
            this.btnDI27.Text = "DI27";
            this.btnDI27.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI27.UseVisualStyleBackColor = true;
            // 
            // btnDI26
            // 
            this.btnDI26.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI26.FlatAppearance.BorderSize = 0;
            this.btnDI26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI26.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI26.ImageIndex = 0;
            this.btnDI26.ImageList = this.imglistDI;
            this.btnDI26.Location = new System.Drawing.Point(72, 203);
            this.btnDI26.Name = "btnDI26";
            this.btnDI26.Size = new System.Drawing.Size(55, 55);
            this.btnDI26.TabIndex = 66;
            this.btnDI26.Tag = "26";
            this.btnDI26.Text = "DI26";
            this.btnDI26.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI26.UseVisualStyleBackColor = true;
            // 
            // btnDI25
            // 
            this.btnDI25.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI25.FlatAppearance.BorderSize = 0;
            this.btnDI25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI25.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI25.ImageIndex = 0;
            this.btnDI25.ImageList = this.imglistDI;
            this.btnDI25.Location = new System.Drawing.Point(15, 203);
            this.btnDI25.Name = "btnDI25";
            this.btnDI25.Size = new System.Drawing.Size(55, 55);
            this.btnDI25.TabIndex = 65;
            this.btnDI25.Tag = "25";
            this.btnDI25.Text = "DI25";
            this.btnDI25.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI25.UseVisualStyleBackColor = true;
            // 
            // btnDI24
            // 
            this.btnDI24.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI24.FlatAppearance.BorderSize = 0;
            this.btnDI24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI24.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI24.ImageIndex = 0;
            this.btnDI24.ImageList = this.imglistDI;
            this.btnDI24.Location = new System.Drawing.Point(406, 142);
            this.btnDI24.Name = "btnDI24";
            this.btnDI24.Size = new System.Drawing.Size(55, 55);
            this.btnDI24.TabIndex = 64;
            this.btnDI24.Tag = "24";
            this.btnDI24.Text = "DI24";
            this.btnDI24.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI24.UseVisualStyleBackColor = true;
            // 
            // btnDI23
            // 
            this.btnDI23.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI23.FlatAppearance.BorderSize = 0;
            this.btnDI23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI23.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI23.ImageIndex = 0;
            this.btnDI23.ImageList = this.imglistDI;
            this.btnDI23.Location = new System.Drawing.Point(349, 142);
            this.btnDI23.Name = "btnDI23";
            this.btnDI23.Size = new System.Drawing.Size(55, 55);
            this.btnDI23.TabIndex = 63;
            this.btnDI23.Tag = "23";
            this.btnDI23.Text = "DI23";
            this.btnDI23.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI23.UseVisualStyleBackColor = true;
            // 
            // btnDI22
            // 
            this.btnDI22.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI22.FlatAppearance.BorderSize = 0;
            this.btnDI22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI22.ImageIndex = 0;
            this.btnDI22.ImageList = this.imglistDI;
            this.btnDI22.Location = new System.Drawing.Point(292, 142);
            this.btnDI22.Name = "btnDI22";
            this.btnDI22.Size = new System.Drawing.Size(55, 55);
            this.btnDI22.TabIndex = 62;
            this.btnDI22.Tag = "22";
            this.btnDI22.Text = "DI22";
            this.btnDI22.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI22.UseVisualStyleBackColor = true;
            // 
            // btnDI21
            // 
            this.btnDI21.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI21.FlatAppearance.BorderSize = 0;
            this.btnDI21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI21.ImageIndex = 0;
            this.btnDI21.ImageList = this.imglistDI;
            this.btnDI21.Location = new System.Drawing.Point(235, 142);
            this.btnDI21.Name = "btnDI21";
            this.btnDI21.Size = new System.Drawing.Size(55, 55);
            this.btnDI21.TabIndex = 61;
            this.btnDI21.Tag = "21";
            this.btnDI21.Text = "DI21";
            this.btnDI21.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI21.UseVisualStyleBackColor = true;
            // 
            // btnDI20
            // 
            this.btnDI20.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI20.FlatAppearance.BorderSize = 0;
            this.btnDI20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI20.ImageIndex = 0;
            this.btnDI20.ImageList = this.imglistDI;
            this.btnDI20.Location = new System.Drawing.Point(182, 142);
            this.btnDI20.Name = "btnDI20";
            this.btnDI20.Size = new System.Drawing.Size(55, 55);
            this.btnDI20.TabIndex = 60;
            this.btnDI20.Tag = "20";
            this.btnDI20.Text = "DI20";
            this.btnDI20.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI20.UseVisualStyleBackColor = true;
            // 
            // btnDI19
            // 
            this.btnDI19.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI19.FlatAppearance.BorderSize = 0;
            this.btnDI19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI19.ImageIndex = 0;
            this.btnDI19.ImageList = this.imglistDI;
            this.btnDI19.Location = new System.Drawing.Point(125, 142);
            this.btnDI19.Name = "btnDI19";
            this.btnDI19.Size = new System.Drawing.Size(55, 55);
            this.btnDI19.TabIndex = 59;
            this.btnDI19.Tag = "19";
            this.btnDI19.Text = "DI19";
            this.btnDI19.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI19.UseVisualStyleBackColor = true;
            // 
            // btnDI18
            // 
            this.btnDI18.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI18.FlatAppearance.BorderSize = 0;
            this.btnDI18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI18.ImageIndex = 0;
            this.btnDI18.ImageList = this.imglistDI;
            this.btnDI18.Location = new System.Drawing.Point(68, 142);
            this.btnDI18.Name = "btnDI18";
            this.btnDI18.Size = new System.Drawing.Size(55, 55);
            this.btnDI18.TabIndex = 58;
            this.btnDI18.Tag = "18";
            this.btnDI18.Text = "DI18";
            this.btnDI18.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI18.UseVisualStyleBackColor = true;
            // 
            // btnDI17
            // 
            this.btnDI17.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI17.FlatAppearance.BorderSize = 0;
            this.btnDI17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI17.ImageIndex = 0;
            this.btnDI17.ImageList = this.imglistDI;
            this.btnDI17.Location = new System.Drawing.Point(11, 142);
            this.btnDI17.Name = "btnDI17";
            this.btnDI17.Size = new System.Drawing.Size(55, 55);
            this.btnDI17.TabIndex = 57;
            this.btnDI17.Tag = "17";
            this.btnDI17.Text = "DI17";
            this.btnDI17.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI17.UseVisualStyleBackColor = true;
            // 
            // btnDI16
            // 
            this.btnDI16.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI16.FlatAppearance.BorderSize = 0;
            this.btnDI16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI16.ImageIndex = 0;
            this.btnDI16.ImageList = this.imglistDI;
            this.btnDI16.Location = new System.Drawing.Point(410, 81);
            this.btnDI16.Name = "btnDI16";
            this.btnDI16.Size = new System.Drawing.Size(55, 55);
            this.btnDI16.TabIndex = 56;
            this.btnDI16.Tag = "16";
            this.btnDI16.Text = "DI16";
            this.btnDI16.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI16.UseVisualStyleBackColor = true;
            // 
            // btnDI15
            // 
            this.btnDI15.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI15.FlatAppearance.BorderSize = 0;
            this.btnDI15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI15.ImageIndex = 0;
            this.btnDI15.ImageList = this.imglistDI;
            this.btnDI15.Location = new System.Drawing.Point(353, 81);
            this.btnDI15.Name = "btnDI15";
            this.btnDI15.Size = new System.Drawing.Size(55, 55);
            this.btnDI15.TabIndex = 55;
            this.btnDI15.Tag = "15";
            this.btnDI15.Text = "DI15";
            this.btnDI15.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI15.UseVisualStyleBackColor = true;
            // 
            // btnDI14
            // 
            this.btnDI14.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI14.FlatAppearance.BorderSize = 0;
            this.btnDI14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI14.ImageIndex = 0;
            this.btnDI14.ImageList = this.imglistDI;
            this.btnDI14.Location = new System.Drawing.Point(296, 81);
            this.btnDI14.Name = "btnDI14";
            this.btnDI14.Size = new System.Drawing.Size(55, 55);
            this.btnDI14.TabIndex = 54;
            this.btnDI14.Tag = "14";
            this.btnDI14.Text = "DI14";
            this.btnDI14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI14.UseVisualStyleBackColor = true;
            // 
            // btnDI13
            // 
            this.btnDI13.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI13.FlatAppearance.BorderSize = 0;
            this.btnDI13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI13.ImageIndex = 0;
            this.btnDI13.ImageList = this.imglistDI;
            this.btnDI13.Location = new System.Drawing.Point(239, 81);
            this.btnDI13.Name = "btnDI13";
            this.btnDI13.Size = new System.Drawing.Size(55, 55);
            this.btnDI13.TabIndex = 53;
            this.btnDI13.Tag = "13";
            this.btnDI13.Text = "DI13";
            this.btnDI13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI13.UseVisualStyleBackColor = true;
            // 
            // btnDI12
            // 
            this.btnDI12.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI12.FlatAppearance.BorderSize = 0;
            this.btnDI12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI12.ImageIndex = 0;
            this.btnDI12.ImageList = this.imglistDI;
            this.btnDI12.Location = new System.Drawing.Point(179, 81);
            this.btnDI12.Name = "btnDI12";
            this.btnDI12.Size = new System.Drawing.Size(55, 55);
            this.btnDI12.TabIndex = 52;
            this.btnDI12.Tag = "12";
            this.btnDI12.Text = "DI12";
            this.btnDI12.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI12.UseVisualStyleBackColor = true;
            // 
            // btnDI11
            // 
            this.btnDI11.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI11.FlatAppearance.BorderSize = 0;
            this.btnDI11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI11.ImageIndex = 0;
            this.btnDI11.ImageList = this.imglistDI;
            this.btnDI11.Location = new System.Drawing.Point(122, 81);
            this.btnDI11.Name = "btnDI11";
            this.btnDI11.Size = new System.Drawing.Size(55, 55);
            this.btnDI11.TabIndex = 51;
            this.btnDI11.Tag = "11";
            this.btnDI11.Text = "DI11";
            this.btnDI11.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI11.UseVisualStyleBackColor = true;
            // 
            // btnDI10
            // 
            this.btnDI10.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI10.FlatAppearance.BorderSize = 0;
            this.btnDI10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI10.ImageIndex = 0;
            this.btnDI10.ImageList = this.imglistDI;
            this.btnDI10.Location = new System.Drawing.Point(63, 81);
            this.btnDI10.Name = "btnDI10";
            this.btnDI10.Size = new System.Drawing.Size(55, 55);
            this.btnDI10.TabIndex = 50;
            this.btnDI10.Tag = "10";
            this.btnDI10.Text = "DI10";
            this.btnDI10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI10.UseVisualStyleBackColor = true;
            // 
            // btnDI9
            // 
            this.btnDI9.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI9.FlatAppearance.BorderSize = 0;
            this.btnDI9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI9.ImageIndex = 0;
            this.btnDI9.ImageList = this.imglistDI;
            this.btnDI9.Location = new System.Drawing.Point(6, 81);
            this.btnDI9.Name = "btnDI9";
            this.btnDI9.Size = new System.Drawing.Size(55, 55);
            this.btnDI9.TabIndex = 49;
            this.btnDI9.Tag = "9";
            this.btnDI9.Text = "DI9";
            this.btnDI9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI9.UseVisualStyleBackColor = true;
            // 
            // btnDI8
            // 
            this.btnDI8.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI8.FlatAppearance.BorderSize = 0;
            this.btnDI8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI8.ImageIndex = 0;
            this.btnDI8.ImageList = this.imglistDI;
            this.btnDI8.Location = new System.Drawing.Point(405, 20);
            this.btnDI8.Name = "btnDI8";
            this.btnDI8.Size = new System.Drawing.Size(55, 55);
            this.btnDI8.TabIndex = 48;
            this.btnDI8.Tag = "8";
            this.btnDI8.Text = "DI8";
            this.btnDI8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI8.UseVisualStyleBackColor = true;
            // 
            // btnDI7
            // 
            this.btnDI7.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI7.FlatAppearance.BorderSize = 0;
            this.btnDI7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI7.ImageIndex = 0;
            this.btnDI7.ImageList = this.imglistDI;
            this.btnDI7.Location = new System.Drawing.Point(348, 20);
            this.btnDI7.Name = "btnDI7";
            this.btnDI7.Size = new System.Drawing.Size(55, 55);
            this.btnDI7.TabIndex = 47;
            this.btnDI7.Tag = "7";
            this.btnDI7.Text = "DI7";
            this.btnDI7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI7.UseVisualStyleBackColor = true;
            // 
            // btnDI6
            // 
            this.btnDI6.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI6.FlatAppearance.BorderSize = 0;
            this.btnDI6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI6.ImageIndex = 0;
            this.btnDI6.ImageList = this.imglistDI;
            this.btnDI6.Location = new System.Drawing.Point(291, 20);
            this.btnDI6.Name = "btnDI6";
            this.btnDI6.Size = new System.Drawing.Size(55, 55);
            this.btnDI6.TabIndex = 46;
            this.btnDI6.Tag = "6";
            this.btnDI6.Text = "DI6";
            this.btnDI6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI6.UseVisualStyleBackColor = true;
            // 
            // btnDI5
            // 
            this.btnDI5.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI5.FlatAppearance.BorderSize = 0;
            this.btnDI5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI5.ImageIndex = 0;
            this.btnDI5.ImageList = this.imglistDI;
            this.btnDI5.Location = new System.Drawing.Point(234, 20);
            this.btnDI5.Name = "btnDI5";
            this.btnDI5.Size = new System.Drawing.Size(55, 55);
            this.btnDI5.TabIndex = 45;
            this.btnDI5.Tag = "5";
            this.btnDI5.Text = "DI5";
            this.btnDI5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI5.UseVisualStyleBackColor = true;
            // 
            // btnDI4
            // 
            this.btnDI4.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI4.FlatAppearance.BorderSize = 0;
            this.btnDI4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI4.ImageIndex = 0;
            this.btnDI4.ImageList = this.imglistDI;
            this.btnDI4.Location = new System.Drawing.Point(177, 20);
            this.btnDI4.Name = "btnDI4";
            this.btnDI4.Size = new System.Drawing.Size(55, 55);
            this.btnDI4.TabIndex = 44;
            this.btnDI4.Tag = "4";
            this.btnDI4.Text = "DI4";
            this.btnDI4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI4.UseVisualStyleBackColor = true;
            // 
            // btnDI3
            // 
            this.btnDI3.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI3.FlatAppearance.BorderSize = 0;
            this.btnDI3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI3.ImageIndex = 0;
            this.btnDI3.ImageList = this.imglistDI;
            this.btnDI3.Location = new System.Drawing.Point(120, 20);
            this.btnDI3.Name = "btnDI3";
            this.btnDI3.Size = new System.Drawing.Size(55, 55);
            this.btnDI3.TabIndex = 43;
            this.btnDI3.Tag = "3";
            this.btnDI3.Text = "DI3";
            this.btnDI3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI3.UseVisualStyleBackColor = true;
            // 
            // btnDI2
            // 
            this.btnDI2.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI2.FlatAppearance.BorderSize = 0;
            this.btnDI2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI2.ImageIndex = 0;
            this.btnDI2.ImageList = this.imglistDI;
            this.btnDI2.Location = new System.Drawing.Point(63, 20);
            this.btnDI2.Name = "btnDI2";
            this.btnDI2.Size = new System.Drawing.Size(55, 55);
            this.btnDI2.TabIndex = 42;
            this.btnDI2.Tag = "2";
            this.btnDI2.Text = "DI2";
            this.btnDI2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI2.UseVisualStyleBackColor = true;
            // 
            // btnDI1
            // 
            this.btnDI1.BackColor = System.Drawing.SystemColors.Control;
            this.btnDI1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDI1.FlatAppearance.BorderSize = 0;
            this.btnDI1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDI1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDI1.ImageIndex = 0;
            this.btnDI1.ImageList = this.imglistDI;
            this.btnDI1.Location = new System.Drawing.Point(6, 20);
            this.btnDI1.Name = "btnDI1";
            this.btnDI1.Size = new System.Drawing.Size(55, 55);
            this.btnDI1.TabIndex = 41;
            this.btnDI1.Tag = "1";
            this.btnDI1.Text = "DI1";
            this.btnDI1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDI1.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // txtBoxRcv
            // 
            this.txtBoxRcv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBoxRcv.Location = new System.Drawing.Point(0, 0);
            this.txtBoxRcv.Name = "txtBoxRcv";
            this.txtBoxRcv.Size = new System.Drawing.Size(324, 631);
            this.txtBoxRcv.TabIndex = 81;
            this.txtBoxRcv.Text = "";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox2);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox3);
            this.splitContainer1.Panel1MinSize = 620;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.txtBoxRcv);
            this.splitContainer1.Size = new System.Drawing.Size(948, 631);
            this.splitContainer1.SplitterDistance = 620;
            this.splitContainer1.TabIndex = 82;
            // 
            // txtao2
            // 
            this.txtao2.Location = new System.Drawing.Point(532, 142);
            this.txtao2.Name = "txtao2";
            this.txtao2.Size = new System.Drawing.Size(66, 21);
            this.txtao2.TabIndex = 92;
            this.txtao2.Text = "2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(479, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 12);
            this.label10.TabIndex = 91;
            this.label10.Text = "AO1";
            // 
            // txtwao12
            // 
            this.txtwao12.Location = new System.Drawing.Point(474, 238);
            this.txtwao12.Name = "txtwao12";
            this.txtwao12.Size = new System.Drawing.Size(132, 23);
            this.txtwao12.TabIndex = 90;
            this.txtwao12.Text = "写入AO1 AO2";
            this.txtwao12.UseVisualStyleBackColor = true;
            this.txtwao12.Click += new System.EventHandler(this.txtwao12_Click);
            // 
            // txtwao2
            // 
            this.txtwao2.Location = new System.Drawing.Point(533, 208);
            this.txtwao2.Name = "txtwao2";
            this.txtwao2.Size = new System.Drawing.Size(75, 23);
            this.txtwao2.TabIndex = 89;
            this.txtwao2.Text = "写入AO2";
            this.txtwao2.UseVisualStyleBackColor = true;
            this.txtwao2.Click += new System.EventHandler(this.txtwao2_Click);
            // 
            // txtwao1
            // 
            this.txtwao1.Location = new System.Drawing.Point(532, 176);
            this.txtwao1.Name = "txtwao1";
            this.txtwao1.Size = new System.Drawing.Size(75, 23);
            this.txtwao1.TabIndex = 88;
            this.txtwao1.Text = "写入AO1";
            this.txtwao1.UseVisualStyleBackColor = true;
            this.txtwao1.Click += new System.EventHandler(this.txtwao1_Click);
            // 
            // txtao1
            // 
            this.txtao1.Location = new System.Drawing.Point(532, 115);
            this.txtao1.Name = "txtao1";
            this.txtao1.Size = new System.Drawing.Size(66, 21);
            this.txtao1.TabIndex = 87;
            this.txtao1.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(479, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 12);
            this.label9.TabIndex = 86;
            this.label9.Text = "AO1";
            // 
            // Frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(948, 631);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Frmmain";
            this.Text = "TCP/IP 客户端调试  20161216";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Frmmain_FormClosing);
            this.Load += new System.EventHandler(this.Frmmain_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnopen;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtDONum;
        private System.Windows.Forms.ImageList imglistDO;
        private System.Windows.Forms.ImageList imglistDI;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnDO1;
        private System.Windows.Forms.Button btnOpenAll;
        private System.Windows.Forms.Button btnCloseAll;
        public System.Windows.Forms.TextBox txtDINum;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDI20;
        private System.Windows.Forms.Button btnDI19;
        private System.Windows.Forms.Button btnDI18;
        private System.Windows.Forms.Button btnDI17;
        private System.Windows.Forms.Button btnDI16;
        private System.Windows.Forms.Button btnDI15;
        private System.Windows.Forms.Button btnDI14;
        private System.Windows.Forms.Button btnDI13;
        private System.Windows.Forms.Button btnDI12;
        private System.Windows.Forms.Button btnDI11;
        private System.Windows.Forms.Button btnDI10;
        private System.Windows.Forms.Button btnDI9;
        private System.Windows.Forms.Button btnDI8;
        private System.Windows.Forms.Button btnDI7;
        private System.Windows.Forms.Button btnDI6;
        private System.Windows.Forms.Button btnDI5;
        private System.Windows.Forms.Button btnDI4;
        private System.Windows.Forms.Button btnDI3;
        private System.Windows.Forms.Button btnDI2;
        private System.Windows.Forms.Button btnDI1;
        public System.Windows.Forms.TextBox txtaddr;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnReadDI;
        private System.Windows.Forms.Button btnReadDO;
        private System.Windows.Forms.Button btnLed1;
        private System.Windows.Forms.Button btnLed2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnDI24;
        private System.Windows.Forms.Button btnDI23;
        private System.Windows.Forms.Button btnDI22;
        private System.Windows.Forms.Button btnDI21;
        public System.Windows.Forms.TextBox txtInterval;
        private System.Windows.Forms.Button btnDIRead;
        private System.Windows.Forms.RichTextBox txtBoxRcv;
        private System.Windows.Forms.ComboBox cbxBaudRate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbxPortNum;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnDO8;
        private System.Windows.Forms.Button btnDO7;
        private System.Windows.Forms.Button btnDO6;
        private System.Windows.Forms.Button btnDO5;
        private System.Windows.Forms.Button btnDO4;
        private System.Windows.Forms.Button btnDO3;
        private System.Windows.Forms.Button btnDO2;
        private System.Windows.Forms.Button btnDI32;
        private System.Windows.Forms.Button btnDI31;
        private System.Windows.Forms.Button btnDI30;
        private System.Windows.Forms.Button btnDI29;
        private System.Windows.Forms.Button btnDI28;
        private System.Windows.Forms.Button btnDI27;
        private System.Windows.Forms.Button btnDI26;
        private System.Windows.Forms.Button btnDI25;
        private System.Windows.Forms.Button btnDO32;
        private System.Windows.Forms.Button btnDO31;
        private System.Windows.Forms.Button btnDO30;
        private System.Windows.Forms.Button btnDO29;
        private System.Windows.Forms.Button btnDO28;
        private System.Windows.Forms.Button btnDO27;
        private System.Windows.Forms.Button btnDO26;
        private System.Windows.Forms.Button btnDO25;
        private System.Windows.Forms.Button btnDO24;
        private System.Windows.Forms.Button btnDO23;
        private System.Windows.Forms.Button btnDO22;
        private System.Windows.Forms.Button btnDO21;
        private System.Windows.Forms.Button btnDO20;
        private System.Windows.Forms.Button btnDO19;
        private System.Windows.Forms.Button btnDO18;
        private System.Windows.Forms.Button btnDO17;
        private System.Windows.Forms.Button btnDO16;
        private System.Windows.Forms.Button btnDO15;
        private System.Windows.Forms.Button btnDO14;
        private System.Windows.Forms.Button btnDO13;
        private System.Windows.Forms.Button btnDO12;
        private System.Windows.Forms.Button btnDO11;
        private System.Windows.Forms.Button btnDO10;
        private System.Windows.Forms.Button btnDO9;
        public System.Windows.Forms.TextBox txtbaseaddr;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox txtAINum;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.TextBox txtao2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button txtwao12;
        private System.Windows.Forms.Button txtwao2;
        private System.Windows.Forms.Button txtwao1;
        public System.Windows.Forms.TextBox txtao1;
        private System.Windows.Forms.Label label9;
    }
}

