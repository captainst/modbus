// vc_demoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "vc_demo.h"
#include "vc_demoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
CComboBox* m_port;
CComboBox* m_node;
CComboBox* m_baud;

CEdit* m_user;
CEdit* m_Bitaddr;
CEdit* m_Bitvalue;

CEdit* m_read[10];
CEdit* m_write[10];

int mnport,mnode,WritePlc,Readtrue;

HINSTANCE hinstDLL; 

//���ڿ��ƺ���
typedef int (_stdcall *pOpen)(int nport, int BaudRate, int DataBits, char* Parity, int StopBits, char* User); 
typedef int (_stdcall *pClose)(int nport);
typedef int (_stdcall *pSetDelay)(int value);
typedef int (_stdcall *pComTrue)(int nport);
typedef int (_stdcall *pComWork)(int nport);

//��׼modbus����
typedef int (_stdcall *pfcn01)(int nport, int node, int address, int Count,int* RxdBuffer);
typedef int (_stdcall *pfcn02)(int nport, int node, int address, int Count,int* RxdBuffer);
typedef int (_stdcall *pfcn03)(int nport, int node, int address, int Count,int* RxdBuffer);
typedef int (_stdcall *pfcn04)(int nport, int node, int address, int Count,int* RxdBuffer);
typedef int (_stdcall *pfcn05)(int nport, int node, int address, int value);
typedef int (_stdcall *pfcn06)(int nport, int node, int address, int value);
typedef int (_stdcall *pfcn15)(int nport, int node, int address, int Count,int* TxdBuffer);
typedef int (_stdcall *pfcn16)(int nport, int node, int address, int Count,int* TxdBuffer);

//����modbus����
typedef int (_stdcall *pfcn03DInt)(int nport, int node,  int regular, int address, int Count,int* RxdBuffer);
typedef int (_stdcall *pfcn03Float)(int nport, int node,  int regular, int address, int Count,float* RxdBuffer);
typedef int (_stdcall *pfcn04DInt)(int nport, int node,  int regular, int address, int Count,int* RxdBuffer);
typedef int (_stdcall *pfcn04Float)(int nport, int node,  int regular, int address, int Count,float* RxdBuffer);
typedef int (_stdcall *pfcn16DInt)(int nport, int node, int regular, int address, int Count,int* TxdBuffer);
typedef int (_stdcall *pfcn16Float)(int nport, int node, int regular, int address, int Count,float* TxdBuffer);
typedef int (_stdcall *pWbitWrite)(int nport, int node, int address, int Bit, int value);
typedef int (_stdcall *pWbitSetReset)(int nport, int node, int address, int Bit);

//��϶�дʱ�����������չ����
typedef int (_stdcall *pBitBin)(int value, int Bitaddress);
typedef int (_stdcall *p32I_16h)(int value);
typedef int (_stdcall *p32I_16l)(int value);
typedef int (_stdcall *p16I_32I)(int valueH, int valueL);
typedef int (_stdcall *p32f_16h)(float value);
typedef int (_stdcall *p32f_16l)(float value);
typedef float (_stdcall *p16I_32f)(int valueH, int valueL);

pOpen mOpen; 
pClose mClose;
pSetDelay mSetDelay;
pComTrue mComTrue;
pComWork mComWork;

pfcn01 mfcn01;
pfcn02 mfcn02;
pfcn03 mfcn03;
pfcn04 mfcn04;
pfcn05 mfcn05;
pfcn06 mfcn06;
pfcn15 mfcn15;
pfcn16 mfcn16;

pfcn03DInt mfcn03DInt;
pfcn03Float mfcn03Float;
pfcn04DInt mfcn04DInt;
pfcn04Float mfcn04Float;
pfcn16DInt mfcn16DInt;
pfcn16Float mfcn16Float;
pWbitWrite mWbitWrite;
pWbitSetReset mWbitSetReset;

pBitBin mBitBin;
p32I_16h m32I_16h;
p32I_16l m32I_16l;
p16I_32I m16I_32I;
p32f_16h m32f_16h;
p32f_16l m32f_16l;
p16I_32f m16I_32f;

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVc_demoDlg dialog

CVc_demoDlg::CVc_demoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVc_demoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVc_demoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVc_demoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVc_demoDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CVc_demoDlg, CDialog)
	//{{AFX_MSG_MAP(CVc_demoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(BtnOpen, OnBtnOpen)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_BN_CLICKED(BtnClose, OnBtnClose)
	ON_BN_CLICKED(BtnRead, OnBtnRead)	
	ON_BN_CLICKED(BtnWrite, OnBtnWrite)	
	ON_BN_CLICKED(BtnSet, OnBtnSet)
	ON_BN_CLICKED(BtnReset, OnBtnReset)
	ON_BN_CLICKED(BtnbitWrite, OnBtnbitWrite)
	ON_WM_CLOSE()
	ON_WM_CANCELMODE()
	ON_WM_CAPTURECHANGED()
	ON_WM_CHAR()
	ON_BN_CLICKED(BtnbitRead, OnBtnbitRead)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVc_demoDlg message handlers

BOOL CVc_demoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	
	//demo�ĳ�ʼ������

	m_port=(CComboBox*)GetDlgItem(Comnoprt);
    m_port->SetCurSel(0);
	m_node=(CComboBox*)GetDlgItem(Comnode);
	m_node->SetCurSel(0);
	m_baud=(CComboBox*)GetDlgItem(CombBaudRate);
    m_baud->SetCurSel(1);
	m_user=(CEdit*)GetDlgItem(EditUesr);
	m_user->SetWindowText("wjun_2008");          //δע���û�ͳһʹ��wjun_2008
	
	m_Bitaddr=(CEdit*)GetDlgItem(EditbitAddr);
	m_Bitaddr->SetWindowText("0");
	m_Bitvalue=(CEdit*)GetDlgItem(EditBitvalue);
	m_Bitvalue->SetWindowText("");	

    m_read[0]=(CEdit*)GetDlgItem(ReadEdit01);
    m_read[1]=(CEdit*)GetDlgItem(ReadEdit02);
	m_read[2]=(CEdit*)GetDlgItem(ReadEdit03);
	m_read[3]=(CEdit*)GetDlgItem(ReadEdit04);
	m_read[4]=(CEdit*)GetDlgItem(ReadEdit05);
	m_read[5]=(CEdit*)GetDlgItem(ReadEdit06);


	m_write[0]=(CEdit*)GetDlgItem(WriteEdit01);
	m_write[1]=(CEdit*)GetDlgItem(WriteEdit02);
	m_write[2]=(CEdit*)GetDlgItem(WriteEdit03);
	m_write[3]=(CEdit*)GetDlgItem(WriteEdit04);
	m_write[4]=(CEdit*)GetDlgItem(WriteEdit05);
	m_write[5]=(CEdit*)GetDlgItem(WriteEdit06);

	m_write[0]->SetWindowText("200");
	m_write[1]->SetWindowText("2000");
	m_write[2]->SetWindowText("6860000");
	m_write[3]->SetWindowText("6888");
	m_write[4]->SetWindowText("8686");
	m_write[5]->SetWindowText("666.366");

	mnport = 1;
	mnode = 0;
    WritePlc = -1;
	Readtrue = -1;
	((CButton *)GetDlgItem(OptionWord01))->SetCheck(TRUE);//ѡ��
	
	hinstDLL = LoadLibrary("modbus_rtu.dll");
    if (hinstDLL)
	{
      mOpen = (pOpen)GetProcAddress (hinstDLL,"mbrtuComOpen");
	  mClose = (pClose)GetProcAddress (hinstDLL,"mbrtuComClose");
      mSetDelay = (pSetDelay)GetProcAddress (hinstDLL,"mbrtuSetDelay");
	  mComTrue = (pComTrue)GetProcAddress (hinstDLL,"mbrtuComTrue");
	  mComWork = (pComWork)GetProcAddress (hinstDLL,"mbrtuComWork");

	  mfcn01 = (pfcn01)GetProcAddress (hinstDLL,"mbrtufcn01");
	  mfcn02 = (pfcn02)GetProcAddress (hinstDLL,"mbrtufcn02");
	  mfcn03 = (pfcn03)GetProcAddress (hinstDLL,"mbrtufcn03");
	  mfcn04 = (pfcn04)GetProcAddress (hinstDLL,"mbrtufcn04");
	  mfcn05 = (pfcn05)GetProcAddress (hinstDLL,"mbrtufcn05");
	  mfcn06 = (pfcn06)GetProcAddress (hinstDLL,"mbrtufcn06");
	  mfcn15 = (pfcn15)GetProcAddress (hinstDLL,"mbrtufcn15");
	  mfcn16 = (pfcn16)GetProcAddress (hinstDLL,"mbrtufcn16");
		  
      mfcn03DInt = (pfcn03DInt)GetProcAddress (hinstDLL,"mbrtufcn03DInt");
	  mfcn03Float = (pfcn03Float)GetProcAddress (hinstDLL,"mbrtufcn03Float");
	  mfcn04DInt = (pfcn04DInt)GetProcAddress (hinstDLL,"mbrtufcn04DInt");
	  mfcn04Float = (pfcn04Float)GetProcAddress (hinstDLL,"mbrtufcn04Float");
	  mfcn16DInt = (pfcn16DInt)GetProcAddress (hinstDLL,"mbrtufcn16DInt");
	  mfcn16Float = (pfcn16Float)GetProcAddress (hinstDLL,"mbrtufcn16Float");
	  mWbitWrite = (pWbitWrite)GetProcAddress (hinstDLL,"mbrtuWordBitWrite");
	  mWbitSetReset = (pWbitSetReset)GetProcAddress (hinstDLL,"mbrtuWordBitSetReset");	 

	  mBitBin = (pBitBin)GetProcAddress (hinstDLL,"DecBitBin");
	  m32I_16h = (p32I_16h)GetProcAddress (hinstDLL,"Int32ToInt_16h");
	  m32I_16l = (p32I_16l)GetProcAddress (hinstDLL,"Int32ToInt_16l");
	  m16I_32I= (p16I_32I)GetProcAddress (hinstDLL,"Int16ToInt32");
	  m32f_16h = (p32f_16h)GetProcAddress (hinstDLL,"Float32ToInt_16h");
	  m32f_16l = (p32f_16l)GetProcAddress (hinstDLL,"Float32ToInt_16l");
	  m16I_32f= (p16I_32f)GetProcAddress (hinstDLL,"Int16ToFloat32");
		
	  AfxMessageBox("modbus_rtu.dll�ѳɹ����룡");
	}
	else
	{
		AfxMessageBox("û�ҵ�modbus_rtu.dll��");
		SendMessage(WM_CLOSE); 
	}
	//

	// TODO: Add extra initialization here	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CVc_demoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CVc_demoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CVc_demoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CVc_demoDlg::OnBtnOpen() 
{
	// TODO: Add your control notification handler code here
	CString strUser;
    CString strParity;
    CString strBaudRate;

  	char* Userchar;
    char* Paritychar;

	mnport = m_port->GetCurSel() +1;    //�����˿ں�
	mnode = m_node->GetCurSel() + 1;    //������վ��

	mSetDelay(32);  //���ô���ͨѶ��ʱʱ�����,����ͨ���������ʵ�ѡ��
	m_user->GetWindowText(strUser);
	strParity = "e";
    m_baud->GetWindowText(strBaudRate);

	Userchar = strUser.GetBuffer(0);
    Paritychar = strParity.GetBuffer(0);

	int BaudRate=atol(strBaudRate.GetBuffer(0));

	int k = mOpen(mnport,BaudRate,8,Paritychar,1,Userchar);
	
	switch (k)
    {
	   case 0:
         AfxMessageBox("modbus rtuЭ��ͨѶDEMO----DLLδע�ᣡ");		 
		 break;  
	   case 1:
         AfxMessageBox("modbus rtuЭ��ͨѶDEMO----DLL��ע�ᣡ");
		 break;  	 
	}

	k = mComTrue(mnport);

	if (k == 1) 

    { 
      m_port->EnableWindow(FALSE);
      m_node->EnableWindow(FALSE);      
	  SetTimer(1,100,NULL);   //�򿪴���ͨ�Ŷ�ʱ��100ms��ʱ
	}

}

void CVc_demoDlg::OnBtnClose() 
{
	// TODO: Add your control notification handler code here
    int k = mComTrue(mnport);

	switch (k)
    {
	   case -1:         
		 AfxMessageBox("modbus rtuЭ��ͨѶDEMO----DLL����δ�򿪣�");
         break;  

	   case 1:
         KillTimer(1);       //�رմ���ͨ�Ŷ�ʱ��
         mClose(mnport);
		 AfxMessageBox("modbus rtuЭ��ͨѶDEMO----DLL���ڹرգ�");
		 m_port->EnableWindow(TRUE);
         m_node->EnableWindow(TRUE);
         break;  	 
	}
	
}

//�����̵Ķ�д��ʽ����������ʾ����ֻҪ����PLC�Ķ���д�����ͬʱ
//����Ӧȷ������ر�ʱ�����ڱ���رղ��������ͷ�DLL

void CVc_demoDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CString Tempstr,readstr;

	int addrI,addrBit,SendDint,k,ReadInt,checkInt;
	short SendInt;
	float Sendfloat,Readfloat;
	int buffer[1024];

	KillTimer(1);       //�رմ���ͨ�Ŷ�ʱ��

	switch (nIDEvent)
	{
      case 1:  ///����IDΪ1�Ķ�ʱ��
        if (WritePlc >= 0)           //ִ��дPLC����
        {
           switch(WritePlc)
           {
             case 0:                      //��ʱ�رճ���
                SendMessage(WM_CLOSE); 
			    break;		    
              case 1:            //���������д��PLC            	
				addrI=0;         //modbus��ַ��40001��ʼ��ƫ�Ƶ�ַ0-7,8���洢��ֵ
				//����ϵ�����ת����16λ����,����
				m_write[0]->GetWindowText(Tempstr);
				SendInt = atoi(Tempstr.GetBuffer(0));
                buffer[0] = SendInt;

				m_write[1]->GetWindowText(Tempstr);
				SendInt = atoi(Tempstr.GetBuffer(0));
                buffer[1] = SendInt;

				m_write[2]->GetWindowText(Tempstr);
				SendDint = atol(Tempstr.GetBuffer(0));
				checkInt = ((CButton *)GetDlgItem(OptionWord01))->GetCheck();
				if (checkInt==1)   //��ͬƷ�Ƶ���λ����˫�ֺ͸�������ݴ洢��������ͬ���и�λ��ǰ�͵�λ��ǰ֮��
                {
                   buffer[2] = m32I_16l(SendDint);
                   buffer[3] = m32I_16h(SendDint);
				}
				else
                {
				   buffer[2] = m32I_16h(SendDint);
                   buffer[3] = m32I_16l(SendDint);
				}                               
				m_write[3]->GetWindowText(Tempstr);
				SendInt = atoi(Tempstr.GetBuffer(0));
                buffer[4] = SendInt;

				m_write[4]->GetWindowText(Tempstr);
				SendInt = atoi(Tempstr.GetBuffer(0));
                buffer[5] = SendInt; 
                
				m_write[5]->GetWindowText(Tempstr);
				Sendfloat = (float)atof(Tempstr.GetBuffer(0));
                if (checkInt==1)   //��ͬƷ�Ƶ���λ����˫�ֺ͸�������ݴ洢��������ͬ���и�λ��ǰ�͵�λ��ǰ֮��
                {
                   buffer[6] = m32f_16l(Sendfloat);
                   buffer[7] = m32f_16h(Sendfloat);  
				}
				else
                {
				   buffer[6] = m32f_16h(Sendfloat);
                   buffer[7] = m32f_16l(Sendfloat);     
				}         
                
				mfcn16(mnport,mnode,addrI,8,&buffer[0]);   //��16λ����д��modbusվ

                WritePlc = -1;
				break;
              case 2:         //�߼���Ȧдֵ                
                m_Bitaddr->GetWindowText(Tempstr);    
				addrI= atoi(Tempstr.GetBuffer(0));                //�߼���Ȧmodbus��ַ��Χ00001~0XXXX �������ð�ƫ�Ƶ�ַ��0��ʼ 
                m_Bitvalue->GetWindowText(Tempstr);  
				SendInt = atoi(Tempstr.GetBuffer(0));             //λֵ��ȡֵ0��1 
                buffer[0] = SendInt;
				mfcn15(mnport,mnode,addrI,1,&buffer[0]); //���߼���Ȧ���ж�λģʽд
				WritePlc = -1;
				break;
              case 3:        //���߼���Ȧ
                m_Bitaddr->GetWindowText(Tempstr);    
				addrI= atoi(Tempstr.GetBuffer(0));                     //�߼���Ȧmodbus��ַ��Χ00001~0XXXX �������ð�ƫ�Ƶ�ַ��0��ʼ
                k = mfcn01(mnport,mnode,addrI,1,&buffer[0]);  
				if (k==1)
				{  
				   readstr.Format("%d",buffer[0]);
                   m_Bitvalue -> SetWindowText(readstr);
				}				
				WritePlc = -1; 
				break;			  
			  case 4:       //�߼���Ȧ��1   
				m_Bitaddr->GetWindowText(Tempstr);    
				addrI= atoi(Tempstr.GetBuffer(0));                //�߼���Ȧmodbus��ַ��Χ00001~0XXXX �������ð�ƫ�Ƶ�ַ��0��ʼ
                mfcn05(mnport,mnode,addrI,1);  
                WritePlc = -1;
				break;
			  case 5:       //�߼���Ȧ��0                   
				m_Bitaddr->GetWindowText(Tempstr);    
				addrI= atoi(Tempstr.GetBuffer(0));                //�߼���Ȧmodbus��ַ��Χ00001~0XXXX �������ð�ƫ�Ƶ�ַ��0��ʼ
                mfcn05(mnport,mnode,addrI,0);  
                WritePlc = -1;
				break;	
		   }               
		} 
		else if (Readtrue > 0)     //ִ��ѭ����ȡ��λ������,��ȡ�������ֵ
		{
           addrI=0;        //modbus��ַ��40001��ʼ��ƫ�Ƶ�ַ0-7,8���洢��ֵ           
          
		   k = mfcn03(mnport,mnode,addrI,8,&buffer[0]);
		   
		   if (k==8)
           {           			   
			 readstr.Format("%d",buffer[0]);
             m_read[0]->SetWindowText(readstr);

			 readstr.Format("%d",buffer[1]);
             m_read[1]->SetWindowText(readstr);

			 checkInt = ((CButton *)GetDlgItem(OptionWord01))->GetCheck();
			 if (checkInt==1)   //��ͬƷ�Ƶ���λ����˫�ֺ͸�������ݴ洢��������ͬ���и�λ��ǰ�͵�λ��ǰ֮��
             {
                ReadInt = m16I_32I(buffer[3],buffer[2]);
			 }
			 else
             {
			    ReadInt = m16I_32I(buffer[2],buffer[3]);	  
			 }  		 

			 readstr.Format("%d",ReadInt);
             m_read[2]->SetWindowText(readstr);

			 readstr.Format("%d",buffer[4]);
             m_read[3]->SetWindowText(readstr);

			 readstr.Format("%d",buffer[5]);
             m_read[4]->SetWindowText(readstr);

			 if (checkInt==1)   //��ͬƷ�Ƶ���λ����˫�ֺ͸�������ݴ洢��������ͬ���и�λ��ǰ�͵�λ��ǰ֮��
             {
                Readfloat = m16I_32f(buffer[7],buffer[6]);
			 }
			 else
             {
			    Readfloat = m16I_32f(buffer[6],buffer[7]);	  
			 }   
		     readstr.Format("%.3f",Readfloat);
             m_read[5]->SetWindowText(readstr);
			
		   }
		}
		SetTimer(1,100,NULL);   //�򿪴���ͨ�Ŷ�ʱ��100ms��ʱ
        break;     
	}


	CDialog::OnTimer(nIDEvent);
}

void CVc_demoDlg::OnDestroy() 
{	
	if(hinstDLL)
	{
      int k = mComTrue(mnport);
	  if (k==1) 
      {
		 mClose(mnport);
	  }		  
	  FreeLibrary(hinstDLL);
	}

	CDialog::OnDestroy();

	// TODO: Add your message handler code here
	
}



void CVc_demoDlg::OnBtnRead() 
{
	// TODO: Add your control notification handler code here
   if (Readtrue > 0) 
   {
	 Readtrue = -1;
	 GetDlgItem(BtnRead)->SetWindowText("��PLCֵ"); 
   }
   else
   {
     Readtrue = 1;
	 GetDlgItem(BtnRead)->SetWindowText("ֹͣ��ֵ"); 
   } 
	
}

void CVc_demoDlg::OnBtnWrite() 
{
	// TODO: Add your control notification handler code here
	int k = mComTrue(mnport);

	if (k==1 && WritePlc<0)
    {
      WritePlc = 1;     //ѡ����PLCд������
	}	
}

void CVc_demoDlg::OnBtnbitWrite() 
{
	// TODO: Add your control notification handler code here

	int k = mComTrue(mnport);

	if (k==1 && WritePlc<0)
    {
      WritePlc = 2;     //ѡ����PLCд������
	}		
}

void CVc_demoDlg::OnBtnbitRead() 
{
	// TODO: Add your control notification handler code here
	int k = mComTrue(mnport);

	if (k==1 && WritePlc<0)
    {
      WritePlc = 3;     //ѡ����PLCд������
	}		
}

void CVc_demoDlg::OnBtnSet() 
{
	// TODO: Add your control notification handler code here
	int k = mComTrue(mnport);

	if (k==1 && WritePlc<0)
    {
      WritePlc = 4;     //ѡ����PLCд������
	}
}

void CVc_demoDlg::OnBtnReset() 
{
	// TODO: Add your control notification handler code here
	int k = mComTrue(mnport);

	if (k==1 && WritePlc<0)
    {
      WritePlc = 5;     //ѡ����PLCд������
	}
}

