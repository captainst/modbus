//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vc_demo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_VC_DEMO_DIALOG              102
#define IDR_MAINFRAME                   128
#define Comnoprt                        1000
#define EditUesr                        1001
#define Comnode                         1002
#define BtnOpen                         1003
#define ReadEdit01                      1004
#define BtnClose                        1005
#define ReadEdit02                      1006
#define ReadEdit03                      1007
#define ReadEdit04                      1008
#define ReadEdit05                      1009
#define ReadEdit06                      1010
#define BtnRead                         1011
#define BtnPro                          1012
#define BtnRun                          1013
#define Btncheck                        1014
#define WriteEdit01                     1015
#define WriteEdit02                     1016
#define WriteEdit03                     1017
#define WriteEdit04                     1018
#define WriteEdit05                     1019
#define WriteEdit06                     1020
#define BtnWrite                        1021
#define Comaddress                      1022
#define EditWaddress                    1023
#define EditbitAddr                     1023
#define EditBaddress                    1024
#define BtnFset                         1025
#define BtnFreset                       1026
#define BtnCancel                       1027
#define BtnSet                          1028
#define BtnReset                        1029
#define plcmode                         1030
#define EditBitvalue                    1030
#define CombBaudRate                    1031
#define IDC_SCROLLBAR1                  1032
#define BtnbitWrite                     1032
#define OptionWord01                    1033
#define OptionWord2                     1034
#define BtnbitRead                      1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
