// xmlapp.cpp: implementation of the xmlapp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "xmlapp.h"
#include "Markup.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXMLApp::CXMLApp()
{

}

CXMLApp::~CXMLApp()
{

}

bool CXMLApp::init()
{
	CString Temp;
	int index = 0;

	for (index = 0; index < EQUIP_MAX_NUM; index++)
	{
		equip[index].init(_T(""), 0, 0, 0, 0);
	}
	index = 0;
	equip[index++].init(_T("DAM0200"), 4, 0, 0, 1);
	equip[index++].init(_T("DAM0400"), 4, 0, 0, 1);
	equip[index++].init(_T("DAM0404"), 4, 4, 0, 1);
	equip[index++].init(_T("DAM0800"), 8, 0, 0, 1);
	equip[index++].init(_T("DAM1600"), 16, 0, 0, 1);
	equip[index++].init(_T("DAM0606"), 6, 6, 0, 1);
	equip[index++].init(_T("USB0100"), 1, 0, 0, 1);
	equip[index++].init(_T("DAM2010"), 0, 20, 10, 1);
	equip[index++].init(_T("DAM1012A"), 10, 0, 12, 1);
	equip[index++].init(_T("DAM1012D"), 10, 12, 0, 1);
	equip[index++].init(_T("DAM10102"), 10, 10, 2, 1);
	equip[index++].init(_T("DAM14142"), 2, 14, 14, 1);	
	equip[index++].init(_T("DO0200"), 2, 0, 0, 1);
	equip[index++].init(_T("PT0030"), 0, 0, 3, 1);
	equip[index++].init(_T("WT0040"), 0, 0, 4, 1);
	equip[index++].init(_T("DAM4100"), 0, 0, 4, 1);
	equip[index++].init(_T("DAM6640"), 6, 4, 6, 1);
	equip[index++].init(_T("DAM6120"), 9, 0, 12, 1);
	//DO0400;DO0800;DO1600;DAM6600;USB0100;DAM2010;DAM1010;DAMDD02;DO0200;DO1012;
	

	for (int index = 0; index < EQUIP_DI_NUM; index++)
	{
		Temp.Format(_T("%d#"), index + 1);
		cdi[index].init(Temp, 0, 1);
	}

	for (int index = 0; index < EQUIP_DO_NUM; index++)
	{
		Temp.Format(_T("�̵���%d"), index + 1);
		cdo[index].init(Temp,0,1);
	}

	for (int index = 0; index < EQUIP_AI_NUM; index++)
	{
		Temp.Format(_T("AI%d"), index + 1);
		cai[index].init(Temp, _T(""),1,0,1);
	}

	cset.comname = _T("COM1");
	cset.baud = _T("9600");
	cset.EquipName = _T("DO0400");
	cset.addr = _T("254");
	return true;
}
bool CXMLApp::CreateXmlFile(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false
	
	
	CMarkup xml;
	xml.SetDoc(__T("<?xml version=\"1.0\"?>\r\n"));
	xml.AddElem(__T("Server"));
	xml.IntoElem();

	xml.AddElem(_T("��˾��Ϣ"));
	xml.AddAttrib(_T("��˾��"), CommpanyName);
	//-------------����������Ϣ
	for (int index = 0; index < EQUIP_MAX_NUM; index++)
	{
		Temp.Format(_T("��Ʒ%d"),index+1);
		xml.AddElem(Temp);
		xml.AddAttrib(_T("����"), equip[index].name);
		xml.AddAttrib(_T("DI"), equip[index].dinum);
		xml.AddAttrib(_T("DO"), equip[index].donum);
		xml.AddAttrib(_T("AI"), equip[index].ainum);
		xml.AddAttrib(_T("��Ч"), equip[index].IsValid);
	}
	xml.OutOfElem();//Point		
	
	xml.Save(methord::GetAppPath()+"\\"+szFileName);
    return true;
}

bool CXMLApp::ReadXmlFile(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false
	
	
	CMarkup xml; 
	if(xml.Load(methord::GetAppPath()+"\\"+szFileName)==false)return false;
	
	xml.ResetMainPos();
	if ( !(xml.FindElem(__T("Server"))) )
	{		
		return false;
	}
    xml.IntoElem();

	if (xml.FindElem(_T("��˾��Ϣ")))
	{
		CommpanyName = xml.GetAttrib(_T("��˾��"));
	}
	
	for (int index = 0; index < EQUIP_MAX_NUM; index++)
	{
		Temp.Format(_T("��Ʒ%d"), index + 1);
		if (xml.FindElem(Temp))
		{			
			equip[index].name = xml.GetAttrib(_T("����"));
			equip[index].dinum = _ttoi(xml.GetAttrib(_T("DI")));
			equip[index].donum = _ttoi(xml.GetAttrib(_T("DO")));
			equip[index].ainum = _ttoi(xml.GetAttrib(_T("AI")));
			equip[index].IsValid = _ttoi(xml.GetAttrib(_T("��Ч")));
		}
	}
	xml.OutOfElem();//
	
    return true;
}



bool CXMLApp::CreateXmlFile2(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false


	CMarkup xml;
	xml.SetDoc(__T("<?xml version=\"1.0\"?>\r\n"));
	xml.AddElem(__T("Server"));
	xml.IntoElem();

	//-------------����������Ϣ
	for (int index = 0; index < EQUIP_DI_NUM; index++)
	{
		Temp.Format(_T("DI%d"), index + 1);
		xml.AddElem(Temp);
		xml.AddAttrib(_T("����"), cdi[index].name);
		xml.AddAttrib(_T("����"), cdi[index].Isdir);
		xml.AddAttrib(_T("��Ч"), cdi[index].IsValid);
	}

	for (int index = 0; index < EQUIP_DO_NUM; index++)
	{
		Temp.Format(_T("DO%d"), index + 1);
		xml.AddElem(Temp);
		xml.AddAttrib(_T("����"), cdo[index].name);
		xml.AddAttrib(_T("����"), cdo[index].Isdir);
		xml.AddAttrib(_T("��Ч"), cdo[index].IsValid);
	}

	for (int index = 0; index < EQUIP_AI_NUM; index++)
	{
		Temp.Format(_T("AI%d"), index + 1);
		xml.AddElem(Temp);
		xml.AddAttrib(_T("����"), cai[index].name);
		xml.AddAttrib(_T("��λ"), cai[index].unit);

		Temp.Format(_T("%f"), cai[index].a);
		xml.AddAttrib(_T("����a"), Temp);
		Temp.Format(_T("%f"), cai[index].b);
		xml.AddAttrib(_T("����b"), Temp);
		xml.AddAttrib(_T("��Ч"), cai[index].IsValid);
	}
	xml.OutOfElem();//Point		

	xml.Save(methord::GetAppPath() + "\\" + szFileName);
	return true;
}

bool CXMLApp::ReadXmlFile2(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false


	CMarkup xml;
	if (xml.Load(methord::GetAppPath() + "\\" + szFileName) == false)return false;

	xml.ResetMainPos();
	if (!(xml.FindElem(__T("Server"))))
	{
		return false;
	}
	xml.IntoElem();

	for (int index = 0; index < EQUIP_DI_NUM; index++)
	{
		Temp.Format(_T("DI%d"), index + 1);
		if (xml.FindElem(Temp))
		{
			cdi[index].name = xml.GetAttrib(_T("����"));
			cdi[index].Isdir = _ttoi(xml.GetAttrib(_T("����")));
			cdi[index].IsValid = _ttoi(xml.GetAttrib(_T("��Ч")));
		}
	}

	for (int index = 0; index < EQUIP_DO_NUM; index++)
	{
		Temp.Format(_T("DO%d"), index + 1);
		if (xml.FindElem(Temp))
		{
			cdo[index].name = xml.GetAttrib(_T("����"));
			cdo[index].Isdir = _ttoi(xml.GetAttrib(_T("����")));
			cdo[index].IsValid = _ttoi(xml.GetAttrib(_T("��Ч")));
		}
	}

	for (int index = 0; index < EQUIP_AI_NUM; index++)
	{
		Temp.Format(_T("AI%d"), index + 1);
		if (xml.FindElem(Temp))
		{
			cai[index].name = xml.GetAttrib(_T("����"));
			cai[index].unit = xml.GetAttrib(_T("��λ"));
			cai[index].a = _ttof(xml.GetAttrib(_T("����a")));
			cai[index].b = _ttof(xml.GetAttrib(_T("����b")));
			cai[index].IsValid = _ttoi(xml.GetAttrib(_T("��Ч")));
		}
	}
	xml.OutOfElem();//

	return true;
}



bool CXMLApp::CreateXmlFile3(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false


	CMarkup xml;
	xml.SetDoc(__T("<?xml version=\"1.0\"?>\r\n"));
	xml.AddElem(__T("Server"));
	xml.IntoElem();

	//-------------����������Ϣ
	xml.AddElem(__T("���ں�"), cset.comname);
	xml.AddElem(__T("������"), cset.baud);
	xml.AddElem(__T("�ͺ�"), cset.EquipName);
	xml.AddElem(__T("��ַ"), cset.addr);
	xml.OutOfElem();//Point		

	xml.Save(methord::GetAppPath() + "\\" + szFileName);
	return true;
}

bool CXMLApp::ReadXmlFile3(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false


	CMarkup xml;
	if (xml.Load(methord::GetAppPath() + "\\" + szFileName) == false)return false;

	xml.ResetMainPos();
	if (!(xml.FindElem(__T("Server"))))
	{
		return false;
	}
	xml.IntoElem();
	if (xml.FindElem(__T("���ں�")))	cset.comname = (xml.GetData());//
	if (xml.FindElem(__T("������")))cset.baud = (xml.GetData());//
	if (xml.FindElem(__T("�ͺ�")))	cset.EquipName = (xml.GetData());//
	if (xml.FindElem(__T("��ַ")))	cset.addr = (xml.GetData());//
	xml.OutOfElem();//

	return true;
}
