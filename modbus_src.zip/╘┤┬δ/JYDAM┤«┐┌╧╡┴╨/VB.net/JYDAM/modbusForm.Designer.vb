﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class modbusForm
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.FrameByteStyle = New System.Windows.Forms.GroupBox()
        Me.CombBaudRate = New System.Windows.Forms.ComboBox()
        Me.Combnode = New System.Windows.Forms.ComboBox()
        Me.CommandClose = New System.Windows.Forms.Button()
        Me.CommandOpen = New System.Windows.Forms.Button()
        Me.CombCOM = New System.Windows.Forms.ComboBox()
        Me.LabBaud = New System.Windows.Forms.Label()
        Me.Labnode = New System.Windows.Forms.Label()
        Me.LabCom = New System.Windows.Forms.Label()
        Me.btnDO1 = New System.Windows.Forms.Button()
        Me.btnDO2 = New System.Windows.Forms.Button()
        Me.btnDO4 = New System.Windows.Forms.Button()
        Me.btnDO3 = New System.Windows.Forms.Button()
        Me.btnDO8 = New System.Windows.Forms.Button()
        Me.btnDO7 = New System.Windows.Forms.Button()
        Me.btnDO6 = New System.Windows.Forms.Button()
        Me.btnDO5 = New System.Windows.Forms.Button()
        Me.btnDO16 = New System.Windows.Forms.Button()
        Me.btnDO15 = New System.Windows.Forms.Button()
        Me.btnDO14 = New System.Windows.Forms.Button()
        Me.btnDO13 = New System.Windows.Forms.Button()
        Me.btnDO12 = New System.Windows.Forms.Button()
        Me.btnDO11 = New System.Windows.Forms.Button()
        Me.btnDO10 = New System.Windows.Forms.Button()
        Me.btnDO9 = New System.Windows.Forms.Button()
        Me.btnDI16 = New System.Windows.Forms.Button()
        Me.btnDI15 = New System.Windows.Forms.Button()
        Me.btnDI14 = New System.Windows.Forms.Button()
        Me.btnDI13 = New System.Windows.Forms.Button()
        Me.btnDI12 = New System.Windows.Forms.Button()
        Me.btnDI11 = New System.Windows.Forms.Button()
        Me.btnDI10 = New System.Windows.Forms.Button()
        Me.btnDI9 = New System.Windows.Forms.Button()
        Me.btnDI8 = New System.Windows.Forms.Button()
        Me.btnDI7 = New System.Windows.Forms.Button()
        Me.btnDI6 = New System.Windows.Forms.Button()
        Me.btnDI5 = New System.Windows.Forms.Button()
        Me.btnDI4 = New System.Windows.Forms.Button()
        Me.btnDI3 = New System.Windows.Forms.Button()
        Me.btnDI2 = New System.Windows.Forms.Button()
        Me.btnDI1 = New System.Windows.Forms.Button()
        Me.txtAI = New System.Windows.Forms.TextBox()
        Me.btnDIRead = New System.Windows.Forms.Button()
        Me.btnAIRead = New System.Windows.Forms.Button()
        Me.btnWriteAO1 = New System.Windows.Forms.Button()
        Me.txtAO1 = New System.Windows.Forms.TextBox()
        Me.btnWriteAO2 = New System.Windows.Forms.Button()
        Me.btnReadAO1 = New System.Windows.Forms.Button()
        Me.btnReadAO2 = New System.Windows.Forms.Button()
        Me.txtAO2 = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.FrameByteStyle.SuspendLayout()
        Me.SuspendLayout()
        '
        'FrameByteStyle
        '
        Me.FrameByteStyle.BackColor = System.Drawing.SystemColors.Control
        Me.FrameByteStyle.Controls.Add(Me.CombBaudRate)
        Me.FrameByteStyle.Controls.Add(Me.Combnode)
        Me.FrameByteStyle.Controls.Add(Me.CommandClose)
        Me.FrameByteStyle.Controls.Add(Me.CommandOpen)
        Me.FrameByteStyle.Controls.Add(Me.CombCOM)
        Me.FrameByteStyle.Controls.Add(Me.LabBaud)
        Me.FrameByteStyle.Controls.Add(Me.Labnode)
        Me.FrameByteStyle.Controls.Add(Me.LabCom)
        Me.FrameByteStyle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FrameByteStyle.Location = New System.Drawing.Point(16, 11)
        Me.FrameByteStyle.Margin = New System.Windows.Forms.Padding(4)
        Me.FrameByteStyle.Name = "FrameByteStyle"
        Me.FrameByteStyle.Padding = New System.Windows.Forms.Padding(0)
        Me.FrameByteStyle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FrameByteStyle.Size = New System.Drawing.Size(576, 106)
        Me.FrameByteStyle.TabIndex = 51
        Me.FrameByteStyle.TabStop = False
        '
        'CombBaudRate
        '
        Me.CombBaudRate.BackColor = System.Drawing.SystemColors.Window
        Me.CombBaudRate.Cursor = System.Windows.Forms.Cursors.Default
        Me.CombBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CombBaudRate.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.CombBaudRate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.CombBaudRate.Items.AddRange(New Object() {"4800", "9600", "19200", "38400", "56000", "57600", "115200"})
        Me.CombBaudRate.Location = New System.Drawing.Point(89, 57)
        Me.CombBaudRate.Margin = New System.Windows.Forms.Padding(4)
        Me.CombBaudRate.Name = "CombBaudRate"
        Me.CombBaudRate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CombBaudRate.Size = New System.Drawing.Size(105, 25)
        Me.CombBaudRate.TabIndex = 37
        '
        'Combnode
        '
        Me.Combnode.BackColor = System.Drawing.SystemColors.Window
        Me.Combnode.Cursor = System.Windows.Forms.Cursors.Default
        Me.Combnode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combnode.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Combnode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Combnode.Items.AddRange(New Object() {"254", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "129", "130", "131", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200", "201", "202", "203", "204", "205", "206", "207", "208", "209", "210", "211", "212", "213", "214", "215", "216", "217", "218", "219", "220", "221", "222", "223", "224", "225", "226", "227", "228", "229", "230", "231", "232", "233", "234", "235", "236", "237", "238", "239", "240", "241", "242", "243", "244", "245", "246", "247", "248", "249", "250", "251", "252", "253", "254", "255"})
        Me.Combnode.Location = New System.Drawing.Point(279, 24)
        Me.Combnode.Margin = New System.Windows.Forms.Padding(4)
        Me.Combnode.Name = "Combnode"
        Me.Combnode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Combnode.Size = New System.Drawing.Size(116, 25)
        Me.Combnode.TabIndex = 7
        '
        'CommandClose
        '
        Me.CommandClose.BackColor = System.Drawing.SystemColors.Control
        Me.CommandClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.CommandClose.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.CommandClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CommandClose.Location = New System.Drawing.Point(416, 62)
        Me.CommandClose.Margin = New System.Windows.Forms.Padding(4)
        Me.CommandClose.Name = "CommandClose"
        Me.CommandClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CommandClose.Size = New System.Drawing.Size(143, 30)
        Me.CommandClose.TabIndex = 4
        Me.CommandClose.Text = "关闭串口"
        Me.CommandClose.UseVisualStyleBackColor = False
        '
        'CommandOpen
        '
        Me.CommandOpen.BackColor = System.Drawing.SystemColors.Control
        Me.CommandOpen.Cursor = System.Windows.Forms.Cursors.Default
        Me.CommandOpen.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.CommandOpen.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CommandOpen.Location = New System.Drawing.Point(416, 24)
        Me.CommandOpen.Margin = New System.Windows.Forms.Padding(4)
        Me.CommandOpen.Name = "CommandOpen"
        Me.CommandOpen.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CommandOpen.Size = New System.Drawing.Size(143, 30)
        Me.CommandOpen.TabIndex = 3
        Me.CommandOpen.Text = "打开串口"
        Me.CommandOpen.UseVisualStyleBackColor = False
        '
        'CombCOM
        '
        Me.CombCOM.BackColor = System.Drawing.SystemColors.Window
        Me.CombCOM.Cursor = System.Windows.Forms.Cursors.Default
        Me.CombCOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CombCOM.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.CombCOM.ForeColor = System.Drawing.SystemColors.WindowText
        Me.CombCOM.Items.AddRange(New Object() {"COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8"})
        Me.CombCOM.Location = New System.Drawing.Point(89, 21)
        Me.CombCOM.Margin = New System.Windows.Forms.Padding(4)
        Me.CombCOM.Name = "CombCOM"
        Me.CombCOM.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CombCOM.Size = New System.Drawing.Size(105, 25)
        Me.CombCOM.TabIndex = 2
        '
        'LabBaud
        '
        Me.LabBaud.AutoSize = True
        Me.LabBaud.BackColor = System.Drawing.SystemColors.Control
        Me.LabBaud.Cursor = System.Windows.Forms.Cursors.Default
        Me.LabBaud.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.LabBaud.ForeColor = System.Drawing.Color.Black
        Me.LabBaud.Location = New System.Drawing.Point(19, 62)
        Me.LabBaud.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabBaud.Name = "LabBaud"
        Me.LabBaud.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LabBaud.Size = New System.Drawing.Size(71, 18)
        Me.LabBaud.TabIndex = 38
        Me.LabBaud.Text = "波特率:"
        '
        'Labnode
        '
        Me.Labnode.AutoSize = True
        Me.Labnode.BackColor = System.Drawing.SystemColors.Control
        Me.Labnode.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labnode.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labnode.ForeColor = System.Drawing.Color.Black
        Me.Labnode.Location = New System.Drawing.Point(209, 29)
        Me.Labnode.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Labnode.Name = "Labnode"
        Me.Labnode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labnode.Size = New System.Drawing.Size(71, 18)
        Me.Labnode.TabIndex = 8
        Me.Labnode.Text = "从站号:"
        '
        'LabCom
        '
        Me.LabCom.AutoSize = True
        Me.LabCom.BackColor = System.Drawing.SystemColors.Control
        Me.LabCom.Cursor = System.Windows.Forms.Cursors.Default
        Me.LabCom.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.LabCom.ForeColor = System.Drawing.Color.Black
        Me.LabCom.Location = New System.Drawing.Point(19, 28)
        Me.LabCom.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabCom.Name = "LabCom"
        Me.LabCom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LabCom.Size = New System.Drawing.Size(71, 18)
        Me.LabCom.TabIndex = 1
        Me.LabCom.Text = "串口号:"
        '
        'btnDO1
        '
        Me.btnDO1.Location = New System.Drawing.Point(16, 138)
        Me.btnDO1.Name = "btnDO1"
        Me.btnDO1.Size = New System.Drawing.Size(56, 40)
        Me.btnDO1.TabIndex = 52
        Me.btnDO1.Tag = "1"
        Me.btnDO1.Text = "DO1"
        Me.btnDO1.UseVisualStyleBackColor = True
        '
        'btnDO2
        '
        Me.btnDO2.Location = New System.Drawing.Point(78, 138)
        Me.btnDO2.Name = "btnDO2"
        Me.btnDO2.Size = New System.Drawing.Size(56, 40)
        Me.btnDO2.TabIndex = 53
        Me.btnDO2.Tag = "2"
        Me.btnDO2.Text = "DO2"
        Me.btnDO2.UseVisualStyleBackColor = True
        '
        'btnDO4
        '
        Me.btnDO4.Location = New System.Drawing.Point(202, 138)
        Me.btnDO4.Name = "btnDO4"
        Me.btnDO4.Size = New System.Drawing.Size(56, 40)
        Me.btnDO4.TabIndex = 55
        Me.btnDO4.Tag = "4"
        Me.btnDO4.Text = "DO4"
        Me.btnDO4.UseVisualStyleBackColor = True
        '
        'btnDO3
        '
        Me.btnDO3.Location = New System.Drawing.Point(140, 138)
        Me.btnDO3.Name = "btnDO3"
        Me.btnDO3.Size = New System.Drawing.Size(56, 40)
        Me.btnDO3.TabIndex = 54
        Me.btnDO3.Tag = "3"
        Me.btnDO3.Text = "DO3"
        Me.btnDO3.UseVisualStyleBackColor = True
        '
        'btnDO8
        '
        Me.btnDO8.Location = New System.Drawing.Point(450, 138)
        Me.btnDO8.Name = "btnDO8"
        Me.btnDO8.Size = New System.Drawing.Size(56, 40)
        Me.btnDO8.TabIndex = 59
        Me.btnDO8.Tag = "8"
        Me.btnDO8.Text = "DO8"
        Me.btnDO8.UseVisualStyleBackColor = True
        '
        'btnDO7
        '
        Me.btnDO7.Location = New System.Drawing.Point(388, 138)
        Me.btnDO7.Name = "btnDO7"
        Me.btnDO7.Size = New System.Drawing.Size(56, 40)
        Me.btnDO7.TabIndex = 58
        Me.btnDO7.Tag = "7"
        Me.btnDO7.Text = "DO7"
        Me.btnDO7.UseVisualStyleBackColor = True
        '
        'btnDO6
        '
        Me.btnDO6.Location = New System.Drawing.Point(326, 138)
        Me.btnDO6.Name = "btnDO6"
        Me.btnDO6.Size = New System.Drawing.Size(56, 40)
        Me.btnDO6.TabIndex = 57
        Me.btnDO6.Tag = "6"
        Me.btnDO6.Text = "DO6"
        Me.btnDO6.UseVisualStyleBackColor = True
        '
        'btnDO5
        '
        Me.btnDO5.Location = New System.Drawing.Point(264, 138)
        Me.btnDO5.Name = "btnDO5"
        Me.btnDO5.Size = New System.Drawing.Size(56, 40)
        Me.btnDO5.TabIndex = 56
        Me.btnDO5.Tag = "5"
        Me.btnDO5.Text = "DO5"
        Me.btnDO5.UseVisualStyleBackColor = True
        '
        'btnDO16
        '
        Me.btnDO16.Location = New System.Drawing.Point(450, 184)
        Me.btnDO16.Name = "btnDO16"
        Me.btnDO16.Size = New System.Drawing.Size(56, 40)
        Me.btnDO16.TabIndex = 67
        Me.btnDO16.Tag = "16"
        Me.btnDO16.Text = "DO16"
        Me.btnDO16.UseVisualStyleBackColor = True
        '
        'btnDO15
        '
        Me.btnDO15.Location = New System.Drawing.Point(388, 184)
        Me.btnDO15.Name = "btnDO15"
        Me.btnDO15.Size = New System.Drawing.Size(56, 40)
        Me.btnDO15.TabIndex = 66
        Me.btnDO15.Tag = "15"
        Me.btnDO15.Text = "DO15"
        Me.btnDO15.UseVisualStyleBackColor = True
        '
        'btnDO14
        '
        Me.btnDO14.Location = New System.Drawing.Point(326, 184)
        Me.btnDO14.Name = "btnDO14"
        Me.btnDO14.Size = New System.Drawing.Size(56, 40)
        Me.btnDO14.TabIndex = 65
        Me.btnDO14.Tag = "14"
        Me.btnDO14.Text = "DO14"
        Me.btnDO14.UseVisualStyleBackColor = True
        '
        'btnDO13
        '
        Me.btnDO13.Location = New System.Drawing.Point(264, 184)
        Me.btnDO13.Name = "btnDO13"
        Me.btnDO13.Size = New System.Drawing.Size(56, 40)
        Me.btnDO13.TabIndex = 64
        Me.btnDO13.Tag = "13"
        Me.btnDO13.Text = "DO13"
        Me.btnDO13.UseVisualStyleBackColor = True
        '
        'btnDO12
        '
        Me.btnDO12.Location = New System.Drawing.Point(202, 184)
        Me.btnDO12.Name = "btnDO12"
        Me.btnDO12.Size = New System.Drawing.Size(56, 40)
        Me.btnDO12.TabIndex = 63
        Me.btnDO12.Tag = "12"
        Me.btnDO12.Text = "DO12"
        Me.btnDO12.UseVisualStyleBackColor = True
        '
        'btnDO11
        '
        Me.btnDO11.Location = New System.Drawing.Point(140, 184)
        Me.btnDO11.Name = "btnDO11"
        Me.btnDO11.Size = New System.Drawing.Size(56, 40)
        Me.btnDO11.TabIndex = 62
        Me.btnDO11.Tag = "11"
        Me.btnDO11.Text = "DO11"
        Me.btnDO11.UseVisualStyleBackColor = True
        '
        'btnDO10
        '
        Me.btnDO10.Location = New System.Drawing.Point(78, 184)
        Me.btnDO10.Name = "btnDO10"
        Me.btnDO10.Size = New System.Drawing.Size(56, 40)
        Me.btnDO10.TabIndex = 61
        Me.btnDO10.Tag = "10"
        Me.btnDO10.Text = "DO10"
        Me.btnDO10.UseVisualStyleBackColor = True
        '
        'btnDO9
        '
        Me.btnDO9.Location = New System.Drawing.Point(16, 184)
        Me.btnDO9.Name = "btnDO9"
        Me.btnDO9.Size = New System.Drawing.Size(56, 40)
        Me.btnDO9.TabIndex = 60
        Me.btnDO9.Tag = "9"
        Me.btnDO9.Text = "DO9"
        Me.btnDO9.UseVisualStyleBackColor = True
        '
        'btnDI16
        '
        Me.btnDI16.Location = New System.Drawing.Point(450, 300)
        Me.btnDI16.Name = "btnDI16"
        Me.btnDI16.Size = New System.Drawing.Size(56, 40)
        Me.btnDI16.TabIndex = 83
        Me.btnDI16.Text = "DI16"
        Me.btnDI16.UseVisualStyleBackColor = True
        '
        'btnDI15
        '
        Me.btnDI15.Location = New System.Drawing.Point(388, 300)
        Me.btnDI15.Name = "btnDI15"
        Me.btnDI15.Size = New System.Drawing.Size(56, 40)
        Me.btnDI15.TabIndex = 82
        Me.btnDI15.Text = "DI15"
        Me.btnDI15.UseVisualStyleBackColor = True
        '
        'btnDI14
        '
        Me.btnDI14.Location = New System.Drawing.Point(326, 300)
        Me.btnDI14.Name = "btnDI14"
        Me.btnDI14.Size = New System.Drawing.Size(56, 40)
        Me.btnDI14.TabIndex = 81
        Me.btnDI14.Text = "DI14"
        Me.btnDI14.UseVisualStyleBackColor = True
        '
        'btnDI13
        '
        Me.btnDI13.Location = New System.Drawing.Point(264, 300)
        Me.btnDI13.Name = "btnDI13"
        Me.btnDI13.Size = New System.Drawing.Size(56, 40)
        Me.btnDI13.TabIndex = 80
        Me.btnDI13.Text = "DI13"
        Me.btnDI13.UseVisualStyleBackColor = True
        '
        'btnDI12
        '
        Me.btnDI12.Location = New System.Drawing.Point(202, 300)
        Me.btnDI12.Name = "btnDI12"
        Me.btnDI12.Size = New System.Drawing.Size(56, 40)
        Me.btnDI12.TabIndex = 79
        Me.btnDI12.Text = "DI12"
        Me.btnDI12.UseVisualStyleBackColor = True
        '
        'btnDI11
        '
        Me.btnDI11.Location = New System.Drawing.Point(140, 300)
        Me.btnDI11.Name = "btnDI11"
        Me.btnDI11.Size = New System.Drawing.Size(56, 40)
        Me.btnDI11.TabIndex = 78
        Me.btnDI11.Text = "DI11"
        Me.btnDI11.UseVisualStyleBackColor = True
        '
        'btnDI10
        '
        Me.btnDI10.Location = New System.Drawing.Point(78, 300)
        Me.btnDI10.Name = "btnDI10"
        Me.btnDI10.Size = New System.Drawing.Size(56, 40)
        Me.btnDI10.TabIndex = 77
        Me.btnDI10.Text = "DI10"
        Me.btnDI10.UseVisualStyleBackColor = True
        '
        'btnDI9
        '
        Me.btnDI9.Location = New System.Drawing.Point(16, 300)
        Me.btnDI9.Name = "btnDI9"
        Me.btnDI9.Size = New System.Drawing.Size(56, 40)
        Me.btnDI9.TabIndex = 76
        Me.btnDI9.Text = "DI9"
        Me.btnDI9.UseVisualStyleBackColor = True
        '
        'btnDI8
        '
        Me.btnDI8.Location = New System.Drawing.Point(450, 254)
        Me.btnDI8.Name = "btnDI8"
        Me.btnDI8.Size = New System.Drawing.Size(56, 40)
        Me.btnDI8.TabIndex = 75
        Me.btnDI8.Text = "DI8"
        Me.btnDI8.UseVisualStyleBackColor = True
        '
        'btnDI7
        '
        Me.btnDI7.Location = New System.Drawing.Point(388, 254)
        Me.btnDI7.Name = "btnDI7"
        Me.btnDI7.Size = New System.Drawing.Size(56, 40)
        Me.btnDI7.TabIndex = 74
        Me.btnDI7.Text = "DI7"
        Me.btnDI7.UseVisualStyleBackColor = True
        '
        'btnDI6
        '
        Me.btnDI6.Location = New System.Drawing.Point(326, 254)
        Me.btnDI6.Name = "btnDI6"
        Me.btnDI6.Size = New System.Drawing.Size(56, 40)
        Me.btnDI6.TabIndex = 73
        Me.btnDI6.Text = "DI6"
        Me.btnDI6.UseVisualStyleBackColor = True
        '
        'btnDI5
        '
        Me.btnDI5.Location = New System.Drawing.Point(264, 254)
        Me.btnDI5.Name = "btnDI5"
        Me.btnDI5.Size = New System.Drawing.Size(56, 40)
        Me.btnDI5.TabIndex = 72
        Me.btnDI5.Text = "DI5"
        Me.btnDI5.UseVisualStyleBackColor = True
        '
        'btnDI4
        '
        Me.btnDI4.Location = New System.Drawing.Point(202, 254)
        Me.btnDI4.Name = "btnDI4"
        Me.btnDI4.Size = New System.Drawing.Size(56, 40)
        Me.btnDI4.TabIndex = 71
        Me.btnDI4.Text = "DI4"
        Me.btnDI4.UseVisualStyleBackColor = True
        '
        'btnDI3
        '
        Me.btnDI3.Location = New System.Drawing.Point(140, 254)
        Me.btnDI3.Name = "btnDI3"
        Me.btnDI3.Size = New System.Drawing.Size(56, 40)
        Me.btnDI3.TabIndex = 70
        Me.btnDI3.Text = "DI3"
        Me.btnDI3.UseVisualStyleBackColor = True
        '
        'btnDI2
        '
        Me.btnDI2.Location = New System.Drawing.Point(78, 254)
        Me.btnDI2.Name = "btnDI2"
        Me.btnDI2.Size = New System.Drawing.Size(56, 40)
        Me.btnDI2.TabIndex = 69
        Me.btnDI2.Text = "DI2"
        Me.btnDI2.UseVisualStyleBackColor = True
        '
        'btnDI1
        '
        Me.btnDI1.Location = New System.Drawing.Point(16, 254)
        Me.btnDI1.Name = "btnDI1"
        Me.btnDI1.Size = New System.Drawing.Size(56, 40)
        Me.btnDI1.TabIndex = 68
        Me.btnDI1.Tag = "1"
        Me.btnDI1.Text = "DI1"
        Me.btnDI1.UseVisualStyleBackColor = True
        '
        'txtAI
        '
        Me.txtAI.Location = New System.Drawing.Point(18, 359)
        Me.txtAI.Multiline = True
        Me.txtAI.Name = "txtAI"
        Me.txtAI.Size = New System.Drawing.Size(556, 62)
        Me.txtAI.TabIndex = 84
        '
        'btnDIRead
        '
        Me.btnDIRead.Location = New System.Drawing.Point(512, 254)
        Me.btnDIRead.Name = "btnDIRead"
        Me.btnDIRead.Size = New System.Drawing.Size(81, 40)
        Me.btnDIRead.TabIndex = 85
        Me.btnDIRead.Text = "读取DI"
        Me.btnDIRead.UseVisualStyleBackColor = True
        '
        'btnAIRead
        '
        Me.btnAIRead.Location = New System.Drawing.Point(512, 300)
        Me.btnAIRead.Name = "btnAIRead"
        Me.btnAIRead.Size = New System.Drawing.Size(81, 40)
        Me.btnAIRead.TabIndex = 86
        Me.btnAIRead.Text = "读取AI"
        Me.btnAIRead.UseVisualStyleBackColor = True
        '
        'btnWriteAO1
        '
        Me.btnWriteAO1.Location = New System.Drawing.Point(116, 446)
        Me.btnWriteAO1.Name = "btnWriteAO1"
        Me.btnWriteAO1.Size = New System.Drawing.Size(81, 40)
        Me.btnWriteAO1.TabIndex = 87
        Me.btnWriteAO1.Text = "写AO1"
        Me.btnWriteAO1.UseVisualStyleBackColor = True
        '
        'txtAO1
        '
        Me.txtAO1.Location = New System.Drawing.Point(16, 451)
        Me.txtAO1.Name = "txtAO1"
        Me.txtAO1.Size = New System.Drawing.Size(94, 25)
        Me.txtAO1.TabIndex = 88
        '
        'btnWriteAO2
        '
        Me.btnWriteAO2.Location = New System.Drawing.Point(425, 446)
        Me.btnWriteAO2.Name = "btnWriteAO2"
        Me.btnWriteAO2.Size = New System.Drawing.Size(81, 40)
        Me.btnWriteAO2.TabIndex = 89
        Me.btnWriteAO2.Text = "写AO2"
        Me.btnWriteAO2.UseVisualStyleBackColor = True
        '
        'btnReadAO1
        '
        Me.btnReadAO1.Location = New System.Drawing.Point(203, 446)
        Me.btnReadAO1.Name = "btnReadAO1"
        Me.btnReadAO1.Size = New System.Drawing.Size(81, 40)
        Me.btnReadAO1.TabIndex = 90
        Me.btnReadAO1.Text = "读AO1"
        Me.btnReadAO1.UseVisualStyleBackColor = True
        '
        'btnReadAO2
        '
        Me.btnReadAO2.Location = New System.Drawing.Point(512, 446)
        Me.btnReadAO2.Name = "btnReadAO2"
        Me.btnReadAO2.Size = New System.Drawing.Size(81, 40)
        Me.btnReadAO2.TabIndex = 91
        Me.btnReadAO2.Text = "读AO2"
        Me.btnReadAO2.UseVisualStyleBackColor = True
        '
        'txtAO2
        '
        Me.txtAO2.Location = New System.Drawing.Point(326, 456)
        Me.txtAO2.Name = "txtAO2"
        Me.txtAO2.Size = New System.Drawing.Size(94, 25)
        Me.txtAO2.TabIndex = 92
        '
        'Timer1
        '
        '
        'modbusForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(605, 498)
        Me.Controls.Add(Me.txtAO2)
        Me.Controls.Add(Me.btnReadAO2)
        Me.Controls.Add(Me.btnReadAO1)
        Me.Controls.Add(Me.btnWriteAO2)
        Me.Controls.Add(Me.txtAO1)
        Me.Controls.Add(Me.btnWriteAO1)
        Me.Controls.Add(Me.btnAIRead)
        Me.Controls.Add(Me.btnDIRead)
        Me.Controls.Add(Me.txtAI)
        Me.Controls.Add(Me.btnDI16)
        Me.Controls.Add(Me.btnDI15)
        Me.Controls.Add(Me.btnDI14)
        Me.Controls.Add(Me.btnDI13)
        Me.Controls.Add(Me.btnDI12)
        Me.Controls.Add(Me.btnDI11)
        Me.Controls.Add(Me.btnDI10)
        Me.Controls.Add(Me.btnDI9)
        Me.Controls.Add(Me.btnDI8)
        Me.Controls.Add(Me.btnDI7)
        Me.Controls.Add(Me.btnDI6)
        Me.Controls.Add(Me.btnDI5)
        Me.Controls.Add(Me.btnDI4)
        Me.Controls.Add(Me.btnDI3)
        Me.Controls.Add(Me.btnDI2)
        Me.Controls.Add(Me.btnDI1)
        Me.Controls.Add(Me.btnDO16)
        Me.Controls.Add(Me.btnDO15)
        Me.Controls.Add(Me.btnDO14)
        Me.Controls.Add(Me.btnDO13)
        Me.Controls.Add(Me.btnDO12)
        Me.Controls.Add(Me.btnDO11)
        Me.Controls.Add(Me.btnDO10)
        Me.Controls.Add(Me.btnDO9)
        Me.Controls.Add(Me.btnDO8)
        Me.Controls.Add(Me.btnDO7)
        Me.Controls.Add(Me.btnDO6)
        Me.Controls.Add(Me.btnDO5)
        Me.Controls.Add(Me.btnDO4)
        Me.Controls.Add(Me.btnDO3)
        Me.Controls.Add(Me.btnDO2)
        Me.Controls.Add(Me.btnDO1)
        Me.Controls.Add(Me.FrameByteStyle)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "modbusForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "施耐德modbus rtu协议通信demo"
        Me.FrameByteStyle.ResumeLayout(False)
        Me.FrameByteStyle.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents FrameByteStyle As System.Windows.Forms.GroupBox
    Public WithEvents CombBaudRate As System.Windows.Forms.ComboBox
    Public WithEvents Combnode As System.Windows.Forms.ComboBox
    Public WithEvents CommandClose As System.Windows.Forms.Button
    Public WithEvents CommandOpen As System.Windows.Forms.Button
    Public WithEvents CombCOM As System.Windows.Forms.ComboBox
    Public WithEvents LabBaud As System.Windows.Forms.Label
    Public WithEvents Labnode As System.Windows.Forms.Label
    Public WithEvents LabCom As System.Windows.Forms.Label
    Friend WithEvents btnDO1 As Button
    Friend WithEvents btnDO2 As Button
    Friend WithEvents btnDO4 As Button
    Friend WithEvents btnDO3 As Button
    Friend WithEvents btnDO8 As Button
    Friend WithEvents btnDO7 As Button
    Friend WithEvents btnDO6 As Button
    Friend WithEvents btnDO5 As Button
    Friend WithEvents btnDO16 As Button
    Friend WithEvents btnDO15 As Button
    Friend WithEvents btnDO14 As Button
    Friend WithEvents btnDO13 As Button
    Friend WithEvents btnDO12 As Button
    Friend WithEvents btnDO11 As Button
    Friend WithEvents btnDO10 As Button
    Friend WithEvents btnDO9 As Button
    Friend WithEvents btnDI16 As Button
    Friend WithEvents btnDI15 As Button
    Friend WithEvents btnDI14 As Button
    Friend WithEvents btnDI13 As Button
    Friend WithEvents btnDI12 As Button
    Friend WithEvents btnDI11 As Button
    Friend WithEvents btnDI10 As Button
    Friend WithEvents btnDI9 As Button
    Friend WithEvents btnDI8 As Button
    Friend WithEvents btnDI7 As Button
    Friend WithEvents btnDI6 As Button
    Friend WithEvents btnDI5 As Button
    Friend WithEvents btnDI4 As Button
    Friend WithEvents btnDI3 As Button
    Friend WithEvents btnDI2 As Button
    Friend WithEvents btnDI1 As Button
    Friend WithEvents txtAI As TextBox
    Friend WithEvents btnDIRead As Button
    Friend WithEvents btnAIRead As Button
    Friend WithEvents btnWriteAO1 As Button
    Friend WithEvents txtAO1 As TextBox
    Friend WithEvents btnWriteAO2 As Button
    Friend WithEvents btnReadAO1 As Button
    Friend WithEvents btnReadAO2 As Button
    Friend WithEvents txtAO2 As TextBox
    Friend WithEvents Timer1 As Timer
End Class
