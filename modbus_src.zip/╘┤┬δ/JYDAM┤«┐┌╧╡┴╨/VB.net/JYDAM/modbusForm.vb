﻿Imports System.Runtime.InteropServices

Public Class modbusForm
    Dim modbusInt, ComPort, Readtrue As Integer
    '串口控制函数
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtuComOpen", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtuComOpen(ByVal nport As Integer, _
                               ByVal BaudRate As Integer, _
                               ByVal DataBits As Integer, _
                               ByVal Parity As String, _
                               ByVal StopBits As Integer, _
                               ByVal User As String) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtuComClose", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtuComClose(ByVal nport As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtuComTrue", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtuComTrue(ByVal nport As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtuComWork", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtuComWork(ByVal nport As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtuSetDelay", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtuSetDelay(ByVal value As Integer) As Integer
    End Function
    '标准modbus函数
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn01", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn01(ByVal nport As Integer, _
                               ByVal node As Integer, _
                               ByVal address As Integer, _
                               ByVal Count As Integer, _
                               ByRef RxdBuffer As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn02", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn02(ByVal nport As Integer, _
                              ByVal node As Integer, _
                              ByVal address As Integer, _
                              ByVal Count As Integer, _
                              ByRef RxdBuffer As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn03", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn03(ByVal nport As Integer, _
                              ByVal node As Integer, _
                              ByVal address As Integer, _
                              ByVal Count As Integer, _
                              ByRef RxdBuffer As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn04", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn04(ByVal nport As Integer, _
                              ByVal node As Integer, _
                              ByVal address As Integer, _
                              ByVal Count As Integer, _
                              ByRef RxdBuffer As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn05", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn05(ByVal nport As Integer, _
                             ByVal node As Integer, _
                             ByVal address As Integer, _
                             ByVal value As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn06", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn06(ByVal nport As Integer, _
                             ByVal node As Integer, _
                             ByVal address As Integer, _
                             ByVal value As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn15", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn15(ByVal nport As Integer, _
                              ByVal node As Integer, _
                              ByVal address As Integer, _
                              ByVal Count As Integer, _
                              ByRef TxdBuffer As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn16", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn16(ByVal nport As Integer, _
                             ByVal node As Integer, _
                             ByVal address As Integer, _
                             ByVal Count As Integer, _
                             ByRef TxdBuffer As Integer) As Integer
    End Function
    '延伸modbus函数
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn03DInt", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn03DInt(ByVal nport As Integer, _
                             ByVal node As Integer, _
                             ByVal regular As Integer, _
                             ByVal address As Integer, _
                             ByVal Count As Integer, _
                             ByRef RxdBuffer As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn03Float", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn03Float(ByVal nport As Integer, _
                            ByVal node As Integer, _
                            ByVal regular As Integer, _
                            ByVal address As Integer, _
                            ByVal Count As Integer, _
                            ByRef RxdBuffer As Single) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn04DInt", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn04DInt(ByVal nport As Integer, _
                             ByVal node As Integer, _
                             ByVal regular As Integer, _
                             ByVal address As Integer, _
                             ByVal Count As Integer, _
                             ByRef RxdBuffer As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn04Float", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn04Float(ByVal nport As Integer, _
                            ByVal node As Integer, _
                            ByVal regular As Integer, _
                            ByVal address As Integer, _
                            ByVal Count As Integer, _
                            ByRef RxdBuffer As Single) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn16DInt", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn16DInt(ByVal nport As Integer, _
                             ByVal node As Integer, _
                             ByVal regular As Integer, _
                             ByVal address As Integer, _
                             ByVal Count As Integer, _
                             ByRef TxdBuffer As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtufcn16Float", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtufcn16Float(ByVal nport As Integer, _
                            ByVal node As Integer, _
                            ByVal regular As Integer, _
                            ByVal address As Integer, _
                            ByVal Count As Integer, _
                            ByRef TxdBuffer As Single) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtuWordBitWrite", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtuWordBitWrite(ByVal nport As Integer, _
                             ByVal node As Integer, _
                             ByVal address As Integer, _
                             ByVal Bit As Integer, _
                             ByVal value As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="mbrtuWordBitSetReset", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function mbrtuWordBitSetReset(ByVal nport As Integer, _
                             ByVal node As Integer, _
                             ByVal address As Integer, _
                             ByVal Bit As Integer) As Integer
    End Function
    '混合读写时等情况所需拓展函数
    <DllImport("modbus_rtu.dll", EntryPoint:="DecBitBin", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function DecBitBin(ByVal value As Integer, _
                               ByVal Bitaddress As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="Int32ToInt_16h", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function Int32ToInt_16h(ByVal value As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="Int32ToInt_16l", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function Int32ToInt_16l(ByVal value As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="Int16ToInt32", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function Int16ToInt32(ByVal valueH As Integer, _
                               ByVal valueL As Integer) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="Float32ToInt_16h", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function Float32ToInt_16h(ByVal value As Single) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="Float32ToInt_16l", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function Float32ToInt_16l(ByVal value As Single) As Integer
    End Function
    <DllImport("modbus_rtu.dll", EntryPoint:="Int16ToFloat32", CharSet:=CharSet.Ansi, SetLastError:=True)> _
    Private Shared Function Int16ToFloat32(ByVal valueH As Integer, _
                               ByVal valueL As Integer) As Single
    End Function
    Private Sub Formmodbus_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Combnode.SelectedIndex = 0
        CombCOM.SelectedIndex = 0
        CombBaudRate.SelectedIndex = 1
        ComPort = 1
        modbusInt = -1
        Readtrue = -1
    End Sub

    '通道数量请根据实际板卡来决定
    Const DONum = 4   '继电器通道的数量
    Const DINum = 4   '光耦输通道入的数量
    Const AINum = 4   '模拟量输入通道的数量
    Const AIMode = 0   '模拟量输入通道的数量

    Const AIMode1 = 0  '模拟量为4-20mA,数值为16位整形数据
    Const AIMode2 = 1  '模拟量为累积量,数值为32位整形数据
    Const AIMode3 = 2  '模拟量为浮点型,数值为浮点型数据，比如pt100

    Private Sub CommandOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandOpen.Click
        Dim k, BaudRate As Integer
        ComPort = CombCOM.SelectedIndex + 1

        If mbrtuComTrue(ComPort) = -1 Then
            '设定DLL函数的超时参数8~80
            Call mbrtuSetDelay(2)
            '将DLL用户名及端口号传入打开串口，串口设定9600,8,n,1
            BaudRate = Val(CombBaudRate.Text)
            k = mbrtuComOpen(ComPort, BaudRate, 8, "n", 1, "lp")
            If k = 1 Then         'k=-1 表示串口打开失败，可能串口不存在或已被占用
                Me.Text = "JYDAM----DLL已注册"
            ElseIf k = 0 Then
                Me.Text = "jydam----DLL未注册"
            End If
            If mbrtuComTrue(ComPort) = 1 Then
                CombCOM.Enabled = False
                Combnode.Enabled = False
            End If
        End If
    End Sub

    Private Sub CommandClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandClose.Click
        If mbrtuComTrue(ComPort) = 1 Then
            Readtrue = -1
            modbusInt = -1

            If mbrtuComClose(ComPort) = -1 Then
                Exit Sub '关闭串口=-1表示失败  
            End If
            CombCOM.Enabled = True
            Me.Text = "施耐德modbus rtu协议通信demo"
        End If
    End Sub

    Private Sub modbusForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        mbrtuComClose(ComPort)
    End Sub
    Private Sub BtnDO_Click(sender As Object, e As EventArgs) Handles btnDO1.Click, btnDO9.Click, btnDO8.Click, btnDO7.Click, btnDO6.Click, btnDO5.Click, btnDO4.Click, btnDO3.Click, btnDO2.Click, btnDO16.Click, btnDO15.Click, btnDO14.Click, btnDO13.Click, btnDO12.Click, btnDO11.Click, btnDO10.Click
        Dim btn As Button
        btn = CType(sender, Button)

        Dim mbnode As Integer = Val(Combnode.Text)
        Call mbrtuSetDelay(2)
        Dim Index As Integer = Convert.ToInt32(btn.Tag)
        If Index >= 1 And Index <= DONum Then
            If btn.BackColor = Color.FromArgb(0, 255, 0) Then
                If mbrtufcn05(ComPort, mbnode, Index - 1, 1) = 1 Then
                    btn.BackColor = Color.FromArgb(255, 0, 0)
                End If
            Else
                If mbrtufcn05(ComPort, mbnode, Index - 1, 0) = 1 Then
                    btn.BackColor = Color.FromArgb(0, 255, 0)
                End If
            End If
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

    End Sub

End Class