﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class modbusForm
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BtnReadW = New System.Windows.Forms.Button()
        Me.FrameByteStyle = New System.Windows.Forms.GroupBox()
        Me.CombBaudRate = New System.Windows.Forms.ComboBox()
        Me.Combnode = New System.Windows.Forms.ComboBox()
        Me.Usertxt = New System.Windows.Forms.TextBox()
        Me.CommandClose = New System.Windows.Forms.Button()
        Me.CommandOpen = New System.Windows.Forms.Button()
        Me.CombCOM = New System.Windows.Forms.ComboBox()
        Me.LabBaud = New System.Windows.Forms.Label()
        Me.Labnode = New System.Windows.Forms.Label()
        Me.Labuser = New System.Windows.Forms.Label()
        Me.LabCom = New System.Windows.Forms.Label()
        Me.Labcunchu = New System.Windows.Forms.Label()
        Me.Labforce03 = New System.Windows.Forms.Label()
        Me.Labforce02 = New System.Windows.Forms.Label()
        Me.Labforce01 = New System.Windows.Forms.Label()
        Me.Labwrite06 = New System.Windows.Forms.Label()
        Me.Labwrite05 = New System.Windows.Forms.Label()
        Me.Labwrite07 = New System.Windows.Forms.Label()
        Me.Labwrite02 = New System.Windows.Forms.Label()
        Me.Labwrite03 = New System.Windows.Forms.Label()
        Me.Labwrite04 = New System.Windows.Forms.Label()
        Me.Labread03 = New System.Windows.Forms.Label()
        Me.Labread02 = New System.Windows.Forms.Label()
        Me.Labwrite01 = New System.Windows.Forms.Label()
        Me.Labread01 = New System.Windows.Forms.Label()
        Me.Labread05 = New System.Windows.Forms.Label()
        Me.Labread06 = New System.Windows.Forms.Label()
        Me.Labread07 = New System.Windows.Forms.Label()
        Me.Labread04 = New System.Windows.Forms.Label()
        Me.OptionWord02 = New System.Windows.Forms.RadioButton()
        Me.OptionWord01 = New System.Windows.Forms.RadioButton()
        Me.EditbitAddr = New System.Windows.Forms.TextBox()
        Me.EditBitvalue = New System.Windows.Forms.TextBox()
        Me.TimerPlc = New System.Windows.Forms.Timer(Me.components)
        Me.BtnWriteM = New System.Windows.Forms.Button()
        Me.BtnReadM = New System.Windows.Forms.Button()
        Me.Btn_Set = New System.Windows.Forms.Button()
        Me.Btn_ReSet = New System.Windows.Forms.Button()
        Me.SendText5 = New System.Windows.Forms.TextBox()
        Me.SendText4 = New System.Windows.Forms.TextBox()
        Me.SendText3 = New System.Windows.Forms.TextBox()
        Me.SendText2 = New System.Windows.Forms.TextBox()
        Me.SendText1 = New System.Windows.Forms.TextBox()
        Me.SendText0 = New System.Windows.Forms.TextBox()
        Me.ReadText5 = New System.Windows.Forms.TextBox()
        Me.ReadText2 = New System.Windows.Forms.TextBox()
        Me.ReadText0 = New System.Windows.Forms.TextBox()
        Me.ReadText1 = New System.Windows.Forms.TextBox()
        Me.ReadText4 = New System.Windows.Forms.TextBox()
        Me.ReadText3 = New System.Windows.Forms.TextBox()
        Me.BtnWriteW = New System.Windows.Forms.Button()
        Me.FrameByteStyle.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnReadW
        '
        Me.BtnReadW.BackColor = System.Drawing.SystemColors.Control
        Me.BtnReadW.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnReadW.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.BtnReadW.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnReadW.Location = New System.Drawing.Point(322, 134)
        Me.BtnReadW.Name = "BtnReadW"
        Me.BtnReadW.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnReadW.Size = New System.Drawing.Size(120, 24)
        Me.BtnReadW.TabIndex = 52
        Me.BtnReadW.Text = "读PLC值"
        Me.BtnReadW.UseVisualStyleBackColor = False
        '
        'FrameByteStyle
        '
        Me.FrameByteStyle.BackColor = System.Drawing.SystemColors.Control
        Me.FrameByteStyle.Controls.Add(Me.CombBaudRate)
        Me.FrameByteStyle.Controls.Add(Me.Combnode)
        Me.FrameByteStyle.Controls.Add(Me.Usertxt)
        Me.FrameByteStyle.Controls.Add(Me.CommandClose)
        Me.FrameByteStyle.Controls.Add(Me.CommandOpen)
        Me.FrameByteStyle.Controls.Add(Me.CombCOM)
        Me.FrameByteStyle.Controls.Add(Me.LabBaud)
        Me.FrameByteStyle.Controls.Add(Me.Labnode)
        Me.FrameByteStyle.Controls.Add(Me.Labuser)
        Me.FrameByteStyle.Controls.Add(Me.LabCom)
        Me.FrameByteStyle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FrameByteStyle.Location = New System.Drawing.Point(12, 9)
        Me.FrameByteStyle.Name = "FrameByteStyle"
        Me.FrameByteStyle.Padding = New System.Windows.Forms.Padding(0)
        Me.FrameByteStyle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FrameByteStyle.Size = New System.Drawing.Size(432, 85)
        Me.FrameByteStyle.TabIndex = 51
        Me.FrameByteStyle.TabStop = False
        '
        'CombBaudRate
        '
        Me.CombBaudRate.BackColor = System.Drawing.SystemColors.Window
        Me.CombBaudRate.Cursor = System.Windows.Forms.Cursors.Default
        Me.CombBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CombBaudRate.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.CombBaudRate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.CombBaudRate.Items.AddRange(New Object() {"4800", "9600", "19200", "38400", "56000", "57600", "115200"})
        Me.CombBaudRate.Location = New System.Drawing.Point(67, 51)
        Me.CombBaudRate.Name = "CombBaudRate"
        Me.CombBaudRate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CombBaudRate.Size = New System.Drawing.Size(80, 22)
        Me.CombBaudRate.TabIndex = 37
        '
        'Combnode
        '
        Me.Combnode.BackColor = System.Drawing.SystemColors.Window
        Me.Combnode.Cursor = System.Windows.Forms.Cursors.Default
        Me.Combnode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combnode.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Combnode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Combnode.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "129", "130", "131", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200", "201", "202", "203", "204", "205", "206", "207", "208", "209", "210", "211", "212", "213", "214", "215", "216", "217", "218", "219", "220", "221", "222", "223", "224", "225", "226", "227", "228", "229", "230", "231", "232", "233", "234", "235", "236", "237", "238", "239", "240", "241", "242", "243", "244", "245", "246", "247", "248", "249", "250", "251", "252", "253", "254", "255"})
        Me.Combnode.Location = New System.Drawing.Point(212, 51)
        Me.Combnode.Name = "Combnode"
        Me.Combnode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Combnode.Size = New System.Drawing.Size(88, 22)
        Me.Combnode.TabIndex = 7
        '
        'Usertxt
        '
        Me.Usertxt.AcceptsReturn = True
        Me.Usertxt.BackColor = System.Drawing.SystemColors.Window
        Me.Usertxt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Usertxt.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Usertxt.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Usertxt.Location = New System.Drawing.Point(212, 17)
        Me.Usertxt.MaxLength = 0
        Me.Usertxt.Name = "Usertxt"
        Me.Usertxt.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Usertxt.Size = New System.Drawing.Size(87, 23)
        Me.Usertxt.TabIndex = 6
        Me.Usertxt.Text = "lp"
        '
        'CommandClose
        '
        Me.CommandClose.BackColor = System.Drawing.SystemColors.Control
        Me.CommandClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.CommandClose.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.CommandClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CommandClose.Location = New System.Drawing.Point(312, 50)
        Me.CommandClose.Name = "CommandClose"
        Me.CommandClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CommandClose.Size = New System.Drawing.Size(107, 24)
        Me.CommandClose.TabIndex = 4
        Me.CommandClose.Text = "关闭串口"
        Me.CommandClose.UseVisualStyleBackColor = False
        '
        'CommandOpen
        '
        Me.CommandOpen.BackColor = System.Drawing.SystemColors.Control
        Me.CommandOpen.Cursor = System.Windows.Forms.Cursors.Default
        Me.CommandOpen.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.CommandOpen.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CommandOpen.Location = New System.Drawing.Point(312, 19)
        Me.CommandOpen.Name = "CommandOpen"
        Me.CommandOpen.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CommandOpen.Size = New System.Drawing.Size(107, 24)
        Me.CommandOpen.TabIndex = 3
        Me.CommandOpen.Text = "打开串口"
        Me.CommandOpen.UseVisualStyleBackColor = False
        '
        'CombCOM
        '
        Me.CombCOM.BackColor = System.Drawing.SystemColors.Window
        Me.CombCOM.Cursor = System.Windows.Forms.Cursors.Default
        Me.CombCOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CombCOM.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.CombCOM.ForeColor = System.Drawing.SystemColors.WindowText
        Me.CombCOM.Items.AddRange(New Object() {"COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8"})
        Me.CombCOM.Location = New System.Drawing.Point(67, 17)
        Me.CombCOM.Name = "CombCOM"
        Me.CombCOM.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CombCOM.Size = New System.Drawing.Size(80, 22)
        Me.CombCOM.TabIndex = 2
        '
        'LabBaud
        '
        Me.LabBaud.AutoSize = True
        Me.LabBaud.BackColor = System.Drawing.SystemColors.Control
        Me.LabBaud.Cursor = System.Windows.Forms.Cursors.Default
        Me.LabBaud.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.LabBaud.ForeColor = System.Drawing.Color.Black
        Me.LabBaud.Location = New System.Drawing.Point(14, 55)
        Me.LabBaud.Name = "LabBaud"
        Me.LabBaud.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LabBaud.Size = New System.Drawing.Size(56, 14)
        Me.LabBaud.TabIndex = 38
        Me.LabBaud.Text = "波特率:"
        '
        'Labnode
        '
        Me.Labnode.AutoSize = True
        Me.Labnode.BackColor = System.Drawing.SystemColors.Control
        Me.Labnode.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labnode.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labnode.ForeColor = System.Drawing.Color.Black
        Me.Labnode.Location = New System.Drawing.Point(160, 55)
        Me.Labnode.Name = "Labnode"
        Me.Labnode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labnode.Size = New System.Drawing.Size(56, 14)
        Me.Labnode.TabIndex = 8
        Me.Labnode.Text = "从站号:"
        '
        'Labuser
        '
        Me.Labuser.AutoSize = True
        Me.Labuser.BackColor = System.Drawing.SystemColors.Control
        Me.Labuser.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labuser.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labuser.ForeColor = System.Drawing.Color.Black
        Me.Labuser.Location = New System.Drawing.Point(160, 21)
        Me.Labuser.Name = "Labuser"
        Me.Labuser.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labuser.Size = New System.Drawing.Size(56, 14)
        Me.Labuser.TabIndex = 5
        Me.Labuser.Text = "用户名:"
        '
        'LabCom
        '
        Me.LabCom.AutoSize = True
        Me.LabCom.BackColor = System.Drawing.SystemColors.Control
        Me.LabCom.Cursor = System.Windows.Forms.Cursors.Default
        Me.LabCom.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.LabCom.ForeColor = System.Drawing.Color.Black
        Me.LabCom.Location = New System.Drawing.Point(14, 22)
        Me.LabCom.Name = "LabCom"
        Me.LabCom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LabCom.Size = New System.Drawing.Size(56, 14)
        Me.LabCom.TabIndex = 1
        Me.LabCom.Text = "串口号:"
        '
        'Labcunchu
        '
        Me.Labcunchu.AutoSize = True
        Me.Labcunchu.BackColor = System.Drawing.SystemColors.Control
        Me.Labcunchu.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labcunchu.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labcunchu.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labcunchu.Location = New System.Drawing.Point(11, 110)
        Me.Labcunchu.Name = "Labcunchu"
        Me.Labcunchu.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labcunchu.Size = New System.Drawing.Size(140, 14)
        Me.Labcunchu.TabIndex = 89
        Me.Labcunchu.Text = "双字与浮点存储方式:"
        '
        'Labforce03
        '
        Me.Labforce03.AutoSize = True
        Me.Labforce03.BackColor = System.Drawing.SystemColors.Control
        Me.Labforce03.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labforce03.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labforce03.ForeColor = System.Drawing.Color.Black
        Me.Labforce03.Location = New System.Drawing.Point(110, 371)
        Me.Labforce03.Name = "Labforce03"
        Me.Labforce03.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labforce03.Size = New System.Drawing.Size(28, 14)
        Me.Labforce03.TabIndex = 87
        Me.Labforce03.Text = "值:"
        '
        'Labforce02
        '
        Me.Labforce02.AutoSize = True
        Me.Labforce02.BackColor = System.Drawing.SystemColors.Control
        Me.Labforce02.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labforce02.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labforce02.ForeColor = System.Drawing.Color.Black
        Me.Labforce02.Location = New System.Drawing.Point(11, 371)
        Me.Labforce02.Name = "Labforce02"
        Me.Labforce02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labforce02.Size = New System.Drawing.Size(42, 14)
        Me.Labforce02.TabIndex = 81
        Me.Labforce02.Text = "地址:"
        '
        'Labforce01
        '
        Me.Labforce01.AutoSize = True
        Me.Labforce01.BackColor = System.Drawing.SystemColors.Control
        Me.Labforce01.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labforce01.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labforce01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labforce01.Location = New System.Drawing.Point(11, 343)
        Me.Labforce01.Name = "Labforce01"
        Me.Labforce01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labforce01.Size = New System.Drawing.Size(175, 14)
        Me.Labforce01.TabIndex = 80
        Me.Labforce01.Text = "逻辑线圈区(0XXXX)值操作:"
        '
        'Labwrite06
        '
        Me.Labwrite06.AutoSize = True
        Me.Labwrite06.BackColor = System.Drawing.SystemColors.Control
        Me.Labwrite06.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labwrite06.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labwrite06.ForeColor = System.Drawing.Color.Black
        Me.Labwrite06.Location = New System.Drawing.Point(153, 307)
        Me.Labwrite06.Name = "Labwrite06"
        Me.Labwrite06.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labwrite06.Size = New System.Drawing.Size(49, 14)
        Me.Labwrite06.TabIndex = 78
        Me.Labwrite06.Text = "5(字):"
        '
        'Labwrite05
        '
        Me.Labwrite05.AutoSize = True
        Me.Labwrite05.BackColor = System.Drawing.SystemColors.Control
        Me.Labwrite05.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labwrite05.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labwrite05.ForeColor = System.Drawing.Color.Black
        Me.Labwrite05.Location = New System.Drawing.Point(11, 307)
        Me.Labwrite05.Name = "Labwrite05"
        Me.Labwrite05.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labwrite05.Size = New System.Drawing.Size(49, 14)
        Me.Labwrite05.TabIndex = 79
        Me.Labwrite05.Text = "4(字):"
        '
        'Labwrite07
        '
        Me.Labwrite07.AutoSize = True
        Me.Labwrite07.BackColor = System.Drawing.SystemColors.Control
        Me.Labwrite07.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labwrite07.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labwrite07.ForeColor = System.Drawing.Color.Black
        Me.Labwrite07.Location = New System.Drawing.Point(294, 307)
        Me.Labwrite07.Name = "Labwrite07"
        Me.Labwrite07.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labwrite07.Size = New System.Drawing.Size(63, 14)
        Me.Labwrite07.TabIndex = 77
        Me.Labwrite07.Text = "6(浮点):"
        '
        'Labwrite02
        '
        Me.Labwrite02.AutoSize = True
        Me.Labwrite02.BackColor = System.Drawing.SystemColors.Control
        Me.Labwrite02.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labwrite02.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labwrite02.ForeColor = System.Drawing.Color.Black
        Me.Labwrite02.Location = New System.Drawing.Point(11, 274)
        Me.Labwrite02.Name = "Labwrite02"
        Me.Labwrite02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labwrite02.Size = New System.Drawing.Size(49, 14)
        Me.Labwrite02.TabIndex = 73
        Me.Labwrite02.Text = "0(字):"
        '
        'Labwrite03
        '
        Me.Labwrite03.AutoSize = True
        Me.Labwrite03.BackColor = System.Drawing.SystemColors.Control
        Me.Labwrite03.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labwrite03.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labwrite03.ForeColor = System.Drawing.Color.Black
        Me.Labwrite03.Location = New System.Drawing.Point(153, 275)
        Me.Labwrite03.Name = "Labwrite03"
        Me.Labwrite03.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labwrite03.Size = New System.Drawing.Size(49, 14)
        Me.Labwrite03.TabIndex = 72
        Me.Labwrite03.Text = "1(字):"
        '
        'Labwrite04
        '
        Me.Labwrite04.AutoSize = True
        Me.Labwrite04.BackColor = System.Drawing.SystemColors.Control
        Me.Labwrite04.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labwrite04.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labwrite04.ForeColor = System.Drawing.Color.Black
        Me.Labwrite04.Location = New System.Drawing.Point(294, 275)
        Me.Labwrite04.Name = "Labwrite04"
        Me.Labwrite04.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labwrite04.Size = New System.Drawing.Size(63, 14)
        Me.Labwrite04.TabIndex = 71
        Me.Labwrite04.Text = "2(双字):"
        '
        'Labread03
        '
        Me.Labread03.AutoSize = True
        Me.Labread03.BackColor = System.Drawing.SystemColors.Control
        Me.Labread03.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labread03.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labread03.ForeColor = System.Drawing.Color.Black
        Me.Labread03.Location = New System.Drawing.Point(153, 175)
        Me.Labread03.Name = "Labread03"
        Me.Labread03.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labread03.Size = New System.Drawing.Size(49, 14)
        Me.Labread03.TabIndex = 60
        Me.Labread03.Text = "1(字):"
        '
        'Labread02
        '
        Me.Labread02.AutoSize = True
        Me.Labread02.BackColor = System.Drawing.SystemColors.Control
        Me.Labread02.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labread02.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labread02.ForeColor = System.Drawing.Color.Black
        Me.Labread02.Location = New System.Drawing.Point(11, 175)
        Me.Labread02.Name = "Labread02"
        Me.Labread02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labread02.Size = New System.Drawing.Size(49, 14)
        Me.Labread02.TabIndex = 59
        Me.Labread02.Text = "0(字):"
        '
        'Labwrite01
        '
        Me.Labwrite01.AutoSize = True
        Me.Labwrite01.BackColor = System.Drawing.SystemColors.Control
        Me.Labwrite01.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labwrite01.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labwrite01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labwrite01.Location = New System.Drawing.Point(11, 243)
        Me.Labwrite01.Name = "Labwrite01"
        Me.Labwrite01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labwrite01.Size = New System.Drawing.Size(175, 14)
        Me.Labwrite01.TabIndex = 58
        Me.Labwrite01.Text = "混合写存储器区(4XXXX)值:"
        '
        'Labread01
        '
        Me.Labread01.AutoSize = True
        Me.Labread01.BackColor = System.Drawing.SystemColors.Control
        Me.Labread01.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labread01.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labread01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labread01.Location = New System.Drawing.Point(11, 143)
        Me.Labread01.Name = "Labread01"
        Me.Labread01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labread01.Size = New System.Drawing.Size(231, 14)
        Me.Labread01.TabIndex = 57
        Me.Labread01.Text = "循环读取(混合)存储器区(4XXXX)值:"
        '
        'Labread05
        '
        Me.Labread05.AutoSize = True
        Me.Labread05.BackColor = System.Drawing.SystemColors.Control
        Me.Labread05.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labread05.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labread05.ForeColor = System.Drawing.Color.Black
        Me.Labread05.Location = New System.Drawing.Point(11, 207)
        Me.Labread05.Name = "Labread05"
        Me.Labread05.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labread05.Size = New System.Drawing.Size(49, 14)
        Me.Labread05.TabIndex = 67
        Me.Labread05.Text = "4(字):"
        '
        'Labread06
        '
        Me.Labread06.AutoSize = True
        Me.Labread06.BackColor = System.Drawing.SystemColors.Control
        Me.Labread06.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labread06.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labread06.ForeColor = System.Drawing.Color.Black
        Me.Labread06.Location = New System.Drawing.Point(153, 207)
        Me.Labread06.Name = "Labread06"
        Me.Labread06.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labread06.Size = New System.Drawing.Size(49, 14)
        Me.Labread06.TabIndex = 66
        Me.Labread06.Text = "5(字):"
        '
        'Labread07
        '
        Me.Labread07.AutoSize = True
        Me.Labread07.BackColor = System.Drawing.SystemColors.Control
        Me.Labread07.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labread07.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labread07.ForeColor = System.Drawing.Color.Black
        Me.Labread07.Location = New System.Drawing.Point(294, 207)
        Me.Labread07.Name = "Labread07"
        Me.Labread07.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labread07.Size = New System.Drawing.Size(63, 14)
        Me.Labread07.TabIndex = 65
        Me.Labread07.Text = "6(浮点):"
        '
        'Labread04
        '
        Me.Labread04.AutoSize = True
        Me.Labread04.BackColor = System.Drawing.SystemColors.Control
        Me.Labread04.Cursor = System.Windows.Forms.Cursors.Default
        Me.Labread04.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Labread04.ForeColor = System.Drawing.Color.Black
        Me.Labread04.Location = New System.Drawing.Point(294, 175)
        Me.Labread04.Name = "Labread04"
        Me.Labread04.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labread04.Size = New System.Drawing.Size(63, 14)
        Me.Labread04.TabIndex = 61
        Me.Labread04.Text = "2(双字):"
        '
        'OptionWord02
        '
        Me.OptionWord02.BackColor = System.Drawing.SystemColors.Control
        Me.OptionWord02.Cursor = System.Windows.Forms.Cursors.Default
        Me.OptionWord02.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.OptionWord02.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OptionWord02.Location = New System.Drawing.Point(287, 108)
        Me.OptionWord02.Name = "OptionWord02"
        Me.OptionWord02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OptionWord02.Size = New System.Drawing.Size(111, 17)
        Me.OptionWord02.TabIndex = 91
        Me.OptionWord02.TabStop = True
        Me.OptionWord02.Text = "高位在前方式"
        Me.OptionWord02.UseVisualStyleBackColor = False
        '
        'OptionWord01
        '
        Me.OptionWord01.BackColor = System.Drawing.SystemColors.Control
        Me.OptionWord01.Checked = True
        Me.OptionWord01.Cursor = System.Windows.Forms.Cursors.Default
        Me.OptionWord01.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.OptionWord01.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OptionWord01.Location = New System.Drawing.Point(159, 108)
        Me.OptionWord01.Name = "OptionWord01"
        Me.OptionWord01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OptionWord01.Size = New System.Drawing.Size(111, 17)
        Me.OptionWord01.TabIndex = 90
        Me.OptionWord01.TabStop = True
        Me.OptionWord01.Text = "低位在前方式"
        Me.OptionWord01.UseVisualStyleBackColor = False
        '
        'EditbitAddr
        '
        Me.EditbitAddr.AcceptsReturn = True
        Me.EditbitAddr.BackColor = System.Drawing.SystemColors.Window
        Me.EditbitAddr.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.EditbitAddr.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.EditbitAddr.ForeColor = System.Drawing.SystemColors.WindowText
        Me.EditbitAddr.Location = New System.Drawing.Point(52, 367)
        Me.EditbitAddr.MaxLength = 0
        Me.EditbitAddr.Name = "EditbitAddr"
        Me.EditbitAddr.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.EditbitAddr.Size = New System.Drawing.Size(50, 23)
        Me.EditbitAddr.TabIndex = 88
        Me.EditbitAddr.Text = "0"
        '
        'EditBitvalue
        '
        Me.EditBitvalue.AcceptsReturn = True
        Me.EditBitvalue.BackColor = System.Drawing.SystemColors.Window
        Me.EditBitvalue.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.EditBitvalue.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.EditBitvalue.ForeColor = System.Drawing.SystemColors.WindowText
        Me.EditBitvalue.Location = New System.Drawing.Point(135, 367)
        Me.EditBitvalue.MaxLength = 0
        Me.EditBitvalue.Name = "EditBitvalue"
        Me.EditBitvalue.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.EditBitvalue.Size = New System.Drawing.Size(50, 23)
        Me.EditBitvalue.TabIndex = 86
        '
        'TimerPlc
        '
        '
        'BtnWriteM
        '
        Me.BtnWriteM.BackColor = System.Drawing.SystemColors.Control
        Me.BtnWriteM.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnWriteM.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.BtnWriteM.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnWriteM.Location = New System.Drawing.Point(199, 367)
        Me.BtnWriteM.Name = "BtnWriteM"
        Me.BtnWriteM.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnWriteM.Size = New System.Drawing.Size(52, 23)
        Me.BtnWriteM.TabIndex = 85
        Me.BtnWriteM.Text = "写值"
        Me.BtnWriteM.UseVisualStyleBackColor = False
        '
        'BtnReadM
        '
        Me.BtnReadM.BackColor = System.Drawing.SystemColors.Control
        Me.BtnReadM.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnReadM.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.BtnReadM.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnReadM.Location = New System.Drawing.Point(263, 367)
        Me.BtnReadM.Name = "BtnReadM"
        Me.BtnReadM.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnReadM.Size = New System.Drawing.Size(52, 23)
        Me.BtnReadM.TabIndex = 84
        Me.BtnReadM.Text = "读值"
        Me.BtnReadM.UseVisualStyleBackColor = False
        '
        'Btn_Set
        '
        Me.Btn_Set.BackColor = System.Drawing.SystemColors.Control
        Me.Btn_Set.Cursor = System.Windows.Forms.Cursors.Default
        Me.Btn_Set.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Btn_Set.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Btn_Set.Location = New System.Drawing.Point(326, 367)
        Me.Btn_Set.Name = "Btn_Set"
        Me.Btn_Set.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Btn_Set.Size = New System.Drawing.Size(52, 23)
        Me.Btn_Set.TabIndex = 83
        Me.Btn_Set.Text = "置位"
        Me.Btn_Set.UseVisualStyleBackColor = False
        '
        'Btn_ReSet
        '
        Me.Btn_ReSet.BackColor = System.Drawing.SystemColors.Control
        Me.Btn_ReSet.Cursor = System.Windows.Forms.Cursors.Default
        Me.Btn_ReSet.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Btn_ReSet.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Btn_ReSet.Location = New System.Drawing.Point(389, 367)
        Me.Btn_ReSet.Name = "Btn_ReSet"
        Me.Btn_ReSet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Btn_ReSet.Size = New System.Drawing.Size(52, 23)
        Me.Btn_ReSet.TabIndex = 82
        Me.Btn_ReSet.Text = "复位"
        Me.Btn_ReSet.UseVisualStyleBackColor = False
        '
        'SendText5
        '
        Me.SendText5.AcceptsReturn = True
        Me.SendText5.BackColor = System.Drawing.SystemColors.Window
        Me.SendText5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SendText5.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.SendText5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SendText5.Location = New System.Drawing.Point(356, 303)
        Me.SendText5.MaxLength = 0
        Me.SendText5.Name = "SendText5"
        Me.SendText5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SendText5.Size = New System.Drawing.Size(88, 23)
        Me.SendText5.TabIndex = 76
        Me.SendText5.Text = "666.366"
        '
        'SendText4
        '
        Me.SendText4.AcceptsReturn = True
        Me.SendText4.BackColor = System.Drawing.SystemColors.Window
        Me.SendText4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SendText4.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.SendText4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SendText4.Location = New System.Drawing.Point(200, 303)
        Me.SendText4.MaxLength = 0
        Me.SendText4.Name = "SendText4"
        Me.SendText4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SendText4.Size = New System.Drawing.Size(88, 23)
        Me.SendText4.TabIndex = 75
        Me.SendText4.Text = "8686"
        '
        'SendText3
        '
        Me.SendText3.AcceptsReturn = True
        Me.SendText3.BackColor = System.Drawing.SystemColors.Window
        Me.SendText3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SendText3.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.SendText3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SendText3.Location = New System.Drawing.Point(58, 303)
        Me.SendText3.MaxLength = 0
        Me.SendText3.Name = "SendText3"
        Me.SendText3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SendText3.Size = New System.Drawing.Size(88, 23)
        Me.SendText3.TabIndex = 74
        Me.SendText3.Text = "6888"
        '
        'SendText2
        '
        Me.SendText2.AcceptsReturn = True
        Me.SendText2.BackColor = System.Drawing.SystemColors.Window
        Me.SendText2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SendText2.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.SendText2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SendText2.Location = New System.Drawing.Point(356, 271)
        Me.SendText2.MaxLength = 0
        Me.SendText2.Name = "SendText2"
        Me.SendText2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SendText2.Size = New System.Drawing.Size(88, 23)
        Me.SendText2.TabIndex = 70
        Me.SendText2.Text = "6860000"
        '
        'SendText1
        '
        Me.SendText1.AcceptsReturn = True
        Me.SendText1.BackColor = System.Drawing.SystemColors.Window
        Me.SendText1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SendText1.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.SendText1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SendText1.Location = New System.Drawing.Point(200, 271)
        Me.SendText1.MaxLength = 0
        Me.SendText1.Name = "SendText1"
        Me.SendText1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SendText1.Size = New System.Drawing.Size(88, 23)
        Me.SendText1.TabIndex = 69
        Me.SendText1.Text = "2000"
        '
        'SendText0
        '
        Me.SendText0.AcceptsReturn = True
        Me.SendText0.BackColor = System.Drawing.SystemColors.Window
        Me.SendText0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SendText0.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.SendText0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SendText0.Location = New System.Drawing.Point(58, 271)
        Me.SendText0.MaxLength = 0
        Me.SendText0.Name = "SendText0"
        Me.SendText0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SendText0.Size = New System.Drawing.Size(88, 23)
        Me.SendText0.TabIndex = 68
        Me.SendText0.Text = "200"
        '
        'ReadText5
        '
        Me.ReadText5.AcceptsReturn = True
        Me.ReadText5.BackColor = System.Drawing.SystemColors.Window
        Me.ReadText5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ReadText5.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ReadText5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ReadText5.Location = New System.Drawing.Point(356, 203)
        Me.ReadText5.MaxLength = 0
        Me.ReadText5.Name = "ReadText5"
        Me.ReadText5.ReadOnly = True
        Me.ReadText5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReadText5.Size = New System.Drawing.Size(88, 23)
        Me.ReadText5.TabIndex = 64
        '
        'ReadText2
        '
        Me.ReadText2.AcceptsReturn = True
        Me.ReadText2.BackColor = System.Drawing.SystemColors.Window
        Me.ReadText2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ReadText2.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ReadText2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ReadText2.Location = New System.Drawing.Point(356, 171)
        Me.ReadText2.MaxLength = 0
        Me.ReadText2.Name = "ReadText2"
        Me.ReadText2.ReadOnly = True
        Me.ReadText2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReadText2.Size = New System.Drawing.Size(88, 23)
        Me.ReadText2.TabIndex = 54
        '
        'ReadText0
        '
        Me.ReadText0.AcceptsReturn = True
        Me.ReadText0.BackColor = System.Drawing.SystemColors.Window
        Me.ReadText0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ReadText0.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ReadText0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ReadText0.Location = New System.Drawing.Point(58, 171)
        Me.ReadText0.MaxLength = 0
        Me.ReadText0.Name = "ReadText0"
        Me.ReadText0.ReadOnly = True
        Me.ReadText0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReadText0.Size = New System.Drawing.Size(88, 23)
        Me.ReadText0.TabIndex = 56
        '
        'ReadText1
        '
        Me.ReadText1.AcceptsReturn = True
        Me.ReadText1.BackColor = System.Drawing.SystemColors.Window
        Me.ReadText1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ReadText1.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ReadText1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ReadText1.Location = New System.Drawing.Point(200, 171)
        Me.ReadText1.MaxLength = 0
        Me.ReadText1.Name = "ReadText1"
        Me.ReadText1.ReadOnly = True
        Me.ReadText1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReadText1.Size = New System.Drawing.Size(88, 23)
        Me.ReadText1.TabIndex = 55
        '
        'ReadText4
        '
        Me.ReadText4.AcceptsReturn = True
        Me.ReadText4.BackColor = System.Drawing.SystemColors.Window
        Me.ReadText4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ReadText4.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ReadText4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ReadText4.Location = New System.Drawing.Point(200, 203)
        Me.ReadText4.MaxLength = 0
        Me.ReadText4.Name = "ReadText4"
        Me.ReadText4.ReadOnly = True
        Me.ReadText4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReadText4.Size = New System.Drawing.Size(88, 23)
        Me.ReadText4.TabIndex = 63
        '
        'ReadText3
        '
        Me.ReadText3.AcceptsReturn = True
        Me.ReadText3.BackColor = System.Drawing.SystemColors.Window
        Me.ReadText3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ReadText3.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ReadText3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ReadText3.Location = New System.Drawing.Point(58, 203)
        Me.ReadText3.MaxLength = 0
        Me.ReadText3.Name = "ReadText3"
        Me.ReadText3.ReadOnly = True
        Me.ReadText3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReadText3.Size = New System.Drawing.Size(88, 23)
        Me.ReadText3.TabIndex = 62
        '
        'BtnWriteW
        '
        Me.BtnWriteW.BackColor = System.Drawing.SystemColors.Control
        Me.BtnWriteW.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnWriteW.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.BtnWriteW.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnWriteW.Location = New System.Drawing.Point(322, 234)
        Me.BtnWriteW.Name = "BtnWriteW"
        Me.BtnWriteW.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnWriteW.Size = New System.Drawing.Size(120, 24)
        Me.BtnWriteW.TabIndex = 53
        Me.BtnWriteW.Text = "写PLC值"
        Me.BtnWriteW.UseVisualStyleBackColor = False
        '
        'modbusForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(454, 398)
        Me.Controls.Add(Me.EditbitAddr)
        Me.Controls.Add(Me.EditBitvalue)
        Me.Controls.Add(Me.SendText4)
        Me.Controls.Add(Me.SendText3)
        Me.Controls.Add(Me.SendText1)
        Me.Controls.Add(Me.SendText0)
        Me.Controls.Add(Me.ReadText0)
        Me.Controls.Add(Me.ReadText3)
        Me.Controls.Add(Me.ReadText4)
        Me.Controls.Add(Me.ReadText1)
        Me.Controls.Add(Me.BtnReadW)
        Me.Controls.Add(Me.FrameByteStyle)
        Me.Controls.Add(Me.Labcunchu)
        Me.Controls.Add(Me.Labforce03)
        Me.Controls.Add(Me.Labforce02)
        Me.Controls.Add(Me.Labforce01)
        Me.Controls.Add(Me.Labwrite06)
        Me.Controls.Add(Me.Labwrite05)
        Me.Controls.Add(Me.Labwrite02)
        Me.Controls.Add(Me.Labwrite03)
        Me.Controls.Add(Me.Labread03)
        Me.Controls.Add(Me.Labread02)
        Me.Controls.Add(Me.Labwrite01)
        Me.Controls.Add(Me.Labread01)
        Me.Controls.Add(Me.Labread05)
        Me.Controls.Add(Me.Labread06)
        Me.Controls.Add(Me.OptionWord02)
        Me.Controls.Add(Me.OptionWord01)
        Me.Controls.Add(Me.BtnWriteM)
        Me.Controls.Add(Me.BtnReadM)
        Me.Controls.Add(Me.Btn_Set)
        Me.Controls.Add(Me.Btn_ReSet)
        Me.Controls.Add(Me.SendText5)
        Me.Controls.Add(Me.SendText2)
        Me.Controls.Add(Me.ReadText5)
        Me.Controls.Add(Me.ReadText2)
        Me.Controls.Add(Me.BtnWriteW)
        Me.Controls.Add(Me.Labread04)
        Me.Controls.Add(Me.Labwrite04)
        Me.Controls.Add(Me.Labwrite07)
        Me.Controls.Add(Me.Labread07)
        Me.Name = "modbusForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "施耐德modbus rtu协议通信demo"
        Me.FrameByteStyle.ResumeLayout(False)
        Me.FrameByteStyle.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents BtnReadW As System.Windows.Forms.Button
    Public WithEvents FrameByteStyle As System.Windows.Forms.GroupBox
    Public WithEvents CombBaudRate As System.Windows.Forms.ComboBox
    Public WithEvents Combnode As System.Windows.Forms.ComboBox
    Public WithEvents Usertxt As System.Windows.Forms.TextBox
    Public WithEvents CommandClose As System.Windows.Forms.Button
    Public WithEvents CommandOpen As System.Windows.Forms.Button
    Public WithEvents CombCOM As System.Windows.Forms.ComboBox
    Public WithEvents LabBaud As System.Windows.Forms.Label
    Public WithEvents Labnode As System.Windows.Forms.Label
    Public WithEvents Labuser As System.Windows.Forms.Label
    Public WithEvents LabCom As System.Windows.Forms.Label
    Public WithEvents Labcunchu As System.Windows.Forms.Label
    Public WithEvents Labforce03 As System.Windows.Forms.Label
    Public WithEvents Labforce02 As System.Windows.Forms.Label
    Public WithEvents Labforce01 As System.Windows.Forms.Label
    Public WithEvents Labwrite06 As System.Windows.Forms.Label
    Public WithEvents Labwrite05 As System.Windows.Forms.Label
    Public WithEvents Labwrite07 As System.Windows.Forms.Label
    Public WithEvents Labwrite02 As System.Windows.Forms.Label
    Public WithEvents Labwrite03 As System.Windows.Forms.Label
    Public WithEvents Labwrite04 As System.Windows.Forms.Label
    Public WithEvents Labread03 As System.Windows.Forms.Label
    Public WithEvents Labread02 As System.Windows.Forms.Label
    Public WithEvents Labwrite01 As System.Windows.Forms.Label
    Public WithEvents Labread01 As System.Windows.Forms.Label
    Public WithEvents Labread05 As System.Windows.Forms.Label
    Public WithEvents Labread06 As System.Windows.Forms.Label
    Public WithEvents Labread07 As System.Windows.Forms.Label
    Public WithEvents Labread04 As System.Windows.Forms.Label
    Public WithEvents OptionWord02 As System.Windows.Forms.RadioButton
    Public WithEvents OptionWord01 As System.Windows.Forms.RadioButton
    Public WithEvents EditbitAddr As System.Windows.Forms.TextBox
    Public WithEvents EditBitvalue As System.Windows.Forms.TextBox
    Public WithEvents TimerPlc As System.Windows.Forms.Timer
    Public WithEvents BtnWriteM As System.Windows.Forms.Button
    Public WithEvents BtnReadM As System.Windows.Forms.Button
    Public WithEvents Btn_Set As System.Windows.Forms.Button
    Public WithEvents Btn_ReSet As System.Windows.Forms.Button
    Public WithEvents SendText5 As System.Windows.Forms.TextBox
    Public WithEvents SendText4 As System.Windows.Forms.TextBox
    Public WithEvents SendText3 As System.Windows.Forms.TextBox
    Public WithEvents SendText2 As System.Windows.Forms.TextBox
    Public WithEvents SendText1 As System.Windows.Forms.TextBox
    Public WithEvents SendText0 As System.Windows.Forms.TextBox
    Public WithEvents ReadText5 As System.Windows.Forms.TextBox
    Public WithEvents ReadText2 As System.Windows.Forms.TextBox
    Public WithEvents ReadText0 As System.Windows.Forms.TextBox
    Public WithEvents ReadText1 As System.Windows.Forms.TextBox
    Public WithEvents ReadText4 As System.Windows.Forms.TextBox
    Public WithEvents ReadText3 As System.Windows.Forms.TextBox
    Public WithEvents BtnWriteW As System.Windows.Forms.Button

End Class
