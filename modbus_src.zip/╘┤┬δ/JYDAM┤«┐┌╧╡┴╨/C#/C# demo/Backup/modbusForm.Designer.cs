﻿namespace WindowsFormsApplication1
{
    partial class modbusForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ComsetPanel = new System.Windows.Forms.Panel();
            this.Combonode = new System.Windows.Forms.ComboBox();
            this.Labnode = new System.Windows.Forms.Label();
            this.CombBaudRate = new System.Windows.Forms.ComboBox();
            this.LabBaud = new System.Windows.Forms.Label();
            this.ButtonClose = new System.Windows.Forms.Button();
            this.ButtonOpen = new System.Windows.Forms.Button();
            this.Edituser = new System.Windows.Forms.TextBox();
            this.Labuser = new System.Windows.Forms.Label();
            this.Comboxcom = new System.Windows.Forms.ComboBox();
            this.LabelCom = new System.Windows.Forms.Label();
            this.Labcunchu = new System.Windows.Forms.Label();
            this.RadioButtonch1 = new System.Windows.Forms.RadioButton();
            this.RadioButtonch2 = new System.Windows.Forms.RadioButton();
            this.Labread01 = new System.Windows.Forms.Label();
            this.ButtonRead = new System.Windows.Forms.Button();
            this.EditRe01 = new System.Windows.Forms.TextBox();
            this.Labread02 = new System.Windows.Forms.Label();
            this.EditRe02 = new System.Windows.Forms.TextBox();
            this.Labread03 = new System.Windows.Forms.Label();
            this.EditRe03 = new System.Windows.Forms.TextBox();
            this.Labread04 = new System.Windows.Forms.Label();
            this.EditRe06 = new System.Windows.Forms.TextBox();
            this.Labread07 = new System.Windows.Forms.Label();
            this.EditRe05 = new System.Windows.Forms.TextBox();
            this.Labread06 = new System.Windows.Forms.Label();
            this.EditRe04 = new System.Windows.Forms.TextBox();
            this.Labread05 = new System.Windows.Forms.Label();
            this.EditWr06 = new System.Windows.Forms.TextBox();
            this.Labwrite07 = new System.Windows.Forms.Label();
            this.EditWr05 = new System.Windows.Forms.TextBox();
            this.Labwrite06 = new System.Windows.Forms.Label();
            this.EditWr04 = new System.Windows.Forms.TextBox();
            this.Labwrite05 = new System.Windows.Forms.Label();
            this.EditWr03 = new System.Windows.Forms.TextBox();
            this.Labwrite04 = new System.Windows.Forms.Label();
            this.EditWr02 = new System.Windows.Forms.TextBox();
            this.Labwrite03 = new System.Windows.Forms.Label();
            this.EditWr01 = new System.Windows.Forms.TextBox();
            this.Labwrite02 = new System.Windows.Forms.Label();
            this.ButtonWtire = new System.Windows.Forms.Button();
            this.Labwrite01 = new System.Windows.Forms.Label();
            this.LabBit01 = new System.Windows.Forms.Label();
            this.EditBitvalue = new System.Windows.Forms.TextBox();
            this.LabBit03 = new System.Windows.Forms.Label();
            this.EditbitAddr = new System.Windows.Forms.TextBox();
            this.LabBit02 = new System.Windows.Forms.Label();
            this.BtnbitWrite = new System.Windows.Forms.Button();
            this.BtnSet = new System.Windows.Forms.Button();
            this.BtnReset = new System.Windows.Forms.Button();
            this.BtnbitRead = new System.Windows.Forms.Button();
            this.TimerPlc = new System.Windows.Forms.Timer(this.components);
            this.ComsetPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ComsetPanel
            // 
            this.ComsetPanel.BackColor = System.Drawing.SystemColors.Control;
            this.ComsetPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ComsetPanel.Controls.Add(this.Combonode);
            this.ComsetPanel.Controls.Add(this.Labnode);
            this.ComsetPanel.Controls.Add(this.CombBaudRate);
            this.ComsetPanel.Controls.Add(this.LabBaud);
            this.ComsetPanel.Controls.Add(this.ButtonClose);
            this.ComsetPanel.Controls.Add(this.ButtonOpen);
            this.ComsetPanel.Controls.Add(this.Edituser);
            this.ComsetPanel.Controls.Add(this.Labuser);
            this.ComsetPanel.Controls.Add(this.Comboxcom);
            this.ComsetPanel.Controls.Add(this.LabelCom);
            this.ComsetPanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ComsetPanel.Location = new System.Drawing.Point(14, 14);
            this.ComsetPanel.Name = "ComsetPanel";
            this.ComsetPanel.Size = new System.Drawing.Size(501, 88);
            this.ComsetPanel.TabIndex = 0;
            // 
            // Combonode
            // 
            this.Combonode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combonode.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Combonode.FormattingEnabled = true;
            this.Combonode.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50",
            "51",
            "52",
            "53",
            "54",
            "55",
            "56",
            "57",
            "58",
            "59",
            "60",
            "61",
            "62",
            "63",
            "64",
            "65",
            "66",
            "67",
            "68",
            "69",
            "70",
            "71",
            "72",
            "73",
            "74",
            "75",
            "76",
            "77",
            "78",
            "79",
            "80",
            "81",
            "82",
            "83",
            "84",
            "85",
            "86",
            "87",
            "88",
            "89",
            "90",
            "91",
            "92",
            "93",
            "94",
            "95",
            "96",
            "97",
            "98",
            "99",
            "100",
            "101",
            "102",
            "103",
            "104",
            "105",
            "106",
            "107",
            "108",
            "109",
            "110",
            "111",
            "112",
            "113",
            "114",
            "115",
            "116",
            "117",
            "118",
            "119",
            "120",
            "121",
            "122",
            "123",
            "124",
            "125",
            "126",
            "127",
            "128",
            "129",
            "130",
            "131",
            "132",
            "133",
            "134",
            "135",
            "136",
            "137",
            "138",
            "139",
            "140",
            "141",
            "142",
            "143",
            "144",
            "145",
            "146",
            "147",
            "148",
            "149",
            "150",
            "151",
            "152",
            "153",
            "154",
            "155",
            "156",
            "157",
            "158",
            "159",
            "160",
            "161",
            "162",
            "163",
            "164",
            "165",
            "166",
            "167",
            "168",
            "169",
            "170",
            "171",
            "172",
            "173",
            "174",
            "175",
            "176",
            "177",
            "178",
            "179",
            "180",
            "181",
            "182",
            "183",
            "184",
            "185",
            "186",
            "187",
            "188",
            "189",
            "190",
            "191",
            "192",
            "193",
            "194",
            "195",
            "196",
            "197",
            "198",
            "199",
            "200",
            "201",
            "202",
            "203",
            "204",
            "205",
            "206",
            "207",
            "208",
            "209",
            "210",
            "211",
            "212",
            "213",
            "214",
            "215",
            "216",
            "217",
            "218",
            "219",
            "220",
            "221",
            "222",
            "223",
            "224",
            "225",
            "226",
            "227",
            "228",
            "229",
            "230",
            "231",
            "232",
            "233",
            "234",
            "235",
            "236",
            "237",
            "238",
            "239",
            "240",
            "241",
            "242",
            "243",
            "244",
            "245",
            "246",
            "247",
            "248",
            "249",
            "250",
            "251",
            "252",
            "253",
            "254",
            "255"});
            this.Combonode.Location = new System.Drawing.Point(245, 49);
            this.Combonode.Name = "Combonode";
            this.Combonode.Size = new System.Drawing.Size(96, 22);
            this.Combonode.TabIndex = 7;
            // 
            // Labnode
            // 
            this.Labnode.AutoSize = true;
            this.Labnode.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Labnode.Location = new System.Drawing.Point(182, 54);
            this.Labnode.Name = "Labnode";
            this.Labnode.Size = new System.Drawing.Size(56, 14);
            this.Labnode.TabIndex = 6;
            this.Labnode.Text = "从站号:";
            // 
            // CombBaudRate
            // 
            this.CombBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CombBaudRate.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CombBaudRate.FormattingEnabled = true;
            this.CombBaudRate.Items.AddRange(new object[] {
            "4800",
            "9600",
            "19200",
            "38400",
            "56000",
            "57600",
            "115200"});
            this.CombBaudRate.Location = new System.Drawing.Point(78, 49);
            this.CombBaudRate.Name = "CombBaudRate";
            this.CombBaudRate.Size = new System.Drawing.Size(90, 22);
            this.CombBaudRate.TabIndex = 5;
            // 
            // LabBaud
            // 
            this.LabBaud.AutoSize = true;
            this.LabBaud.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LabBaud.Location = new System.Drawing.Point(14, 54);
            this.LabBaud.Name = "LabBaud";
            this.LabBaud.Size = new System.Drawing.Size(56, 14);
            this.LabBaud.TabIndex = 4;
            this.LabBaud.Text = "波特率:";
            // 
            // ButtonClose
            // 
            this.ButtonClose.Location = new System.Drawing.Point(359, 48);
            this.ButtonClose.Name = "ButtonClose";
            this.ButtonClose.Size = new System.Drawing.Size(126, 28);
            this.ButtonClose.TabIndex = 1;
            this.ButtonClose.Text = "关闭串口";
            this.ButtonClose.UseVisualStyleBackColor = true;
            this.ButtonClose.Click += new System.EventHandler(this.ButtonClose_Click);
            // 
            // ButtonOpen
            // 
            this.ButtonOpen.Location = new System.Drawing.Point(359, 12);
            this.ButtonOpen.Name = "ButtonOpen";
            this.ButtonOpen.Size = new System.Drawing.Size(126, 28);
            this.ButtonOpen.TabIndex = 0;
            this.ButtonOpen.Text = "打开串口";
            this.ButtonOpen.UseVisualStyleBackColor = true;
            this.ButtonOpen.Click += new System.EventHandler(this.ButtonOpen_Click);
            // 
            // Edituser
            // 
            this.Edituser.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Edituser.Location = new System.Drawing.Point(245, 14);
            this.Edituser.Name = "Edituser";
            this.Edituser.Size = new System.Drawing.Size(96, 23);
            this.Edituser.TabIndex = 3;
            this.Edituser.Text = "wjun_2008";
            // 
            // Labuser
            // 
            this.Labuser.AutoSize = true;
            this.Labuser.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Labuser.Location = new System.Drawing.Point(182, 19);
            this.Labuser.Name = "Labuser";
            this.Labuser.Size = new System.Drawing.Size(56, 14);
            this.Labuser.TabIndex = 2;
            this.Labuser.Text = "用户名:";
            // 
            // Comboxcom
            // 
            this.Comboxcom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Comboxcom.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Comboxcom.FormattingEnabled = true;
            this.Comboxcom.Items.AddRange(new object[] {
            "COM 1",
            "COM 2",
            "COM 3",
            "COM 4",
            "COM 5",
            "COM 6",
            "COM 7",
            "COM 8"});
            this.Comboxcom.Location = new System.Drawing.Point(78, 14);
            this.Comboxcom.Name = "Comboxcom";
            this.Comboxcom.Size = new System.Drawing.Size(90, 22);
            this.Comboxcom.TabIndex = 2;
            // 
            // LabelCom
            // 
            this.LabelCom.AutoSize = true;
            this.LabelCom.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LabelCom.Location = new System.Drawing.Point(14, 18);
            this.LabelCom.Name = "LabelCom";
            this.LabelCom.Size = new System.Drawing.Size(56, 14);
            this.LabelCom.TabIndex = 0;
            this.LabelCom.Text = "串口号:";
            // 
            // Labcunchu
            // 
            this.Labcunchu.AutoSize = true;
            this.Labcunchu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labcunchu.Location = new System.Drawing.Point(16, 116);
            this.Labcunchu.Name = "Labcunchu";
            this.Labcunchu.Size = new System.Drawing.Size(140, 14);
            this.Labcunchu.TabIndex = 1;
            this.Labcunchu.Text = "双字与浮点存储方式:";
            // 
            // RadioButtonch1
            // 
            this.RadioButtonch1.AutoSize = true;
            this.RadioButtonch1.Checked = true;
            this.RadioButtonch1.Location = new System.Drawing.Point(182, 116);
            this.RadioButtonch1.Name = "RadioButtonch1";
            this.RadioButtonch1.Size = new System.Drawing.Size(109, 18);
            this.RadioButtonch1.TabIndex = 2;
            this.RadioButtonch1.TabStop = true;
            this.RadioButtonch1.Text = "低位在前方式";
            this.RadioButtonch1.UseVisualStyleBackColor = true;
            // 
            // RadioButtonch2
            // 
            this.RadioButtonch2.AutoSize = true;
            this.RadioButtonch2.Location = new System.Drawing.Point(337, 116);
            this.RadioButtonch2.Name = "RadioButtonch2";
            this.RadioButtonch2.Size = new System.Drawing.Size(109, 18);
            this.RadioButtonch2.TabIndex = 3;
            this.RadioButtonch2.Text = "高位在前方式";
            this.RadioButtonch2.UseVisualStyleBackColor = true;
            // 
            // Labread01
            // 
            this.Labread01.AutoSize = true;
            this.Labread01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labread01.Location = new System.Drawing.Point(20, 152);
            this.Labread01.Name = "Labread01";
            this.Labread01.Size = new System.Drawing.Size(231, 14);
            this.Labread01.TabIndex = 4;
            this.Labread01.Text = "循环读取(混合)存储器区(4XXXX)值:";
            // 
            // ButtonRead
            // 
            this.ButtonRead.Location = new System.Drawing.Point(375, 145);
            this.ButtonRead.Name = "ButtonRead";
            this.ButtonRead.Size = new System.Drawing.Size(126, 28);
            this.ButtonRead.TabIndex = 5;
            this.ButtonRead.Text = "读元件值";
            this.ButtonRead.UseVisualStyleBackColor = true;
            this.ButtonRead.Click += new System.EventHandler(this.ButtonRead_Click);
            // 
            // EditRe01
            // 
            this.EditRe01.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditRe01.Location = new System.Drawing.Point(75, 185);
            this.EditRe01.Name = "EditRe01";
            this.EditRe01.Size = new System.Drawing.Size(95, 23);
            this.EditRe01.TabIndex = 6;
            // 
            // Labread02
            // 
            this.Labread02.AutoSize = true;
            this.Labread02.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labread02.Location = new System.Drawing.Point(20, 190);
            this.Labread02.Name = "Labread02";
            this.Labread02.Size = new System.Drawing.Size(49, 14);
            this.Labread02.TabIndex = 7;
            this.Labread02.Text = "0(字):";
            // 
            // EditRe02
            // 
            this.EditRe02.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditRe02.Location = new System.Drawing.Point(235, 185);
            this.EditRe02.Name = "EditRe02";
            this.EditRe02.Size = new System.Drawing.Size(95, 23);
            this.EditRe02.TabIndex = 8;
            // 
            // Labread03
            // 
            this.Labread03.AutoSize = true;
            this.Labread03.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labread03.Location = new System.Drawing.Point(180, 190);
            this.Labread03.Name = "Labread03";
            this.Labread03.Size = new System.Drawing.Size(49, 14);
            this.Labread03.TabIndex = 9;
            this.Labread03.Text = "1(字):";
            // 
            // EditRe03
            // 
            this.EditRe03.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditRe03.Location = new System.Drawing.Point(410, 185);
            this.EditRe03.Name = "EditRe03";
            this.EditRe03.Size = new System.Drawing.Size(100, 23);
            this.EditRe03.TabIndex = 10;
            // 
            // Labread04
            // 
            this.Labread04.AutoSize = true;
            this.Labread04.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labread04.Location = new System.Drawing.Point(340, 190);
            this.Labread04.Name = "Labread04";
            this.Labread04.Size = new System.Drawing.Size(63, 14);
            this.Labread04.TabIndex = 11;
            this.Labread04.Text = "2(双字):";
            // 
            // EditRe06
            // 
            this.EditRe06.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditRe06.Location = new System.Drawing.Point(410, 223);
            this.EditRe06.Name = "EditRe06";
            this.EditRe06.Size = new System.Drawing.Size(100, 23);
            this.EditRe06.TabIndex = 16;
            // 
            // Labread07
            // 
            this.Labread07.AutoSize = true;
            this.Labread07.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labread07.Location = new System.Drawing.Point(340, 228);
            this.Labread07.Name = "Labread07";
            this.Labread07.Size = new System.Drawing.Size(63, 14);
            this.Labread07.TabIndex = 17;
            this.Labread07.Text = "6(浮点):";
            // 
            // EditRe05
            // 
            this.EditRe05.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditRe05.Location = new System.Drawing.Point(235, 223);
            this.EditRe05.Name = "EditRe05";
            this.EditRe05.Size = new System.Drawing.Size(95, 23);
            this.EditRe05.TabIndex = 14;
            // 
            // Labread06
            // 
            this.Labread06.AutoSize = true;
            this.Labread06.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labread06.Location = new System.Drawing.Point(180, 228);
            this.Labread06.Name = "Labread06";
            this.Labread06.Size = new System.Drawing.Size(49, 14);
            this.Labread06.TabIndex = 15;
            this.Labread06.Text = "5(字):";
            // 
            // EditRe04
            // 
            this.EditRe04.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditRe04.Location = new System.Drawing.Point(75, 223);
            this.EditRe04.Name = "EditRe04";
            this.EditRe04.Size = new System.Drawing.Size(95, 23);
            this.EditRe04.TabIndex = 12;
            // 
            // Labread05
            // 
            this.Labread05.AutoSize = true;
            this.Labread05.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labread05.Location = new System.Drawing.Point(20, 228);
            this.Labread05.Name = "Labread05";
            this.Labread05.Size = new System.Drawing.Size(49, 14);
            this.Labread05.TabIndex = 13;
            this.Labread05.Text = "4(字):";
            // 
            // EditWr06
            // 
            this.EditWr06.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditWr06.Location = new System.Drawing.Point(410, 335);
            this.EditWr06.Name = "EditWr06";
            this.EditWr06.Size = new System.Drawing.Size(100, 23);
            this.EditWr06.TabIndex = 30;
            this.EditWr06.Text = "666.386";
            // 
            // Labwrite07
            // 
            this.Labwrite07.AutoSize = true;
            this.Labwrite07.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labwrite07.Location = new System.Drawing.Point(340, 340);
            this.Labwrite07.Name = "Labwrite07";
            this.Labwrite07.Size = new System.Drawing.Size(63, 14);
            this.Labwrite07.TabIndex = 31;
            this.Labwrite07.Text = "6(浮点):";
            // 
            // EditWr05
            // 
            this.EditWr05.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditWr05.Location = new System.Drawing.Point(235, 335);
            this.EditWr05.Name = "EditWr05";
            this.EditWr05.Size = new System.Drawing.Size(95, 23);
            this.EditWr05.TabIndex = 28;
            this.EditWr05.Text = "8686";
            // 
            // Labwrite06
            // 
            this.Labwrite06.AutoSize = true;
            this.Labwrite06.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labwrite06.Location = new System.Drawing.Point(180, 340);
            this.Labwrite06.Name = "Labwrite06";
            this.Labwrite06.Size = new System.Drawing.Size(49, 14);
            this.Labwrite06.TabIndex = 29;
            this.Labwrite06.Text = "5(字):";
            // 
            // EditWr04
            // 
            this.EditWr04.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditWr04.Location = new System.Drawing.Point(75, 335);
            this.EditWr04.Name = "EditWr04";
            this.EditWr04.Size = new System.Drawing.Size(95, 23);
            this.EditWr04.TabIndex = 26;
            this.EditWr04.Text = "6888";
            // 
            // Labwrite05
            // 
            this.Labwrite05.AutoSize = true;
            this.Labwrite05.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labwrite05.Location = new System.Drawing.Point(20, 340);
            this.Labwrite05.Name = "Labwrite05";
            this.Labwrite05.Size = new System.Drawing.Size(49, 14);
            this.Labwrite05.TabIndex = 27;
            this.Labwrite05.Text = "4(字):";
            // 
            // EditWr03
            // 
            this.EditWr03.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditWr03.Location = new System.Drawing.Point(410, 297);
            this.EditWr03.Name = "EditWr03";
            this.EditWr03.Size = new System.Drawing.Size(100, 23);
            this.EditWr03.TabIndex = 24;
            this.EditWr03.Text = "6860000";
            // 
            // Labwrite04
            // 
            this.Labwrite04.AutoSize = true;
            this.Labwrite04.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labwrite04.Location = new System.Drawing.Point(340, 302);
            this.Labwrite04.Name = "Labwrite04";
            this.Labwrite04.Size = new System.Drawing.Size(63, 14);
            this.Labwrite04.TabIndex = 25;
            this.Labwrite04.Text = "2(双字):";
            // 
            // EditWr02
            // 
            this.EditWr02.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditWr02.Location = new System.Drawing.Point(235, 297);
            this.EditWr02.Name = "EditWr02";
            this.EditWr02.Size = new System.Drawing.Size(95, 23);
            this.EditWr02.TabIndex = 22;
            this.EditWr02.Text = "3000";
            // 
            // Labwrite03
            // 
            this.Labwrite03.AutoSize = true;
            this.Labwrite03.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labwrite03.Location = new System.Drawing.Point(180, 302);
            this.Labwrite03.Name = "Labwrite03";
            this.Labwrite03.Size = new System.Drawing.Size(49, 14);
            this.Labwrite03.TabIndex = 23;
            this.Labwrite03.Text = "1(字):";
            // 
            // EditWr01
            // 
            this.EditWr01.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditWr01.Location = new System.Drawing.Point(75, 297);
            this.EditWr01.Name = "EditWr01";
            this.EditWr01.Size = new System.Drawing.Size(95, 23);
            this.EditWr01.TabIndex = 20;
            this.EditWr01.Text = "200";
            // 
            // Labwrite02
            // 
            this.Labwrite02.AutoSize = true;
            this.Labwrite02.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labwrite02.Location = new System.Drawing.Point(20, 302);
            this.Labwrite02.Name = "Labwrite02";
            this.Labwrite02.Size = new System.Drawing.Size(49, 14);
            this.Labwrite02.TabIndex = 21;
            this.Labwrite02.Text = "0(字):";
            // 
            // ButtonWtire
            // 
            this.ButtonWtire.Location = new System.Drawing.Point(375, 257);
            this.ButtonWtire.Name = "ButtonWtire";
            this.ButtonWtire.Size = new System.Drawing.Size(126, 28);
            this.ButtonWtire.TabIndex = 19;
            this.ButtonWtire.Text = "写元件值";
            this.ButtonWtire.UseVisualStyleBackColor = true;
            this.ButtonWtire.Click += new System.EventHandler(this.ButtonWtire_Click);
            // 
            // Labwrite01
            // 
            this.Labwrite01.AutoSize = true;
            this.Labwrite01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Labwrite01.Location = new System.Drawing.Point(20, 264);
            this.Labwrite01.Name = "Labwrite01";
            this.Labwrite01.Size = new System.Drawing.Size(175, 14);
            this.Labwrite01.TabIndex = 18;
            this.Labwrite01.Text = "混合写存储器区(4XXXX)值:";
            // 
            // LabBit01
            // 
            this.LabBit01.AutoSize = true;
            this.LabBit01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.LabBit01.Location = new System.Drawing.Point(20, 376);
            this.LabBit01.Name = "LabBit01";
            this.LabBit01.Size = new System.Drawing.Size(175, 14);
            this.LabBit01.TabIndex = 32;
            this.LabBit01.Text = "逻辑线圈区(0XXXX)值操作:";
            // 
            // EditBitvalue
            // 
            this.EditBitvalue.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditBitvalue.Location = new System.Drawing.Point(185, 405);
            this.EditBitvalue.Name = "EditBitvalue";
            this.EditBitvalue.Size = new System.Drawing.Size(60, 23);
            this.EditBitvalue.TabIndex = 35;
            // 
            // LabBit03
            // 
            this.LabBit03.AutoSize = true;
            this.LabBit03.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.LabBit03.Location = new System.Drawing.Point(155, 410);
            this.LabBit03.Name = "LabBit03";
            this.LabBit03.Size = new System.Drawing.Size(28, 14);
            this.LabBit03.TabIndex = 36;
            this.LabBit03.Text = "值:";
            // 
            // EditbitAddr
            // 
            this.EditbitAddr.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EditbitAddr.Location = new System.Drawing.Point(65, 405);
            this.EditbitAddr.Name = "EditbitAddr";
            this.EditbitAddr.Size = new System.Drawing.Size(80, 23);
            this.EditbitAddr.TabIndex = 33;
            this.EditbitAddr.Text = "0";
            // 
            // LabBit02
            // 
            this.LabBit02.AutoSize = true;
            this.LabBit02.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.LabBit02.Location = new System.Drawing.Point(20, 410);
            this.LabBit02.Name = "LabBit02";
            this.LabBit02.Size = new System.Drawing.Size(42, 14);
            this.LabBit02.TabIndex = 34;
            this.LabBit02.Text = "地址:";
            // 
            // BtnbitWrite
            // 
            this.BtnbitWrite.Location = new System.Drawing.Point(260, 402);
            this.BtnbitWrite.Name = "BtnbitWrite";
            this.BtnbitWrite.Size = new System.Drawing.Size(60, 28);
            this.BtnbitWrite.TabIndex = 37;
            this.BtnbitWrite.Text = "写值";
            this.BtnbitWrite.UseVisualStyleBackColor = true;
            this.BtnbitWrite.Click += new System.EventHandler(this.BtnbitWrite_Click);
            // 
            // BtnSet
            // 
            this.BtnSet.Location = new System.Drawing.Point(325, 402);
            this.BtnSet.Name = "BtnSet";
            this.BtnSet.Size = new System.Drawing.Size(60, 28);
            this.BtnSet.TabIndex = 38;
            this.BtnSet.Text = "置位";
            this.BtnSet.UseVisualStyleBackColor = true;
            this.BtnSet.Click += new System.EventHandler(this.BtnSet_Click);
            // 
            // BtnReset
            // 
            this.BtnReset.Location = new System.Drawing.Point(390, 402);
            this.BtnReset.Name = "BtnReset";
            this.BtnReset.Size = new System.Drawing.Size(60, 28);
            this.BtnReset.TabIndex = 39;
            this.BtnReset.Text = "复位";
            this.BtnReset.UseVisualStyleBackColor = true;
            this.BtnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // BtnbitRead
            // 
            this.BtnbitRead.Location = new System.Drawing.Point(455, 402);
            this.BtnbitRead.Name = "BtnbitRead";
            this.BtnbitRead.Size = new System.Drawing.Size(60, 28);
            this.BtnbitRead.TabIndex = 40;
            this.BtnbitRead.Text = "读值";
            this.BtnbitRead.UseVisualStyleBackColor = true;
            this.BtnbitRead.Click += new System.EventHandler(this.BtnbitRead_Click);
            // 
            // TimerPlc
            // 
            this.TimerPlc.Tick += new System.EventHandler(this.TimerPlc_Tick);
            // 
            // modbusForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 443);
            this.Controls.Add(this.BtnbitRead);
            this.Controls.Add(this.BtnReset);
            this.Controls.Add(this.BtnSet);
            this.Controls.Add(this.BtnbitWrite);
            this.Controls.Add(this.EditBitvalue);
            this.Controls.Add(this.LabBit03);
            this.Controls.Add(this.EditbitAddr);
            this.Controls.Add(this.LabBit02);
            this.Controls.Add(this.LabBit01);
            this.Controls.Add(this.EditWr06);
            this.Controls.Add(this.Labwrite07);
            this.Controls.Add(this.EditWr05);
            this.Controls.Add(this.Labwrite06);
            this.Controls.Add(this.EditWr04);
            this.Controls.Add(this.Labwrite05);
            this.Controls.Add(this.EditWr03);
            this.Controls.Add(this.Labwrite04);
            this.Controls.Add(this.EditWr02);
            this.Controls.Add(this.Labwrite03);
            this.Controls.Add(this.EditWr01);
            this.Controls.Add(this.Labwrite02);
            this.Controls.Add(this.ButtonWtire);
            this.Controls.Add(this.Labwrite01);
            this.Controls.Add(this.EditRe06);
            this.Controls.Add(this.Labread07);
            this.Controls.Add(this.EditRe05);
            this.Controls.Add(this.Labread06);
            this.Controls.Add(this.EditRe04);
            this.Controls.Add(this.Labread05);
            this.Controls.Add(this.EditRe03);
            this.Controls.Add(this.Labread04);
            this.Controls.Add(this.EditRe02);
            this.Controls.Add(this.Labread03);
            this.Controls.Add(this.EditRe01);
            this.Controls.Add(this.Labread02);
            this.Controls.Add(this.ButtonRead);
            this.Controls.Add(this.Labread01);
            this.Controls.Add(this.RadioButtonch2);
            this.Controls.Add(this.RadioButtonch1);
            this.Controls.Add(this.Labcunchu);
            this.Controls.Add(this.ComsetPanel);
            this.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "modbusForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "施耐得modbus rtu协议通信DMEO";
            this.Load += new System.EventHandler(this.modbusForm_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.modbusForm_FormClosing);
            this.ComsetPanel.ResumeLayout(false);
            this.ComsetPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel ComsetPanel;
        private System.Windows.Forms.Label LabelCom;
        private System.Windows.Forms.ComboBox Comboxcom;
        private System.Windows.Forms.Label Labuser;
        private System.Windows.Forms.Button ButtonOpen;
        private System.Windows.Forms.TextBox Edituser;
        private System.Windows.Forms.Button ButtonClose;
        private System.Windows.Forms.ComboBox CombBaudRate;
        private System.Windows.Forms.Label LabBaud;
        private System.Windows.Forms.ComboBox Combonode;
        private System.Windows.Forms.Label Labnode;
        private System.Windows.Forms.Label Labcunchu;
        private System.Windows.Forms.RadioButton RadioButtonch1;
        private System.Windows.Forms.RadioButton RadioButtonch2;
        private System.Windows.Forms.Label Labread01;
        private System.Windows.Forms.Button ButtonRead;
        private System.Windows.Forms.TextBox EditRe01;
        private System.Windows.Forms.Label Labread02;
        private System.Windows.Forms.TextBox EditRe02;
        private System.Windows.Forms.Label Labread03;
        private System.Windows.Forms.TextBox EditRe03;
        private System.Windows.Forms.Label Labread04;
        private System.Windows.Forms.TextBox EditRe06;
        private System.Windows.Forms.Label Labread07;
        private System.Windows.Forms.TextBox EditRe05;
        private System.Windows.Forms.Label Labread06;
        private System.Windows.Forms.TextBox EditRe04;
        private System.Windows.Forms.Label Labread05;
        private System.Windows.Forms.TextBox EditWr06;
        private System.Windows.Forms.Label Labwrite07;
        private System.Windows.Forms.TextBox EditWr05;
        private System.Windows.Forms.Label Labwrite06;
        private System.Windows.Forms.TextBox EditWr04;
        private System.Windows.Forms.Label Labwrite05;
        private System.Windows.Forms.TextBox EditWr03;
        private System.Windows.Forms.Label Labwrite04;
        private System.Windows.Forms.TextBox EditWr02;
        private System.Windows.Forms.Label Labwrite03;
        private System.Windows.Forms.TextBox EditWr01;
        private System.Windows.Forms.Label Labwrite02;
        private System.Windows.Forms.Button ButtonWtire;
        private System.Windows.Forms.Label Labwrite01;
        private System.Windows.Forms.Label LabBit01;
        private System.Windows.Forms.TextBox EditBitvalue;
        private System.Windows.Forms.Label LabBit03;
        private System.Windows.Forms.TextBox EditbitAddr;
        private System.Windows.Forms.Label LabBit02;
        private System.Windows.Forms.Button BtnbitWrite;
        private System.Windows.Forms.Button BtnSet;
        private System.Windows.Forms.Button BtnReset;
        private System.Windows.Forms.Button BtnbitRead;
        private System.Windows.Forms.Timer TimerPlc;


    }
}

