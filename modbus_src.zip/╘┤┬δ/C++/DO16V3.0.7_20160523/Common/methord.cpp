// methord.cpp: implementation of the methord class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "methord.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

uc8 ASIItab[]="0123456789ABCDEF";
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

methord::methord()
{

}

methord::~methord()
{

}

u8 methord::u32tostr(u32 data,u8 *str)
{
	str[0]=ASIItab[(data>>28)&0x0f];
    str[1]=ASIItab[(data>>24)&0x0f];
    str[2]=ASIItab[(data>>20)&0x0f];
    str[3]=ASIItab[(data>>16)&0x0f];
    str[4]=ASIItab[(data>>12)&0x0f];
    str[5]=ASIItab[(data>>8)&0x0f];
    str[6]=ASIItab[(data>>4)&0x0f];
    str[7]=ASIItab[(data>>0)&0x0f];    
    return 8;
}

u8 methord::u16tostr(u16 data, u8 *str)
{
	str[0] = ASIItab[(data>>12)&0x0f];
    str[1] = ASIItab[(data>>8)&0x0f];
    str[2] = ASIItab[(data>>4)&0x0f];
    str[3] = ASIItab[(data>>0)&0x0f];
    return 4;
}

u8 methord::u8tostr(const u8 data, u8 *str)
{
    str[0] = ASIItab[(data>>4)&0x0f];
    str[1] = ASIItab[(data>>0)&0x0f];
    return 2;
}

CString methord::u8tostr(const u8 *data, u16 len)
{
	CString str="";
	CString temp="";
	for (int i = 0; i < len; i++)
	{
		temp.Format(_T("%02X "), data[i]);
		str += temp;
	}
	return str;
}

u8 methord::strtou16(u8 *str, u16 *data)
{
	u8 tm[5];
    if(gsmString2Bytes(str,tm,4)==0)return 0;
    u8tou16(tm,data);
    return 4; 
}

u8 methord::strtou32(u8 *str, u32 *data)
{
	u8 tm[5];
    if(gsmString2Bytes(str,tm,8))return 0;
    u8tou32(tm,data);
    return 8;
}

u8 methord::u8tou16(const u8 *tm, u16 *data)
{
	*data = tm[0];
    *data<<=8;
    *data |= tm[1];
    return 2;   
}

u8 methord::u16tou8(u8 *tm, u16 data)
{
	tm[0] = (data>>8)&0xff;
	tm[1] = data&0xff;
    return 2;  
}

u8 methord::u8tou32(const u8 *tm, u32 *data)
{
	*data = tm[0];*data<<=8;
    *data |= tm[1];*data<<=8;
    *data |= tm[2];*data<<=8;
    *data |= tm[3];
    return 4;   
}

u8 methord::u32tou8(u8 *tm, u32 data)
{
	tm[0] = (u8)((data>>24)&0xff);
	tm[1] = (u8)((data>>16)&0xff);
	tm[2] = (u8)((data>>8)&0xff);
	tm[3] = (u8)(data&0xff);
    return 4;   
}


int methord::autocpy(u8 *dst,const u8 *src,int srclen,int dstlen,u8 ascii)
{
	if(srclen==0) srclen = strlen_1(src);
	if(dstlen==0) dstlen = srclen;
	
	s16 i;
	for( i=0;i<dstlen&&i<srclen;i++)
		dst[i]=src[i];
	for(;i<dstlen;i++)
		dst[i] = ascii;
	
	dst[i] = 0;
	return dstlen;
}

s16 methord::strlen_1(uc8 *src,s16 maxstrlen)
{
	s16 n;
    for ( n = 0; (*src != '\0') && (n < maxstrlen); src++ ) ++n;
    return ( n );
}

s16 methord::FindASCII(u8 *src, u8 ascii, s16 srclen)
{
	s16 i;
    if( srclen <= 0 )
    {
        srclen = strlen_1(src);
    }
	if( ascii == 0 )
    {
        return ( srclen );
    }
    for ( i = 0; i < srclen; i++ )
    {
        if( src[i] == ascii ) return ( i );
    }    
    return ( -1 );
}

s16 methord::gsmString2Bytes(u8 *pSrc, u8 *pDst, s16 nSrcLength)
{
	s16 i;
    for (i = 0; i < nSrcLength; i+=2)
    {
        if ((*pSrc>= '0') && (*pSrc<= '9'))
		{
            *pDst = *pSrc- '0'; 
		}
        else if ((*pSrc>= 'A') && (*pSrc<= 'F'))  /* A....F  */
		{
            *pDst = *pSrc- 'A'+0x0A; 
		}
        else if ((*pSrc>= 'a') && (*pSrc<= 'f'))  /* a....f  */
		{
            *pDst = *pSrc- 'a'+0x0a; 
		}
        else
		{
            return 0;
		} 
		
        *pDst<<=4;
		
        pSrc++;
		
        if ((*pSrc>= '0') && (*pSrc<= '9'))
		{
            *pDst |= *pSrc- '0'; 
		}
        else if ((*pSrc>= 'A') && (*pSrc<= 'F'))  /* A....F  */
		{
            *pDst |= *pSrc- 'A'+0x0A; 
		}
        else if ((*pSrc>= 'a') && (*pSrc<= 'f'))  /* a....f  */
		{
            *pDst |= *pSrc- 'a'+0x0a; 
		}
        else
		{
            return 0;
		} 
		
        pSrc++;
        pDst++;
    } 
    *pDst=0;
    return(nSrcLength / 2);
}

s16 methord::gsmBytes2String(u8 *pSrc, u8 *pDst, s16 nSrcLength)
{
	s16 i;
    for (i = 0; i < nSrcLength; i++)
    {
        *pDst++ = ASIItab[*pSrc >> 4];      // �����4λ
        *pDst++ = ASIItab[*pSrc & 0x0f];    // �����4λ
        pSrc++;
    }
    // ����ַ����Ӹ�������
    *pDst = '\0';
    // ����Ŀ���ַ�������
    return(nSrcLength * 2);
}

void methord::StrSort(CString *StrList, int Comnum)
{
	int i=0,j=0;
    CString StrTemp;
    
	for (i=0; i<Comnum; i++)		  
	{         
		for (j=Comnum-2; j>=i;j--)    
		{                    
			if (StrList[j]>StrList[j+1])       
			{    
				StrTemp=StrList[j];        
				StrList[j]=StrList[j+1];        
				StrList[j+1]=StrTemp;
			}
		} 
	}  
}



int methord::FindCommPort(CString *serial)
{
	HKEY hKey;  
    int rtn;
	int   i=0,Comnum=0;
	
	CString StrTemp;
	
	
    //m_cmbComm.ResetContent();
    rtn = RegOpenKeyEx( HKEY_LOCAL_MACHINE, _T("Hardware\\DeviceMap\\SerialComm"),   
		NULL, KEY_READ, &hKey);  //   �򿪴���ע��� 
    if( rtn == ERROR_SUCCESS)     
    {   
		WCHAR pName[255];
		unsigned char  CName[255];
		LPTSTR    portName = pName;
		LPBYTE commName =CName;
		CString Com, serial_Name;
        DWORD   dwLong,dwSize;   
        while(1)   
        {   
			dwSize = sizeof(pName);
            dwLong   =   dwSize;
            rtn = RegEnumValue( hKey, i, portName, &dwLong,   
				NULL, NULL, commName, &dwSize );
            if( rtn == ERROR_NO_MORE_ITEMS )   //   ö�ٴ���   
                break;      
            i++;   
			
			Com = (LPTSTR)commName;
			serial_Name = (CString)pName;
			
			if(Com.Left(3)=="COM")
			{
				//m_ComBoSerialSet.InsertString(Comnum,Com);
                //������⴮�ڣ����ұ�ʶ����
				if (serial_Name.Left(15)=="\\Device\\VSerial")
				{
					serial[Comnum]=Com+"(V)";
				}
				else
				{
					serial[Comnum]=Com;
				}
				
				Comnum++;
			}
        }   
        RegCloseKey(hKey); 
    }   
	
	//��ȡ�Ĵ����ַ�������
	StrSort(serial,Comnum);
	return Comnum;
}

CString methord::GetAppPath()
{
	TCHAR modulePath[MAX_PATH];
    GetModuleFileName(NULL, modulePath, MAX_PATH);
    CString strModulePath(modulePath);
    strModulePath = strModulePath.Left(strModulePath.ReverseFind(_T('\\')));
    return strModulePath;
}