// ClientComm.cpp: implementation of the CClientComm class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ClientComm.h"
#include "Modbus.h"
#include "MbCommon.h"
#include <winbase.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWinThread* m_IOThread;
UINT ProcessIOEvent( LPVOID pParam );

CClientComm::CClientComm():CnComm()
{
	rcvbufferlen = 0;
	comsetinfo[0] = 38400;
	comsetinfo[1] = 4;
	comsetinfo[2] = 0;
	comsetinfo[3] = 0;

	m_IOThread=::AfxBeginThread(ProcessIOEvent,this);
	SetNotifyThreadId(m_IOThread->m_nThreadID);

	prevSendtime = GetTickCount();
	CloseThread = 0;
	usingflag = 0;
}

CClientComm::~CClientComm()
{
	CloseThread = 1;
	Sleep(100);
	m_IOThread = NULL;
	CloseCom();
}

s16 CClientComm::comsend(u8 *src, s16 srclen)
{
	if(srclen<=0)srclen = methord::strlen_1(src);
	if(IsOpen()==false)return -1;
	
	while(1)
	{
		if(prevSendtime>(GetTickCount()+20))break;
		if(prevSendtime<(GetTickCount()-20))break;
		Sleep(10);
	}
	if(IsOpen()==false)return -1;
	prevSendtime = GetTickCount();

	if (Comm_.IsDebug)
	{
		src[srclen] = 0;

		CString temp = methord::u8tostr(src, srclen);
		info += _T("\r\n����:") + temp;
	}	
	
	if (IsOverlappedMode() || IsTxBufferMode())
		Write(src,srclen);
	else
	{
		//! �����ǻ�����ģʽ �����鷵��ֵ��ȷ��������ȫ���ͳ�
		for (int i = 0; i<srclen; i++ )
			i += Write(src + i, srclen - i);
	}
	return srclen;
}

bool CClientComm::SetComState(s16 status)
{
	bool setok=false;
	if (!IsOpen())return setok;
	
	struct Parity{
		BYTE dwParity;
		TCHAR sParity[24];
	} Paritys[] = 
	{
		{NOPARITY    ,_T("NO")},
		{ODDPARITY   ,_T("ODD")},
		{EVENPARITY  ,_T("EVEN")},
		{MARKPARITY  ,_T("MARK")},
		{SPACEPARITY ,_T("SPACE")}
	};
	
	BYTE ByteSizes[] = {4, 5, 6, 7, 8};
	
	struct StopBit {
		BYTE dwStopBit;
		TCHAR sStopBit[24];
	} StopBits [] = 
	{
		{ONESTOPBIT   ,_T("ONESTOPBIT")},
		{ONE5STOPBITS ,_T("ONE5STOPBITS")},
		{TWOSTOPBITS  ,_T("TWOSTOPBITS")},
	};
	
	//������ ����λ У�鷽ʽ ֹͣλ	
	DCB* pDcb = GetState();	
	
	pDcb->BaudRate = comsetinfo[0];
	pDcb->ByteSize = ByteSizes[comsetinfo[1]%5];
	pDcb->StopBits = StopBits[comsetinfo[3]%3].dwStopBit;
	pDcb->Parity   = Paritys[comsetinfo[2]%5].dwParity;		
	
	
	switch(status)
	{
	case 0x00://�رմ���
		Close();
		setok = true;
		break;
	case 0x01://�򿪴��ڲ�����1		
		setok =SetState(pDcb);
		break;
	}
	
	if(setok==false)
	{
		TCHAR szBuf[1024];
		wsprintf(szBuf, _T("SetState(%d, %d, %d, %d), Fail. Code:%d"), 
			pDcb->BaudRate, 
			Paritys[pDcb->Parity].dwParity, 
			ByteSizes[pDcb->ByteSize], 
			StopBits[pDcb->StopBits].dwStopBit,
			GetLastError());
		MessageBox(NULL,szBuf,_T("Error"),MB_OK);
	}	
	return setok;
}

s16 CClientComm::CloseCom(void)
{
	u16 time=2000;
	while((usingflag)&&(time--))Sleep(10);
	usingflag =1;
	Close();
	usingflag = 0;
	
	return 0;
}
s16 CClientComm::DealReceive(void)
{
	int  srcindex=0;
	long timetemp;

	if(IsOpen()==false) {return -1;}
	u16 time=10;
	while((usingflag)&&(time--))Sleep(10);
	usingflag = 1;
	if(IsOpen()==false) {usingflag=0;return -1;}
	
	//�ȼ�¼����������ĳ��ԭ����Ϊ��ԭ�򣬲�������֮��ʱ�䳤�����治һ��
	do {
		int len = Comm_.Read(rcvingbuf+rcvbufferlen, 2048);		
		if(len<=0) {usingflag=0;return -1;}
		//! ���ջ���ģʽ�£�Ҫȷ�����Ѿ���Comm_.Input()�����������ݴ�����
		//! �������û���µ������������������֪ͨ��
		rcvbufferlen+=len;
		if(rcvbufferlen>MAX_COM_RXBUFF)rcvbufferlen = MAX_COM_RXBUFF;

		if (Comm_.IsDebug)
		{
			rcvingbuf[rcvbufferlen] = 0;

			CString temp = methord::u8tostr(rcvingbuf, rcvbufferlen);
			info += _T("\r\n����:") + temp;
		}
		

		int flag;
		while ((rcvbufferlen-srcindex) >=5)
		{			
				flag = DealCode(rcvingbuf+srcindex,rcvbufferlen-srcindex);
				
				timetemp = prevtime;
				prevtime = 0;
				if (flag == 0)
				{
					if(timetemp==0){prevtime = GetTickCount();break;}
					if(GetTickCount()-timetemp>100)
					{
						srcindex++;
					}
					else
						prevtime = timetemp;
				}
				else if (flag > 0)
				{
					srcindex+=flag;//��ȷ����һ�����ݣ��ӻ������Ƴ����ݡ�
				}
				else
				srcindex++;
		}
		for(int i=0;i<rcvbufferlen-srcindex;i++)
		{
			rcvingbuf[i] = rcvingbuf[srcindex+i];
		}
		rcvbufferlen = rcvbufferlen-srcindex;
	}while(IsRxBufferMode() && Input().SafeSize());

	 usingflag=0;
	 return 0;
}

s16 CClientComm::OpertorDO(s16 ioindex,bool onoff)
{
	u8 src[10];
	u8 dst[255];
	s16 dstlen =0;
	u16 Bit = 0x0001;

	CString temp;
	if(onoff)
	{
		src[0]=0x01;

		temp.Format(_T("\r\n����DO  �򿪵�%d���̵��� "),ioindex+1);
	}
	else
	{
		src[0] = 0x00;
		temp.Format(_T("\r\n����DO  �رյ�%d���̵��� "), ioindex + 1);
	}
	
	RqComm = false;
	Sleep(100);
	info += temp;
	dstlen = CModbus::DealMasterSnd(PROTOCOL_RTU_MODE, equipaddr, 0x05, DO_START+ioindex, 1, src, 1, dst);
	
	DOWriteFLag[0]&=~Bit;
	
	u8 ErrorCnt = 0;
	while(ErrorCnt<3)
	{		
		comsend(dst,dstlen);
		Sleep(200);
		if(DOWriteFLag[0]&Bit)
		{
			DOWriteFLag[0]&=~Bit;
			RqComm = true;
			return 1;			
		}
		ErrorCnt++;
	}
	RqComm = true;
	return 0;
}

s16 CClientComm::OpertorDO(bool onoff)
{
	u8 src[10];
	u8 dst[512];
	s16 dstlen =0;
	u16 Bit = 0x0002;
	if(onoff)
	{
		src[0]=0xff;
		src[1]=0xff;
		src[2] = 0xff;
		src[3] = 0xff;

		info += _T("\r\n����DO ȫ����");
	}
	else 
	{
		src[0]=0x00;
		src[1]=0x00;
		src[2] = 0x00;
		src[3] = 0x00;
		info += _T("\r\n����DO ȫ���ر�");
	}	
	RqComm = false;
	Sleep(100);
	if (DO_CNT<=16)
		dstlen = CModbus::DealMasterSnd(PROTOCOL_RTU_MODE, equipaddr, 15, DO_START, DO_CNT, src, 2, dst);
	else
		dstlen = CModbus::DealMasterSnd(PROTOCOL_RTU_MODE, equipaddr, 15, DO_START, DO_CNT, src, 4, dst);

	DOWriteFLag[0]&=~Bit;
	
	u8 ErrorCnt = 0;
	while(ErrorCnt<3)
	{		
		comsend(dst,dstlen);
		Sleep(200);
		if(DOWriteFLag[0]&Bit)
		{
			DOWriteFLag[0]&=~Bit;
			RqComm = true;
			return 1;			
		}
		ErrorCnt++;
	}
	RqComm = true;
	return 0;
}


s16 CClientComm::AskDI(void)
{
	u8 src[10];
	u8 dst[512];
	s16 dstlen =0;
	
	if(DI_CNT)
	{
		if (Comm_.IsDebug)info += _T("\r\n��ȡDI");
		dstlen = CModbus::DealMasterSnd(PROTOCOL_RTU_MODE, equipaddr, 0x02, DI_START, DI_CNT, src, 1, dst);
		return comsend(dst,dstlen);
	}
	return -1;
}
s16 CClientComm::AskDO(void)
{
	u8 src[10];
	u8 dst[512];
	s16 dstlen =0;
	
	if(DO_CNT)
	{
		if (Comm_.IsDebug)info += _T("\r\n��ȡDO");
		dstlen = CModbus::DealMasterSnd(PROTOCOL_RTU_MODE, equipaddr, 0x01, DO_START, DO_CNT, src, 1, dst);
		return comsend(dst,dstlen);
	}
	return -1;
}
s16 CClientComm::AskAI(void)
{
	u8 src[10];
	u8 dst[512];
	s16 dstlen = 0;

	if (AI_CNT)
	{
		if (Comm_.IsDebug)info += _T("\r\n��ȡAI");
		dstlen = CModbus::DealMasterSnd(PROTOCOL_RTU_MODE, equipaddr, 0x04, AI_START, AI_CNT, src, 1, dst);
		return comsend(dst, dstlen);
	}
	return -1;
}

s16 CClientComm::OpertorRHolding(u16 addr,u16 regstart,u16 regnum)
{
	u16 src[10];
	u8 dst[512];
	s16 dstlen = 0;
	u16 Bit = 0x0001;
	RqComm = false;
	Sleep(100);
	dstlen = CModbus::DealMasterSnd(PROTOCOL_RTU_MODE, addr, 3, regstart, regnum, src, 0, dst);

	HoldReadFLag[0] &= ~Bit;

	u8 ErrorCnt = 0;
	while (ErrorCnt<3)
	{
		comsend(dst, dstlen);
		Sleep(200);
		if (HoldReadFLag[0] & Bit)
		{
			HoldReadFLag[0] &= ~Bit;
			RqComm = true;
			return 1;
		}
		ErrorCnt++;
	}
	RqComm = true;
	return 0;
}
s16 CClientComm::OpertorWHolding(u16 addr, u16 regstart, u16 regnum,void *src)
{
	u8 dst[512];
	s16 dstlen = 0;
	u16 Bit = 0x0001;
	RqComm = false;
	Sleep(100);
	dstlen = CModbus::DealMasterSnd(PROTOCOL_RTU_MODE, addr, 16, regstart, regnum, src, 2 * regnum, dst);

	HoldWriteFLag[0] &= ~Bit;

	u8 ErrorCnt = 0;
	while (ErrorCnt<3)
	{
		comsend(dst, dstlen);
		Sleep(500);
		if (HoldWriteFLag[0] & Bit)
		{
			HoldWriteFLag[0] &= ~Bit;
			RqComm = true;
			return 1;
		}
		ErrorCnt++;
	}
	RqComm = true;
	return 0;
}

s16 CClientComm::OpertorWJD(int jdindex,int mode, int time)
{
	u16 src[10];

	CString temp;
	if (mode == 4)
	{
		temp.Format(_T("\r\n����%d���̵���,����%d.%d�� "), jdindex + 1, time/10,time%10);
	}
	else if (mode == 2)
	{
		temp.Format(_T("\r\n����%d���̵���,����%d.%d�� "), jdindex + 1,time / 10, time % 10);
	}	
	info += temp;

	src[0] = mode;
	src[1] = time;
	return OpertorWHolding(equipaddr, 0 + jdindex*5+3, 2, src);;
}

s16 CClientComm::OpertorRReg(u16 addr, u16 regstart, u16 regnum)
{
	u16 src[10];
	u8 dst[512];
	s16 dstlen = 0;
	u16 Bit = 0x0001;

	RqComm = false;
	Sleep(100);
	dstlen = CModbus::DealMasterSnd(PROTOCOL_RTU_MODE, addr, 4, regstart, regnum, src, 0, dst);

	InputReadFLag[0] &= ~Bit;

	u8 ErrorCnt = 0;
	while (ErrorCnt<3)
	{
		RqComm = false;
		comsend(dst, dstlen);
		Sleep(200);
		if (InputReadFLag[0] & Bit)
		{
			InputReadFLag[0] &= ~Bit;
			RqComm = true;
			return 1;
		}
		ErrorCnt++;
	}
	RqComm = true;
	return 0;
}
s16 CClientComm::OpertorWBaud(int baud232,int baud485)
{
	u16 src[10];
	src[0] = baud485;
	OpertorWHolding(equipaddr, mbBaud2Reg, 1,src);
	src[0] = baud232;
	return OpertorWHolding(equipaddr, mbBaud1Reg, 1, src);;
}

s16 CClientComm::OpertorRBaud()
{
	return OpertorRHolding(equipaddr, mbBaud1Reg, 1);
}


s16 CClientComm::OpertorWBaseAddr(int addr)
{
	u16 src[10];
	src[0] = addr;

	return OpertorWHolding(equipaddr, mbaddrReg, 1, src);
}

s16 CClientComm::OpertorRBaseAddr()
{
	return OpertorRHolding(equipaddr, mbaddrReg, 1);
}


s16 CClientComm::OpertorWWorkmMode(u16 workmode)
{
	u16 src[10];
	src[0] = workmode;

	return OpertorWHolding(equipaddr, mbWorkReg, 1, src);
}

s16 CClientComm::OpertorRWorkmMode()
{
	return OpertorRHolding(equipaddr, mbWorkReg, 1);
}

s16 CClientComm::OpertorWWorkmTime(u16 worktime)
{
	u16 src[10];
	src[0] = worktime;

	return OpertorWHolding(equipaddr, mbWorkTime , 1, src);
}

s16 CClientComm::OpertorRWorkmTime()
{
	return OpertorRHolding(equipaddr, mbWorkTime, 1);
}

s16 CClientComm::OpertorWAO(u16 ao,u16 aodata)
{
	u16 src[10];
	src[0] = aodata;

	return OpertorWHolding(equipaddr, ao, 1, src);
}

s16 CClientComm::OpertorRAO()
{
	return OpertorRHolding(equipaddr, 0, 2);
}



s16 CClientComm::OpertorRAddr()
{
	ReadAddrFlag = 1;
	return OpertorRReg(0xfe, mbRaddrReg, 1);
}

s16 CClientComm::DealCode(u8 *src,s16 srclen)
{
	int srcindex;//���ζ�ȡ�ĳ���

	u8  dst[512];
	s16 dstlen;
	//������Modbus
	if( (srcindex=CMBAscii::eMBASCIIReceive(src,srclen,dst,&dstlen)) >0 ) // ASII ģʽ
    {}
    else if( (srcindex=CMBRtu::eMBRTUReceive(src,srclen,dst,&dstlen))>0 ) // RTU ģʽ
    {}
    else return ( -1 );
	//����������Ϣ������������ϵ���Ϣ�洢�ڼĴ�������		
	if(dst[0]!=equipaddr)return -1;
	
	DealModbus(dst,dstlen);

	return srcindex;
}

s16 CClientComm::DealModbus(u8 *src,s16 srclen)
{
	s16 srcindex=0;	
	u8  Addr = src[srcindex++];
	u8  RegCode = src[srcindex++];
	u16 RegNum =0;
	int i;
	u8  temp;
	switch(RegCode)
	{
		case 1: //1������Ȧ�Ĵ���
			RegNum = src[srcindex++];	
			if(RegNum>0)
			{
				temp = src[srcindex++];
				for(i=0;i<8;i++)
				{
					DOStatus[i] = (temp&0x01)?0x01:0x00;
					temp>>=1;
				}
			}
			if(RegNum>1)
			{
				temp = src[srcindex++];
				for(i=0;i<8;i++)
				{
					DOStatus[8+i] = (temp&0x01)?0x01:0x00;
					temp>>=1;
				}
			}				
			for(i=0;i<10;i++)DOReadFLag[i]|= 0x0001;//�̵�����ȡ�ɹ�	//�̵�����ȡ�ɹ�	
			break;
		case 2: //2����������״̬
			RegNum = src[srcindex++];	
			if(RegNum>0)
			{
				temp = src[srcindex++];
				for(i=0;i<8;i++)
				{
					DIStatus[i] = (temp&0x01)?0x01:0x00;
					temp>>=1;
				}
			}
			if(RegNum>1)
			{
				temp = src[srcindex++];
				for(i=0;i<8;i++)
				{
					DIStatus[8+i] = (temp&0x01)?0x01:0x00;
					temp>>=1;
				}
			}	
			if(RegNum>2)
			{
				temp = src[srcindex++];
				for(i=0;i<8;i++)
				{
					DIStatus[16+i] = (temp&0x01)?0x01:0x00;
					temp>>=1;
				}
			}
			for(i=0;i<10;i++)DIReadFLag[i]|= 0x0001;	
			break;
		case 5:  //5��д������Ȧ�Ĵ���
			for(i=0;i<10;i++)DOWriteFLag[i]|=0x0001;
			break;
		case 15:  //15��д�����Ȧ�Ĵ���
			for(i=0;i<10;i++)DOWriteFLag[i]|=0x0002;
			break;
		case 16:  //15��д������ּĴ���
			for(i=0;i<10;i++)HoldWriteFLag[i]|=0x0001;
			break;
		case 3:  //3����������ּĴ���
			for(i=0;i<10;i++)HoldReadFLag[i]|=0x0001;
			RegNum = src[srcindex++]/2;
			for(i=0;i<RegNum;i++)
			{
				srcindex+=methord::u8tou16(&src[srcindex],&HoldStatus[i]);
			}
			break;
		case 4:  //4�������ֻ���Ĵ���
			for (i = 0; i<10; i++)InputReadFLag[i] |= 0x0001;
			RegNum = src[srcindex++] / 2;
			for (i = 0; i<RegNum; i++)
			{
				srcindex += methord::u8tou16(&src[srcindex], &InputStatus[i]);
			}
			if (RegNum == 1)
			{
				if (ReadAddrFlag == 1)
				{
					ReadAddrFlag = 0;
					ReadAddr = InputStatus[0];
				}			
			}
			break;
		break;

	}
	return 0;
}



UINT ProcessIOEvent( LPVOID pParam )
{		
	s8 okflag=0;
	s8 sendflag=10;
	u16 ovcnt = 0;
	while (true)
	{
		Sleep(10);
		if (Comm_.RqComm)
		{
			ovcnt = 0;
			if ((GetTickCount() - Comm_.prevSendtime) > ((Comm_.IsDebug) ? 3000 : 50))
			{
				Comm_.prevSendtime = GetTickCount();

				sendflag--;
				if (sendflag == 0)
				{
					Comm_.AskDO();
					sendflag = 20;
				}
				else if (sendflag & 0x01)
				{
					Comm_.AskDI();
				}
				else
				{
					Comm_.AskAI();
				}
			}
		}
		else ovcnt++;
		if (ovcnt > 500)
		{
			Comm_.RqComm = true; 
			
		}

		Comm_.DealReceive();
		if(Comm_.CloseThread)return 0;
		if(Comm_.RstThread)
		{
				Comm_.RstThread = 0; 
				sendflag =3;
		}

	}
	return(0);
}