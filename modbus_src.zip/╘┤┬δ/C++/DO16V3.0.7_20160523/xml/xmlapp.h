// xmlapp.h: interface for the xmlapp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XMLAPP_H__3720ADA1_9C4D_4D71_BF12_05061C94B67F__INCLUDED_)
#define AFX_XMLAPP_H__3720ADA1_9C4D_4D71_BF12_05061C94B67F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CXMLApp 
{
public:
	static bool init();

	static bool ReadXmlFile(CString szFileName=__T("�豸��.xml"));
	static bool CreateXmlFile(CString szFileName=__T("�豸��.xml"));

	static bool ReadXmlFile2(CString szFileName = __T("������λ.xml"));
	static bool CreateXmlFile2(CString szFileName = __T("������λ.xml"));

	static bool ReadXmlFile3(CString szFileName = __T("�û�����.xml"));
	static bool CreateXmlFile3(CString szFileName = __T("�û�����.xml"));
	CXMLApp();
	virtual ~CXMLApp();

};

#endif // !defined(AFX_XMLAPP_H__3720ADA1_9C4D_4D71_BF12_05061C94B67F__INCLUDED_)
