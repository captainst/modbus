// xmlapp.cpp: implementation of the xmlapp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "xmlapp.h"
#include "Markup.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXMLApp::CXMLApp()
{

}

CXMLApp::~CXMLApp()
{

}

bool CXMLApp::init()
{
	CString Temp;
	int index = 0;

	for (index = 0; index < EQUIP_MAX_NUM; index++)
	{
		equip[index].init(_T(""), 0, 0, 0, 0, 0, 0, 0, 0, 1000, 1001, 1002, 1003,1004,1000, 0);
	}
	index = 0;
	equip[index++].init(_T("Custom"), 0, 16, 0, 16, 0, 16, 0, 16, 1000, 1001, 1002, 1003, 1004, 1000,1);
	equip[index++].init(_T("DAM0100B"), 1, 0, 0, 0);
	equip[index++].init(_T("DAM0200"), 2, 0, 0, 0);
	equip[index++].init(_T("DAM0204"), 2, 4, 0, 0);
	equip[index++].init(_T("DAM0222"), 2, 2, 2, 0);
	equip[index++].init(_T("DAM0400"), 4, 0, 0, 0);
	equip[index++].init(_T("DAM0404A"), 4, 4, 0, 0);
	equip[index++].init(_T("DAM0800"), 8, 0, 0, 0);
	equip[index++].init(_T("DAM0808"), 8, 8, 0, 0);
	equip[index++].init(_T("DAM1012A"), 10, 0, 12, 0);
	equip[index++].init(_T("DAM1012D"), 10, 12, 0, 0);
	equip[index++].init(_T("DAM1600"), 16, 0, 0, 0);
	equip[index++].init(_T("DAM1616"), 16, 16, 0, 0);
	equip[index++].init(_T("DAM1624"), 16, 24, 0, 0);
	equip[index++].init(_T("DAM2010"), 0, 20, 10, 0);
	equip[index++].init(_T("DAM4400"), 4, 4, 0, 0);
	equip[index++].init(_T("DAM10102"), 10, 10, 2, 0);
	equip[index++].init(_T("DAM14142"), 2, 14, 14, 0);
	equip[index++].init(_T("DAM131421"), 2, 14, 13, 0);
	equip[index++].init(_T("DAM161212"), 16, 12, 12, 0);
	equip[index++].init(_T("DAM0888"), 8, 8, 8, 0);
	equip[index++].init(_T("DAM0816"), 8, 16, 0, 0);
	equip[index++].init(_T("DAM3200A"), 16, 0, 0, 0);
	equip[index++].init(_T("DAM3200B"), 16, 16, 0, 0, 0, 0, 0, 0, 1000, 1001, 1002, 1003, 1004, 1000, 1);

	equip[index++].init(_T("DAM0A02"), 0, 0, 10, 2);

	equip[index++].init(_T("DAM0100A"), 1, 0, 0, 0);
	
	equip[index++].init(_T("DAM4100"), 0, 0, 4, 0);
	equip[index++].init(_T("DAM6640"), 6, 12, 0, 0);
	equip[index++].init(_T("DAM6120"), 9, 0, 12, 0);
	equip[index++].init(_T("DAM0606"), 6, 6, 0, 0);
	equip[index++].init(_T("DAM6600"), 6, 6, 0, 0);
	equip[index++].init(_T("DAMD8100"), 8, 20, 11, 0);
	
	
	equip[index++].init(_T("PT02"), 0, 0, 2, 0);
	equip[index++].init(_T("PT03"), 0, 0, 3, 0);
	equip[index++].init(_T("PT04"), 0, 0, 4, 0);
	equip[index++].init(_T("PT06"), 0, 0, 6, 0);
	equip[index++].init(_T("PT08"), 0, 0, 8, 0);
	equip[index++].init(_T("PT12"), 0, 0, 12, 0);
	equip[index++].init(_T("PT0404"), 4, 0, 4, 0);


	equip[index++].init(_T("DAMDS04"), 0, 0, 4, 0);
	equip[index++].init(_T("DAMDS08"), 0, 0, 8, 0);
	equip[index++].init(_T("DAMDS12"), 0, 0, 12, 0);
	
	
	//DO0400;DO0800;DO1600;DAM6600;USB0100;DAM2010;DAM1010;DAMDD02;DO0200;DO1012;
	

	for (int index = 0; index < EQUIP_DI_NUM; index++)
	{
		Temp.Format(_T("%d#"), index + 1);
		cdi[index].init(Temp, 0, 1);
	}

	for (int index = 0; index < EQUIP_DO_NUM; index++)
	{
		Temp.Format(_T("JD%d"), index + 1);
		cdo[index].init(Temp,0,1);
	}

	for (int index = 0; index < EQUIP_AI_NUM; index++)
	{
		Temp.Format(_T("AI%d"), index + 1);
		cai[index].init(Temp, _T(""),1,0,1);
	}

	cset.comname = _T("COM1");
	cset.baud = _T("9600");
	cset.EquipName = _T("DO0400");
	cset.addr = _T("254");
	return true;
}
bool CXMLApp::CreateXmlFile(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false
	
	
	CMarkup xml;
	xml.SetDoc(__T("<?xml version=\"1.0\"  encoding=\"UTF-8\" ?>\r\n"));
	xml.AddElem(__T("Server"));
	xml.IntoElem();

	xml.AddElem(_T("CompanyInfo"));
	xml.AddAttrib(_T("CompanyName"), CommpanyName);
	//-------------����������Ϣ
	for (int index = 0; index < EQUIP_MAX_NUM; index++)
	{
		Temp.Format(_T("Product_%d"),index+1);
		xml.AddElem(Temp);
		xml.AddAttrib(_T("Name"), equip[index].name);
		xml.AddAttrib(_T("DO_START"), equip[index].doRegStart);
		xml.AddAttrib(_T("DO"), equip[index].donum);
		xml.AddAttrib(_T("DI_START"), equip[index].diRegStart);
		xml.AddAttrib(_T("DI"), equip[index].dinum);
		xml.AddAttrib(_T("AI_START"), equip[index].aiRegStart);
		xml.AddAttrib(_T("AI"), equip[index].ainum);
		xml.AddAttrib(_T("AO_START"), equip[index].aoRegStart);
		xml.AddAttrib(_T("AO"), equip[index].aonum);
		
		xml.AddAttrib(_T("Baud1"), equip[index].mbBaud1Reg);
		xml.AddAttrib(_T("Baud2"), equip[index].mbBaud2Reg);
		xml.AddAttrib(_T("OffsetAddr"), equip[index].mbaddrReg);
		xml.AddAttrib(_T("WorkMode"), equip[index].mbWorkReg);
		xml.AddAttrib(_T("JDTime"), equip[index].mbWorkTime);
		xml.AddAttrib(_T("RAddr"), equip[index].mbRaddrReg);

		xml.AddAttrib(_T("IsValid"), equip[index].IsValid);

	}
	xml.OutOfElem();//Point		
	
	xml.Save(methord::GetAppPath()+"\\"+szFileName);
    return true;
}

bool CXMLApp::ReadXmlFile(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false
	
	
	CMarkup xml; 
	if(xml.Load(methord::GetAppPath()+"\\"+szFileName)==false)return false;
	
	xml.ResetMainPos();
	if ( !(xml.FindElem(__T("Server"))) )
	{		
		return false;
	}
    xml.IntoElem();

	if (xml.FindElem(_T("CompanyInfo")))
	{
		CommpanyName = xml.GetAttrib(_T("CompanyName"));
	}
	
	for (int index = 0; index < EQUIP_MAX_NUM; index++)
	{
		Temp.Format(_T("Product_%d"), index + 1);
		if (xml.FindElem(Temp))
		{			
			equip[index].name = xml.GetAttrib(_T("Name"));
			equip[index].doRegStart = _ttoi(xml.GetAttrib(_T("DO_START")));
			equip[index].donum = _ttoi(xml.GetAttrib(_T("DO")));
			equip[index].diRegStart = _ttoi(xml.GetAttrib(_T("DI_START")));
			equip[index].dinum = _ttoi(xml.GetAttrib(_T("DI")));
			equip[index].aiRegStart = _ttoi(xml.GetAttrib(_T("AI_START")));
			equip[index].ainum = _ttoi(xml.GetAttrib(_T("AI")));
			equip[index].aoRegStart = _ttoi(xml.GetAttrib(_T("AO_START")));
			equip[index].aonum = _ttoi(xml.GetAttrib(_T("AO")));

			equip[index].mbBaud1Reg = _ttoi(xml.GetAttrib(_T("Baud1")));
			equip[index].mbBaud2Reg = _ttoi(xml.GetAttrib(_T("Baud2")));
			equip[index].mbaddrReg = _ttoi(xml.GetAttrib(_T("OffsetAddr")));
			equip[index].mbWorkReg = _ttoi(xml.GetAttrib(_T("WorkMode")));
			equip[index].mbWorkTime = _ttoi(xml.GetAttrib(_T("JDTime")));
			equip[index].mbRaddrReg = _ttoi(xml.GetAttrib(_T("RAddr")));
			equip[index].IsValid = _ttoi(xml.GetAttrib(_T("IsValid")));
		}
	}
	xml.OutOfElem();//
	
    return true;
}



bool CXMLApp::CreateXmlFile2(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false


	CMarkup xml;
	xml.SetDoc(__T("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n"));
	xml.AddElem(__T("Server"));
	xml.IntoElem();

	//-------------����������Ϣ
	for (int index = 0; index < EQUIP_DI_NUM; index++)
	{
		Temp.Format(_T("DI%d"), index + 1);
		xml.AddElem(Temp);
		xml.AddAttrib(_T("Name"), cdi[index].name);
		xml.AddAttrib(_T("Isdir"), cdi[index].Isdir);
		xml.AddAttrib(_T("IsValid"), cdi[index].IsValid);
	}

	for (int index = 0; index < EQUIP_DO_NUM; index++)
	{
		Temp.Format(_T("DO%d"), index + 1);
		xml.AddElem(Temp);
		xml.AddAttrib(_T("Name"), cdo[index].name);
		xml.AddAttrib(_T("Isdir"), cdo[index].Isdir);
		xml.AddAttrib(_T("IsValid"), cdo[index].IsValid);
	}

	for (int index = 0; index < EQUIP_AI_NUM; index++)
	{
		Temp.Format(_T("AI%d"), index + 1);
		xml.AddElem(Temp);
		xml.AddAttrib(_T("Name"), cai[index].name);
		xml.AddAttrib(_T("unit"), cai[index].unit);

		Temp.Format(_T("%f"), cai[index].a);
		xml.AddAttrib(_T("Scale_a"), Temp);
		Temp.Format(_T("%f"), cai[index].b);
		xml.AddAttrib(_T("base_b"), Temp);
		xml.AddAttrib(_T("IsValid"), cai[index].IsValid);
	}
	xml.OutOfElem();//Point		

	xml.Save(methord::GetAppPath() + "\\" + szFileName);
	return true;
}

bool CXMLApp::ReadXmlFile2(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false


	CMarkup xml;
	if (xml.Load(methord::GetAppPath() + "\\" + szFileName) == false)return false;

	xml.ResetMainPos();
	if (!(xml.FindElem(__T("Server"))))
	{
		return false;
	}
	xml.IntoElem();

	for (int index = 0; index < EQUIP_DI_NUM; index++)
	{
		Temp.Format(_T("DI%d"), index + 1);
		if (xml.FindElem(Temp))
		{
			cdi[index].name = xml.GetAttrib(_T("Name"));
			cdi[index].Isdir = _ttoi(xml.GetAttrib(_T("Isdir")));
			cdi[index].IsValid = _ttoi(xml.GetAttrib(_T("IsValid")));
		}
	}

	for (int index = 0; index < EQUIP_DO_NUM; index++)
	{
		Temp.Format(_T("DO%d"), index + 1);
		if (xml.FindElem(Temp))
		{
			cdo[index].name = xml.GetAttrib(_T("Name"));
			cdo[index].Isdir = _ttoi(xml.GetAttrib(_T("Isdir")));
			cdo[index].IsValid = _ttoi(xml.GetAttrib(_T("IsValid")));
		}
	}

	for (int index = 0; index < EQUIP_AI_NUM; index++)
	{
		Temp.Format(_T("AI%d"), index + 1);
		if (xml.FindElem(Temp))
		{
			cai[index].name = xml.GetAttrib(_T("Name"));
			cai[index].unit = xml.GetAttrib(_T("unit"));
			cai[index].a = _ttof(xml.GetAttrib(_T("Scale_a")));
			cai[index].b = _ttof(xml.GetAttrib(_T("base_b")));
			cai[index].IsValid = _ttoi(xml.GetAttrib(_T("IsValid")));
		}
	}
	xml.OutOfElem();//

	return true;
}



bool CXMLApp::CreateXmlFile3(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false


	CMarkup xml;
	xml.SetDoc(__T("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n"));
	xml.AddElem(__T("Server"));
	xml.IntoElem();

	//-------------����������Ϣ
	xml.AddElem(__T("ComName"), cset.comname);
	xml.AddElem(__T("Baud"), cset.baud);
	xml.AddElem(__T("EquipName"), cset.EquipName);
	xml.AddElem(__T("Addr"), cset.addr);
	xml.OutOfElem();//Point		

	xml.Save(methord::GetAppPath() + "\\" + szFileName);
	return true;
}

bool CXMLApp::ReadXmlFile3(CString szFileName)
{
	CString Temp;
	//����xml�ļ�,szFilePathΪ�ļ������·��,�������ɹ�����true,����false


	CMarkup xml;
	if (xml.Load(methord::GetAppPath() + "\\" + szFileName) == false)return false;

	xml.ResetMainPos();
	if (!(xml.FindElem(__T("Server"))))
	{
		return false;
	}
	xml.IntoElem();
	if (xml.FindElem(__T("ComName")))	cset.comname = (xml.GetData());//
	if (xml.FindElem(__T("Baud")))cset.baud = (xml.GetData());//
	if (xml.FindElem(__T("EquipName")))	cset.EquipName = (xml.GetData());//
	if (xml.FindElem(__T("Addr")))	cset.addr = (xml.GetData());//
	xml.OutOfElem();//

	return true;
}
