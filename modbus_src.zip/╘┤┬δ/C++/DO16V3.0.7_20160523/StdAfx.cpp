// stdafx.cpp : source file that includes just the standard includes
//	DO16.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

CClientComm Comm_;  //���ڽӿ�
CEquip_TCB equip[EQUIP_MAX_NUM];
CDI_TCB  cdi[EQUIP_DI_NUM];
CDO_TCB  cdo[EQUIP_DO_NUM];
CCAI_TCB  cai[EQUIP_AI_NUM];
CDefaultSet_TCB cset;
CString CommpanyName=_T("������Ӣ����������޹�˾");