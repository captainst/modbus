// Modbus.h: interface for the CModbus class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MODBUS_H__D2E90436_5908_4CF3_B6A8_E860A267DC7D__INCLUDED_)
#define AFX_MODBUS_H__D2E90436_5908_4CF3_B6A8_E860A267DC7D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define  PROTOCOL_ASCII_MODE 0
#define  PROTOCOL_RTU_MODE   1
class CModbus  
{
public:

	static s16 DealMasterSnd(u8 protocolsMode,u8 Addr, u8 RegCode, u16 RegStart, u16 RegNum, void *src,s16 srclen,u8 *dst);
	
	CModbus();
	virtual ~CModbus();	
};

#endif // !defined(AFX_MODBUS_H__D2E90436_5908_4CF3_B6A8_E860A267DC7D__INCLUDED_)
