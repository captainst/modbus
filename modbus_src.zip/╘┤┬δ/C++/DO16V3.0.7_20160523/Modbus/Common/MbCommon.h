// MbCommon.h: interface for the CMbCommon class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MBCOMMON_H__87644618_C749_4EDA_8470_7ED1C7DFA22E__INCLUDED_)
#define AFX_MBCOMMON_H__87644618_C749_4EDA_8470_7ED1C7DFA22E__INCLUDED_

#include "MBAscii.h"
#include "MBRtu.h"
#include "MBUtils.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define U16_WRITE_REG  0x01
#define U16_READ_REG   0x02
#define BIT_WRITE_REG  0x03
#define BIT_READ_REG   0x04
class CMbCommon  
{
public:

	static s16 eMBinfoSnd(u8 *src, s16 srclen,u8 *dst,u8 protocolsMode);
	CMbCommon();
	virtual ~CMbCommon();

};

#endif // !defined(AFX_MBCOMMON_H__87644618_C749_4EDA_8470_7ED1C7DFA22E__INCLUDED_)
