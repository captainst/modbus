// MBUtils.h: interface for the CMBUtils class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MBUTILS_H__E53FE03A_5CC9_4C0E_AD4A_FFC3B06D7198__INCLUDED_)
#define AFX_MBUTILS_H__E53FE03A_5CC9_4C0E_AD4A_FFC3B06D7198__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMBUtils  
{
public:
	static u8   xMBUtilGetBits(u8 *ucByteBuf, u16 usBitOffset, u8 ucNBits);
	static void xMBUtilSetBits(u8 *ucByteBuf, u16 usBitOffset, u8 ucNBits, u8 ucValue);
	CMBUtils();
	virtual ~CMBUtils();

};

#endif // !defined(AFX_MBUTILS_H__E53FE03A_5CC9_4C0E_AD4A_FFC3B06D7198__INCLUDED_)
