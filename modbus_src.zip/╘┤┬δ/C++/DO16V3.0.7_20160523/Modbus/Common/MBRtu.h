// MBRtu.h: interface for the CMBRtu class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MBRTU_H__E79DF892_4E52_44CE_A9EE_FED4E2DB0F24__INCLUDED_)
#define AFX_MBRTU_H__E79DF892_4E52_44CE_A9EE_FED4E2DB0F24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMBRtu  
{
public:
	static s16 eMBRTUSend(u8 *src, s16 srclen,u8 *dst);
	static s16 eMBRTUReceive(u8 *src, s16 srclen,u8 *dst,s16 *dstlen);
	static u16 usMBCRC16(u8 *src, s16 srclen);
	CMBRtu();
	virtual ~CMBRtu();

};

#endif // !defined(AFX_MBRTU_H__E79DF892_4E52_44CE_A9EE_FED4E2DB0F24__INCLUDED_)
