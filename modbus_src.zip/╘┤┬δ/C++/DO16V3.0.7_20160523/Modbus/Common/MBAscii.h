// MBAscii.h: interface for the CMBAscii class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MBASCII_H__674D9020_BA0B_4BD6_B6F1_1E17E998125E__INCLUDED_)
#define AFX_MBASCII_H__674D9020_BA0B_4BD6_B6F1_1E17E998125E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMBAscii  
{
public:
	static s16 eMBASCIISend(u8 *src, s16 srclen,u8 *dst);
	static s16 eMBASCIIReceive(u8 *src, s16 srclen,u8 *dst,s16 *dstlen);
	static u8  prvucMBLRC(u8 *src, s16 srclen);
	CMBAscii();
	virtual ~CMBAscii();

};

#endif // !defined(AFX_MBASCII_H__674D9020_BA0B_4BD6_B6F1_1E17E998125E__INCLUDED_)
