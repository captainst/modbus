/**
  ******************************************************************************
  * @file    MBAscii.cpp
  * @author  ������Ӣ����������޹�˾ ����
  * @version V1.0.0
  * @date    2012��12��28��
  **@brief   Modbus AsciiЭ��
  * @details implementation of the CMBAscii class. 
  ******************************************************************************
**/
#include "stdafx.h"
#include "MBAscii.h"
#include "methord.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMBAscii::CMBAscii()
{

}

CMBAscii::~CMBAscii()
{

}

u8 CMBAscii::prvucMBLRC(u8 *src, s16 usLen)
{
	u8  ucLRC = 0;  /* LRC char initialized */
	
    while ( usLen-- )
    {
        ucLRC += *src++;   /* Add buffer byte without carry */
    }
    return ( -ucLRC );
}


s16 CMBAscii::eMBASCIIReceive(u8 *src, s16 srclen,u8 *dst,s16 *dstlen)
{
	if(src[0] != ':')return -1;
	srclen = methord::FindASCII(src,0x0A,srclen);
	if(srclen<9)return -1;
	srclen+=1;
	if(src[srclen - 1]!= 0x0A)return -1;
	if(src[srclen - 2]!= 0x0D)return -1;
	
	
	*dstlen = methord::gsmString2Bytes(src + 1, dst, srclen - 3);
    /* Length and CRC check */
    if( prvucMBLRC(dst, *dstlen) == 0)
	{
		*dstlen-=1;
		return ( srclen );
    }
	else 
		return -1;    
}

s16 CMBAscii::eMBASCIISend(u8 *src, s16 srclen,u8 *dst)
{
	s16 dev = 0;
    src[srclen] = prvucMBLRC(src, srclen);
    dst[dev++] = ':';	
    dev += methord::gsmBytes2String(src, dst + dev, srclen + 1);
    dst[dev++] = 0x0D;
    dst[dev++] = 0x0A;
	dst[dev] = 0x00;
    /* Activate the transmitter. */
    return ( dev );
}
