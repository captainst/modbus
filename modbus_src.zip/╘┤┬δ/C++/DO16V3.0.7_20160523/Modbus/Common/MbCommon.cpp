/**
  ******************************************************************************
  * @file    MbCommon.cpp
  * @author  ������Ӣ����������޹�˾ ����
  * @version V1.0.0
  * @date    2012��12��28��
  **@brief   Modbus ���͡��Ĵ����ӿ�
  * @details implementation of the CMbCommon class.
  ******************************************************************************
**/

#include "stdafx.h"
#include "MbCommon.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMbCommon::CMbCommon()
{

}

CMbCommon::~CMbCommon()
{

}

s16 CMbCommon::eMBinfoSnd(u8 *src, s16 srclen,u8 *dst,u8 protocolsMode)
{
	//Ϊ����
    if( protocolsMode == 0 ) //ASII mode
    {
        return CMBAscii::eMBASCIISend(src, srclen,dst);
    }
    else if( protocolsMode == 1 ) //RTU mode
    {
        return CMBRtu::eMBRTUSend(src, srclen,dst);
    }
    else if( protocolsMode == 2 ) //other mode
    {}
    return ( -2 );
}
