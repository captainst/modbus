// Modbus.cpp: implementation of the CModbus class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Modbus.h"
#include "methord.h"
#include "MBAscii.h"
#include "MBRtu.h"
#include "MBUtils.h"
#include "MBMaster.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CModbus::CModbus()
{

}

CModbus::~CModbus()
{

}


s16 CModbus::DealMasterSnd(u8 protocolsMode,u8 Addr, u8 RegCode, u16 RegStart, u16 RegNum, void *src,s16 srclen,u8 *dst)
{
	return CMBMaster::MBMasterSnd(protocolsMode,Addr,RegCode,RegStart,RegNum,src,srclen,dst);	
}
