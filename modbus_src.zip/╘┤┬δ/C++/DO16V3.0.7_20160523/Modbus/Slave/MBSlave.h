// MBSlave.h: interface for the MBSlave class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MBSLAVE_H__E8992B00_4471_47FA_985A_EB7B605AA335__INCLUDED_)
#define AFX_MBSLAVE_H__E8992B00_4471_47FA_985A_EB7B605AA335__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class MBSlave  
{
public:
	MBSlave();
	virtual ~MBSlave();

};

#endif // !defined(AFX_MBSLAVE_H__E8992B00_4471_47FA_985A_EB7B605AA335__INCLUDED_)
