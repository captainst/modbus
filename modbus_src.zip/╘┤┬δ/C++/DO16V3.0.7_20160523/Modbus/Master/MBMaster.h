// MBMaster.h: interface for the CMBMaster class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MBMASTER_H__BA018233_869A_4984_969F_AAF095911920__INCLUDED_)
#define AFX_MBMASTER_H__BA018233_869A_4984_969F_AAF095911920__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMBMaster  
{
public:
	CMBMaster();
	virtual ~CMBMaster();

	static s16 MBMasterSnd(u8 protocolsMode,u8 Addr,u8 RegCode,u16 RegStart,u16 RegNum,void *src,s16 srclen,u8 *dst);
	/*static s16 MBMasterRcv(MBREG_TCB *reg_ptr,MBInfo_TCB *mbinfo_ptr);*/

};

#endif // !defined(AFX_MBMASTER_H__BA018233_869A_4984_969F_AAF095911920__INCLUDED_)
