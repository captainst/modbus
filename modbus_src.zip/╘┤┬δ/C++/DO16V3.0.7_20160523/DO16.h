// DO16.h : main header file for the DO16 application
//

#if !defined(AFX_DO16_H__63052978_E7B6_4ECF_A17B_67805EF095DC__INCLUDED_)
#define AFX_DO16_H__63052978_E7B6_4ECF_A17B_67805EF095DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDO16App:
// See DO16.cpp for the implementation of this class
//

class CDO16App : public CWinApp
{
public:
	CDO16App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDO16App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDO16App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DO16_H__63052978_E7B6_4ECF_A17B_67805EF095DC__INCLUDED_)
