// DO16Dlg.h : header file
//

#include "afxwin.h"
#include "afxcmn.h"
#if !defined(AFX_DO16DLG_H__A2538541_32D4_453C_A89E_FA23F40D66B4__INCLUDED_)
#define AFX_DO16DLG_H__A2538541_32D4_453C_A89E_FA23F40D66B4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDO16Dlg dialog

class CDO16Dlg : public CDialog
{
// Construction
public:
	CDO16Dlg(CWnd* pParent = NULL);	// standard constructor
	void initCommPort();
	void ShowINfo(CString info);
	void DealButton(int btnindex);
	void ShowDebugText(CString str);
	void ShowDO();
	void ShowDI();
	void ShowAI();
	void TabInitial();
	void OnBnClickedBtnWriteao(int addr, int data);
	HICON  hIcons[6];//���ڹ� ���ڿ�     �̵����Ͽ�  �̵����պ�
// Dialog Data
	//{{AFX_DATA(CDO16Dlg)
	enum { IDD = IDD_DO16_DIALOG };
	CStatic	m_ICO_DI10;
	CStatic	m_ICO_DI9;
	CStatic	m_ICO_DI8;
	CStatic	m_ICO_DI7;
	CStatic	m_ICO_DI6;
	CStatic	m_ICO_DI5;
	CStatic	m_ICO_DI4;
	CStatic	m_ICO_DI3;
	CStatic	m_ICO_DI2;
	CStatic	m_ICO_DI16;
	CStatic	m_ICO_DI15;
	CStatic	m_ICO_DI14;
	CStatic	m_ICO_DI13;
	CStatic	m_ICO_DI12;
	CStatic	m_ICO_DI11;
	CStatic	m_ICO_DI1;
	CStatic	m_ICO_JD9;
	CStatic	m_ICO_JD8;
	CStatic	m_ICO_JD7;
	CStatic	m_ICO_JD6;
	CStatic	m_ICO_JD5;
	CStatic	m_ICO_JD4;
	CStatic	m_ICO_JD3;
	CStatic	m_ICO_JD2;
	CStatic	m_ICO_JD1;
	CStatic	m_ICO_JD16;
	CStatic	m_ICO_JD15;
	CStatic	m_ICO_JD14;
	CStatic	m_ICO_JD13;
	CStatic	m_ICO_JD12;
	CStatic	m_ICO_JD11;
	CStatic	m_ICO_JD10;
	CStatic	m_bmpStatus;
	CComboBox	m_ctrcomport;//����ѡ��
	CString	m_BaudRate;
	UINT	m_addr;
//	CString	m_EquipType;
	int		m_selectmode;
	BOOL m_bExpertMode;

	CRect		m_RectDlg;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDO16Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CStatusBarCtrl m_StatusBar;//״̬��
	
	// Generated message map functions
	//{{AFX_MSG(CDO16Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg bool OpenComm(u8 mbaddr);
	afx_msg void OnBtnOpen();
	afx_msg void OnBtnJd1();
	afx_msg void OnBtnJd2();
	afx_msg void OnBtnJd3();
	afx_msg void OnBtnJd4();
	afx_msg void OnBtnJd5();
	afx_msg void OnBtnJd6();
	afx_msg void OnBtnJd7();
	afx_msg void OnBtnJd8();
	afx_msg void OnBtnJd9();
	afx_msg void OnBtnJd10();
	afx_msg void OnBtnJd11();
	afx_msg void OnBtnJd12();
	afx_msg void OnBtnJd13();
	afx_msg void OnBtnJd14();
	afx_msg void OnBtnJd15();
	afx_msg void OnBtnJd16();
	afx_msg void OnBtnOpenall();
	afx_msg void OnBtnCloseall();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnChangeEditAddr();
	afx_msg void OnSelchangeComboEquiptype();
	afx_msg void OnBtnAll();
	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnCloseall2();
	afx_msg void OnBnClickedExpertMode();
	afx_msg void OnBnClickedBtnCloseall3();
	afx_msg void OnBnClickedBtnSetbaud();
	afx_msg void OnBnClickedBtnReadbaud();
	afx_msg void OnOK();
//	int m_baud232;
//	int m_baud485;
	CStatic m_ICO_DI17;
	CStatic m_ICO_DI18;
	CStatic m_ICO_DI19;
	CStatic m_ICO_DI20;
	CListCtrl m_ctrllist;
	CComboBox m_CtlEquipType;
	CString m_strCom;
	afx_msg void OnEnChangeRichedit21();
	CString m_txthelp;
	afx_msg void OnBnClickedBtnOpenall2();
	afx_msg void OnBnClickedBtnOpenall4();
	afx_msg void OnBnClickedBtnOpenall3();
	CString m_txtDebug;

	afx_msg void OnCbnSelchangeComboBaudrate232();
	afx_msg void OnCbnSelchangeComboBaudrate485();
	BOOL m_debug;
	afx_msg void OnBnClickedCheck1();
	CEdit m_ctledit;
	afx_msg void OnBnClickedBtnSetbaud2();
//	CTabCtrl m_Tab;
	afx_msg void OnBnClickedBtnReadbaseaddr();
	afx_msg void OnBnClickedBtnWritebaseaddr();
	UINT m_BaseAddr;
	afx_msg void OnBnClickedBtnReadaddr();
	afx_msg void OnEnChangeEditBaseaddr();
	afx_msg void OnLvnItemchangedList3(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnReadjdtime();
	int m_JDTime;
	afx_msg void OnBnClickedBtnWritejdtime();
	afx_msg void OnBnClickedBtnReadworkmode();
	afx_msg void OnBnClickedBtnWriteworkmode();
	afx_msg void OnBnClickedBtnOpen2();
	afx_msg void OnEnChangeEditJdtime();
	afx_msg void OnEnChangeEditTime();
//	CString m_opertime;
	int m_opertime;
	int m_ao1;
	int m_ao2;
	
	afx_msg void OnBnClickedBtnReadao1();
	afx_msg void OnBnClickedBtnWriteao1();
	afx_msg void OnBnClickedBtnReadao2();
	afx_msg void OnBnClickedBtnWriteao2();
	afx_msg void OnEnChangeEditAo1();
	afx_msg void OnEnChangeEditAo2();
	afx_msg void OnBnClickedBtnWriteao3();
	afx_msg void OnBnClickedBtnWriteao4();
	afx_msg void OnBnClickedBtnWriteao5();
	afx_msg void OnBnClickedBtnWriteao6();
	afx_msg void OnBnClickedBtnWriteao7();
	afx_msg void OnBnClickedBtnWriteao8();
	afx_msg void OnBnClickedBtnWriteao9();
	afx_msg void OnBnClickedBtnWriteao10();
	afx_msg void OnBnClickedBtnWriteao11();
	afx_msg void OnBnClickedBtnWriteao12();
	int m_ao3;
	int m_ao4;
	int m_ao5;
	int m_ao6;
	int m_ao7;
	int m_ao8;
	int m_ao9;
	int m_ao10;
	int m_ao11;
	int m_ao12;
	afx_msg void OnEnChangeEditAo3();
	afx_msg void OnEnChangeEditAo4();
	afx_msg void OnEnChangeEditAo5();
	afx_msg void OnEnChangeEditAo6();
	afx_msg void OnEnChangeEditAo7();
	afx_msg void OnEnChangeEditAo8();
	afx_msg void OnEnChangeEditAo9();
	afx_msg void OnEnChangeEditAo10();
	afx_msg void OnEnChangeEditAo11();
	afx_msg void OnEnChangeEditAo12();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DO16DLG_H__A2538541_32D4_453C_A89E_FA23F40D66B4__INCLUDED_)
