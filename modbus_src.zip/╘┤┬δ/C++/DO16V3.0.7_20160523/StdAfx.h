﻿// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__CE68E9C7_C954_4866_B141_12AF1BF01858__INCLUDED_)
#define AFX_STDAFX_H__CE68E9C7_C954_4866_B141_12AF1BF01858__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT


#define WM_MY_MSG_DEBUGTEXT  (WM_USER+100)
#define WM_MY_MSG_DO (WM_USER+101)
#define WM_MY_MSG_DI  (WM_USER+102)
#define WM_MY_MSG_AI  (WM_USER+103)

//第三方库文件
#include "Markup.h"
#define EQUIP_MAX_NUM  50
#define EQUIP_DI_NUM  20
#define EQUIP_DO_NUM  16
#define EQUIP_AI_NUM  16
typedef struct CEquip
{
	CString name;//名称
	int doRegStart;//DO 起始地址
	int donum;//do 数量
	int diRegStart;//di 起始地址
	int dinum;//di数量
	int aiRegStart;//AI  起始地址
	int ainum;//模拟量数据
	int aoRegStart;//AI  起始地址
	int aonum;//模拟量数据
	int mbBaud1Reg;//波特率地址
	int mbBaud2Reg;//波特率地址
	int mbaddrReg;//偏移地址的地址
	int mbWorkReg;//工作模式的偏移地址
	int mbWorkTime;//延迟时间
	int mbRaddrReg;//读取返回的地址

	int IsValid;//是否有效

	CEquip()
	{
		name = _T("");
		
		doRegStart = 0;
		donum = 0;
		diRegStart = 0;
		dinum = 0;
		aiRegStart = 0;
		ainum = 0;

		mbBaud1Reg = 0;
		mbBaud2Reg = 0;
		mbaddrReg = 0;
		mbWorkReg = 0;
		mbWorkTime = 0;
		mbRaddrReg = 0;

		IsValid = 0;
	}

	void init(CString _name, int _doregStart, int _donum, int _diregStart, int _dinum, int _airegStart, int _ainum, int _aoregStart, int _aonum, int _mbBaud1Reg, int _mbBaud2Reg, int _mbaddrReg, int _mbWorkReg, int _mbWorkTime, int _mbRaddrReg, int _isvalid)
	{
		name = _name;
		doRegStart = _doregStart;
		donum = _donum;
		diRegStart = _diregStart;
		dinum = _dinum;
		aiRegStart = _airegStart;
		ainum = _ainum;
		aoRegStart = _aoregStart;
		aonum = _aonum;

		mbBaud1Reg = _mbBaud1Reg;
		mbBaud2Reg = _mbBaud2Reg;
		mbaddrReg = _mbaddrReg;
		mbWorkReg = _mbWorkReg;
		mbWorkTime = _mbWorkTime;
		mbRaddrReg = _mbRaddrReg;
		IsValid = _isvalid;
	}

	void init(CString _name, int _donum, int _dinum, int _ainum, int _aonum)
	{
		name = _name;
		donum = _donum;
		dinum = _dinum;
		ainum = _ainum;
		aonum = _aonum;
		IsValid = 1;
	}

}CEquip_TCB;


typedef struct CDI
{
	CString name;//名称
	int Isdir;//是否反相
	int IsValid;//是否有效

	CDI()
	{
		name = _T("");
		Isdir = 0;
		IsValid = 0;
	}

	void init(CString _name, int _Isdir, int _isvalid)
	{
		name = _name;
		Isdir = _Isdir;
		IsValid = _isvalid;
	}

}CDI_TCB;


typedef struct CDO
{
	CString name;//名称
	int Isdir;//是否反相
	int IsValid;//是否有效

	CDO()
	{
		name = _T("");
		Isdir = 0;
		IsValid = 0;
	}

	void init(CString _name, int _Isdir, int _isvalid)
	{
		name = _name;
		Isdir = _Isdir;
		IsValid = _isvalid;
	}

}CDO_TCB;


typedef struct CCAI
{
	CString name;//名称
	CString unit;//单位
	double a;//do 数量
	double b;//di数量
	int IsValid;//是否有效

	CCAI()
	{
		name = _T("");
		unit = _T("");
		a = 0;
		b = 0;
		IsValid = 0;
	}

	void init(CString _name, CString _unit,double _a,double _b,int _isvalid)
	{
		name = _name;
		unit = _unit;
		a =_a;
		b = _b;
		IsValid = _isvalid;
	}
}CCAI_TCB;


typedef struct CDefaultSet
{
	CString comname;//名称
	CString baud;//波特率
	CString EquipName;//
	CString addr;
}CDefaultSet_TCB;
//---自定义common库
#include "numtype.h"
#include "methord.h"
#include "CnComm.h"
#include "ClientComm.h"



#include "xmlapp.h"
#include <afxcontrolbars.h>

extern CClientComm Comm_;
extern CEquip_TCB equip[EQUIP_MAX_NUM];
extern CDI_TCB  cdi[EQUIP_DI_NUM];
extern CDO_TCB  cdo[EQUIP_DO_NUM];
extern CCAI_TCB  cai[EQUIP_AI_NUM];
extern CDefaultSet_TCB cset;
extern CString CommpanyName;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__CE68E9C7_C954_4866_B141_12AF1BF01858__INCLUDED_)
