package jydamserial;

public class ModbusUtil {

}
