import net.wimpi.modbus.util.BitVector;

public class helloword {
	public static void main(String[] args) throws Exception{		
		
		Test2();
    }
	public static void Test2() throws Exception
	{
		JYDAMEquip equip = new JYDAMEquip();
		
		//please input the real number of the channel
		int MaxDONum = 4;//继电器数量    
		int MaxDINum = 4;//光耦输入数量
		int MaxAINum = 8;//模拟量输入通道数量
		//初始化设备
		equip.Init("192.168.1.203", 10000, 254); //ip 端口为10000   254为设备的广播地址      
		equip.BeginConnect();	
		
		int cnt=0;
		while(true)
		{
			if(MaxDONum>0)
			{
				cnt++;
				if((cnt&0x01)==0x01)
				{
					System.out.println("打开第一路DO");
					equip.writeSignalDO(0, 1);//
				}
				else 
				{
					System.out.println("关闭第一路DO");
					equip.writeSignalDO(0, 0);//
				}					
			}
			
			//读取DO 继电器
			BitVector DOVal = equip.readDO(MaxDONum);
			Thread.sleep(20);
			//读取DI
			BitVector DIVal = equip.readDI(MaxDINum);
			Thread.sleep(20);
			//读取AI
			int[]     AIVal = equip.readAI(MaxAINum);
			Thread.sleep(20);
			
			
			PrintfDODIVal("DO Status:",DOVal,MaxDONum);
			PrintfDODIVal("DI Status:",DIVal,MaxDINum);
			PrintfAIVal("AI Status:",AIVal);
			Thread.sleep(1000);
		}
		//注意，调试的时候 可能出现链接失败。请手动停止之前的调试。
		//equip.DisConnect();
	}
	
	public static void PrintfDODIVal(String prev,BitVector val,int size)
	{
		System.out.println(prev);
		if(val==null)return;
		for(int i=0;i<size;i++)
			System.out.print("  "+(val.getBit(i)?"1":"0"));
		System.out.println("");
		
	}
	public static void PrintfAIVal(String prev,int[] val)
	{
		System.out.println(prev);
		if(val==null)return;
		for(int i=0;i<val.length;i++)
			System.out.print(val[i]+"  ");
		System.out.println("");
	}
	
	
	
	public static void Test1()
	{
		int rst = ModbusUtil.readDigitalInput("192.168.3.151",10000,254,0);
		System.out.println("DI1:"+rst);
		
		rst = ModbusUtil.readInputRegister("192.168.3.151",10000,254,0);
		System.out.println("AI1:"+rst);
		
		
		ModbusUtil.writeDigitalOutput("192.168.3.151",10000,254,0,1);
		System.out.println("open do1");
		
		rst = ModbusUtil.readDigitalOutput("192.168.3.151",10000,254,0);
		System.out.println("read do1:"+((rst==1)?"open":"close"));
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ModbusUtil.writeDigitalOutput("192.168.3.151",10000,254,0,0);
		System.out.println("close do1");
		
		rst = ModbusUtil.readDigitalOutput("192.168.3.151",10000,254,0);
		System.out.println("read do1:"+((rst==1)?"open":"close"));
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
        System.out.println("test ok");
	}
}
