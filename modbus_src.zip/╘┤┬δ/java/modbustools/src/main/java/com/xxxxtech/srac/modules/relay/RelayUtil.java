package com.xxxxtech.srac.modules.relay;

import net.wimpi.modbus.util.BitVector;

import java.util.List;

/**
 * FileName：RelayUtil <br>
 * CreateTime： 2019-09-30 18:33 <br>
 * Description：<br>
 * 继电器工具类.
 *
 * @author Dawson <br>
 * @version v0.1  <br>
 * @since JDK 1.8
 */

public class RelayUtil {

    private boolean RE_ERROR = false;
    private boolean isConnect = false;
    private JYDAMEquip equip = null;
    

    /**
     * 监听继电器，如果重启，就重新打开继电器
     *
     * @param doorList
     */
    public void listenRelay(String ip, List<Integer> doorList) {
        int MaxDONum = 2;//继电器数量
        try {
            Thread.sleep(1 * 1000);
//            System.out.println(" ---------> " + isConnect +" ----- " + ip);
            if (equip == null && !isConnect) {
                equip = new JYDAMEquip();
                equip.Init(ip, 10000, 254); //ip 端口为10000   254为设备的广播地址
                isConnect = equip.BeginConnect();
                if (isConnect && doorList != null && !RE_ERROR) {
                    for (Integer relayNo : doorList) {
                        equip.writeSignalDO(relayNo, 1);
                        Thread.sleep(20);
                    }
                    RE_ERROR = true;
                    Thread.sleep(2 * 1000);
                    listenRelay(ip, doorList);
                } else {
                    Thread.sleep(2 * 1000);
                    listenRelay(ip, doorList);
                }
            } else {
                Thread.sleep(2 * 1000);
                if (equip != null) {
                    BitVector DOVal = equip.readDO(MaxDONum);
                    System.out.println(" >>>>>>>>>> " + DOVal);
                    listenRelay(ip, doorList);
                } else {
                    isConnect = false;
                }
            }
        } catch (Exception e) {
            System.out.println("出错：" + e.getMessage());
            if (equip != null) {
                if (isConnect) {
                    equip.DisConnect();
                }
                equip = null;
            }

            try {
                Thread.sleep(2 * 1000);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            RE_ERROR = false;
            isConnect = false;
            listenRelay(ip, doorList);
        }
    }

    public static void main(String[] args) throws Exception {

        ModbusUtil modbusUtil1 = new ModbusUtil();
        modbusUtil1.writeDigitalOutput("192.168.1.232",  1, 0);
//        Thread.sleep(20);
//        modbusUtil1.writeDigitalOutput("192.168.0.21",  1, 1);
//        modbusUtil1.writeDigitalOutput("192.168.0.20",  1, 1);

//        int status =  modbusUtil1.readDigitalStatus("192.168.0.23", 0);
//        int status1 =  modbusUtil1.readDigitalInput("192.168.0.21", 1);
//        int status2 =  modbusUtil1.readInputRegister("192.168.0.21", 1);
//        int status3 =  modbusUtil1.readRegister("192.168.0.21", 1);

//        System.out.println(" >>>>> status:" + status);
//        System.out.println(" >>>>> status1:" + status1);
//        System.out.println(" >>>>> status2:" + status2);
//        System.out.println(" >>>>> status3:" + status3);
    }

    public static void test() {
        JYDAMEquip equip = new JYDAMEquip();
        try {
            if (!equip.IsConnect()) {
                equip.Init("192.168.1.102", 10000, 254); //ip 端口为10000   254为设备的广播地址
                boolean isConnect = equip.BeginConnect();
                System.out.println(" ---------> " + isConnect);
                if (isConnect) {
                    equip.writeSignalDO(0, 1);
                    equip.DisConnect();
                    Thread.sleep(2 * 1000);
                    test();
                } else {
                    equip.DisConnect();
                    Thread.sleep(2 * 1000);
                    test();
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            try {
                Thread.sleep(2 * 1000);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            test();
        } finally {
            if (equip.IsConnect()) {
                equip.DisConnect();
            }
        }
    }
}
